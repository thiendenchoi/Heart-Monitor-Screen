`default_nettype none

module conv_linebuf_stream_packer #(
    parameter int unsigned ADDR_WIDTH = 32,
    parameter int unsigned DATA_WIDTH = 256,
    parameter int unsigned ARRAY_DIM = 32,
    parameter int unsigned INPUT_ELEM_WIDTH = 8,
    parameter int unsigned MAX_INPUT_W = 640
)(
    input  logic clk_i,
    input  logic rst_ni,
    input  logic                      start_i,
    input  logic                      next_tile_i,
    input  logic                      prefetch_i,
    input  logic [31:0]               dim_m_i,
    input  logic [31:0]               cfg_k_tiles_i,
    input  logic [31:0]               cfg_origin_base_i,
    input  logic [31:0]               cfg_row_stride_bytes_i,
    input  logic [31:0]               cfg_pixel_stride_bytes_i,
    input  logic [31:0]               cfg_ow_step_bytes_i,
    input  logic [31:0]               cfg_oh_step_bytes_i,
    input  logic [15:0]               cfg_input_h_i,
    input  logic [15:0]               cfg_input_w_i,
    input  logic [15:0]               cfg_input_c_i,
    input  logic [15:0]               cfg_output_w_i,
    input  logic [15:0]               cfg_kernel_h_i,
    input  logic [15:0]               cfg_kernel_w_i,
    input  logic [15:0]               cfg_stride_h_i,
    input  logic [15:0]               cfg_stride_w_i,
    input  logic [15:0]               cfg_pad_h_i,
    input  logic [15:0]               cfg_pad_w_i,
    input  logic [15:0]               cfg_c_base_i,
    input  logic [5:0]                cfg_lane_base_i,
    input  logic                      cfg_coalesce_i,
    input  logic                      cfg_kgen_i,
    input  logic                      cfg_pool_i,
    input  logic                      cfg_c32_fast_i,
    input  logic                      cfg_depthwise_i,
    input  logic [5:0]                cfg_block_valid_bytes_i,
    input  logic [31:0]               cfg_channel_addr_offset_i,
    input  logic [31:0]               cfg_coalesce_k_bytes_i,
    input  logic [7:0]                cfg_k_seed_kh_i,
    input  logic [7:0]                cfg_k_seed_kw_i,
    input  logic [15:0]               cfg_k_seed_ic_i,
    output logic                      obi_req_o,
    input  logic                      obi_gnt_i,
    output logic [ADDR_WIDTH-1:0]     obi_addr_o,
    input  logic                      obi_rvalid_i,
    input  logic [DATA_WIDTH-1:0]     obi_rdata_i,
    output logic [ARRAY_DIM-1:0][INPUT_ELEM_WIDTH-1:0] row_data_o,
    output logic                      row_valid_o,
    input  logic                      row_ready_i,
    output logic                      busy_o,
    output logic                      done_o,
    output logic                      prefetch_busy_o,
    output logic [31:0]               emitted_vectors_o,
    output logic [31:0]               fetch_beats_o,
    output logic [31:0]               bypass_vectors_o,
    output logic [4:0]                debug_state_o,
    output logic [1:0]                debug_fetch_main_state_o,
    output logic [2:0]                debug_fetch_background_state_o,
    output logic [2:0]                debug_bypass_state_o
);

    // The mapped linebuffer macro predates the PMU-only raw state ports.
    // Functional outputs remain mapped; regenerate the macro to preserve
    // detailed state telemetry in this optional bottom-up Sky130 flow.
    assign debug_fetch_main_state_o = '0;
    assign debug_fetch_background_state_o = '0;
    assign debug_bypass_state_o = '0;

    conv_linebuf_stream_packer_mapped i_mapped (
        .clk_i(clk_i), .rst_ni(rst_ni), .start_i(start_i),
        .next_tile_i(next_tile_i), .prefetch_i(prefetch_i), .dim_m_i(dim_m_i),
        .cfg_k_tiles_i(cfg_k_tiles_i), .cfg_origin_base_i(cfg_origin_base_i),
        .cfg_row_stride_bytes_i(cfg_row_stride_bytes_i),
        .cfg_pixel_stride_bytes_i(cfg_pixel_stride_bytes_i),
        .cfg_ow_step_bytes_i(cfg_ow_step_bytes_i),
        .cfg_oh_step_bytes_i(cfg_oh_step_bytes_i),
        .cfg_input_h_i(cfg_input_h_i), .cfg_input_w_i(cfg_input_w_i),
        .cfg_input_c_i(cfg_input_c_i), .cfg_output_w_i(cfg_output_w_i),
        .cfg_kernel_h_i(cfg_kernel_h_i), .cfg_kernel_w_i(cfg_kernel_w_i),
        .cfg_stride_h_i(cfg_stride_h_i), .cfg_stride_w_i(cfg_stride_w_i),
        .cfg_pad_h_i(cfg_pad_h_i), .cfg_pad_w_i(cfg_pad_w_i),
        .cfg_c_base_i(cfg_c_base_i), .cfg_lane_base_i(cfg_lane_base_i),
        .cfg_coalesce_i(cfg_coalesce_i), .cfg_kgen_i(cfg_kgen_i),
        .cfg_pool_i(cfg_pool_i), .cfg_c32_fast_i(cfg_c32_fast_i),
        .cfg_depthwise_i(cfg_depthwise_i),
        .cfg_block_valid_bytes_i(cfg_block_valid_bytes_i),
        .cfg_channel_addr_offset_i(cfg_channel_addr_offset_i),
        .cfg_coalesce_k_bytes_i(cfg_coalesce_k_bytes_i),
        .cfg_k_seed_kh_i(cfg_k_seed_kh_i), .cfg_k_seed_kw_i(cfg_k_seed_kw_i),
        .cfg_k_seed_ic_i(cfg_k_seed_ic_i),
        .obi_req_o(obi_req_o), .obi_gnt_i(obi_gnt_i), .obi_addr_o(obi_addr_o),
        .obi_rvalid_i(obi_rvalid_i), .obi_rdata_i(obi_rdata_i),
        .row_data_o(row_data_o), .row_valid_o(row_valid_o),
        .row_ready_i(row_ready_i), .busy_o(busy_o), .done_o(done_o),
        .prefetch_busy_o(prefetch_busy_o),
        .emitted_vectors_o(emitted_vectors_o), .fetch_beats_o(fetch_beats_o),
        .bypass_vectors_o(bypass_vectors_o), .debug_state_o(debug_state_o)
    );

endmodule

`default_nettype wire
