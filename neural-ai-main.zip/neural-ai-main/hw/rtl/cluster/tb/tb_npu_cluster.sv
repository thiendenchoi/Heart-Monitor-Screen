`default_nettype none

`include "axi/typedef.svh"

module tb_npu_cluster #(
    parameter int unsigned SYSTOLIC_OFM_FIFO_DEPTH = 8,
    parameter int unsigned SYSTOLIC_OTCDM_STALL_PERIOD = 0,
    parameter int unsigned SYSTOLIC_OTCDM_STALL_HOLD = 0
)(
    input  logic        clk_i,       // 1 GHz NPU Clock
    input  logic        rst_ni,      // NPU Reset
    input  logic        fetch_enable_i,
    
    // AXI Slave Interface
    input  logic [31:0] s_axi_awaddr,
    input  logic [2:0]  s_axi_awprot,
    input  logic        s_axi_awvalid,
    output logic        s_axi_awready,
    input  logic [npu_cluster_pkg::AXI_HOST_DATA_WIDTH-1:0] s_axi_wdata,
    input  logic [(npu_cluster_pkg::AXI_HOST_DATA_WIDTH/8)-1:0] s_axi_wstrb,
    input  logic        s_axi_wvalid,
    output logic        s_axi_wready,
    output logic [1:0]  s_axi_bresp,
    output logic        s_axi_bvalid,
    input  logic        s_axi_bready,
    input  logic [31:0] s_axi_araddr,
    input  logic [2:0]  s_axi_arprot,
    input  logic        s_axi_arvalid,
    output logic        s_axi_arready,
    output logic [npu_cluster_pkg::AXI_HOST_DATA_WIDTH-1:0] s_axi_rdata,
    output logic [1:0]  s_axi_rresp,
    output logic        s_axi_rvalid,
    input  logic        s_axi_rready,

    // Backdoor port for Python to initialize axi_sim_mem (DMA target)
    input  logic        backdoor_we_i,
    input  logic [31:0] backdoor_addr_i,
    input  logic [7:0]  backdoor_data_i,
    output logic [7:0]  backdoor_rdata_o,
    input  logic        backdoor_block_toggle_i,
    input  logic [31:0] backdoor_block_addr_i,
    input  logic [5:0]  backdoor_block_bytes_i,
    input  logic [255:0] backdoor_block_data_i,
    output logic [255:0] backdoor_block_rdata_o,
    output logic [2:0]  debug_sys_state_o,
    output logic [1:0]  debug_sys_drain_state_o,
    output logic [4:0]  debug_linebuf_state_o,
    output logic [1:0]  debug_linebuf_fetch_main_state_o,
    output logic [2:0]  debug_linebuf_fetch_background_state_o,
    output logic [2:0]  debug_linebuf_bypass_state_o,
    output logic        irq_o
);

    // AXI Bus between NPU Cluster DMA and axi_sim_mem
    localparam int unsigned AXI_ADDR_WIDTH = 32;
    localparam int unsigned AXI_DATA_WIDTH = 256;
    localparam int unsigned AXI_ID_WIDTH   = 4;
    localparam int unsigned AXI_USER_WIDTH = 1;

    typedef logic [AXI_ADDR_WIDTH-1:0]   axi_addr_t;
    typedef logic [AXI_DATA_WIDTH-1:0]   axi_data_t;
    typedef logic [AXI_ID_WIDTH-1:0]     axi_id_t;
    typedef logic [AXI_DATA_WIDTH/8-1:0] axi_strb_t;
    typedef logic [AXI_USER_WIDTH-1:0]   axi_user_t;

    `AXI_TYPEDEF_ALL(axi, axi_addr_t, axi_id_t, axi_data_t, axi_strb_t, axi_user_t)

    axi_req_t  axi_req;
    axi_resp_t axi_rsp;

    // Instance of NPU Cluster
    initial $display("BOOT_ADDR is %h", u_npu_cluster.u_snitch_core.BOOT_ADDR);
    npu_cluster #(
        .SYSTOLIC_OFM_FIFO_DEPTH(SYSTOLIC_OFM_FIFO_DEPTH),
        .SYSTOLIC_OTCDM_STALL_PERIOD(SYSTOLIC_OTCDM_STALL_PERIOD),
        .SYSTOLIC_OTCDM_STALL_HOLD(SYSTOLIC_OTCDM_STALL_HOLD)
    ) u_npu_cluster (
        .clk_i            (clk_i),
        .rst_ni           (rst_ni),
        .fetch_enable_i   (fetch_enable_i),

        // AXI Master (DMA)
        .axi_aw_addr_o    (axi_req.aw.addr),
        .axi_aw_len_o     (axi_req.aw.len),
        .axi_aw_size_o    (axi_req.aw.size),
        .axi_aw_burst_o   (axi_req.aw.burst),
        .axi_aw_valid_o   (axi_req.aw_valid),
        .axi_aw_ready_i   (axi_rsp.aw_ready),

        .axi_w_data_o     (axi_req.w.data),
        .axi_w_strb_o     (axi_req.w.strb),
        .axi_w_last_o     (axi_req.w.last),
        .axi_w_valid_o    (axi_req.w_valid),
        .axi_w_ready_i    (axi_rsp.w_ready),

        .axi_b_resp_i     (axi_rsp.b.resp),
        .axi_b_valid_i    (axi_rsp.b_valid),
        .axi_b_ready_o    (axi_req.b_ready),

        .axi_ar_addr_o    (axi_req.ar.addr),
        .axi_ar_len_o     (axi_req.ar.len),
        .axi_ar_size_o    (axi_req.ar.size),
        .axi_ar_burst_o   (axi_req.ar.burst),
        .axi_ar_valid_o   (axi_req.ar_valid),
        .axi_ar_ready_i   (axi_rsp.ar_ready),

        .axi_r_data_i     (axi_rsp.r.data),
        .axi_r_resp_i     (axi_rsp.r.resp),
        .axi_r_last_i     (axi_rsp.r.last),
        .axi_r_valid_i    (axi_rsp.r_valid),
        .axi_r_ready_o    (axi_req.r_ready),

        // AXI Slave (Host Boot)
        .s_axi_aw_addr_i  (s_axi_awaddr),
        .s_axi_aw_len_i   (8'h0),
        .s_axi_aw_size_i  (3'b010), // 4 bytes
        .s_axi_aw_burst_i (2'b01),  // INCR
        .s_axi_aw_valid_i (s_axi_awvalid),
        .s_axi_aw_ready_o (s_axi_awready),
        .s_axi_w_data_i   (s_axi_wdata),
        .s_axi_w_strb_i   (s_axi_wstrb),
        .s_axi_w_last_i   (1'b1),
        .s_axi_w_valid_i  (s_axi_wvalid),
        .s_axi_w_ready_o  (s_axi_wready),
        .s_axi_b_resp_o   (s_axi_bresp),
        .s_axi_b_valid_o  (s_axi_bvalid),
        .s_axi_b_ready_i  (s_axi_bready),
        .s_axi_ar_addr_i  (s_axi_araddr),
        .s_axi_ar_len_i   (8'h0),
        .s_axi_ar_size_i  (3'b010), // 4 bytes
        .s_axi_ar_burst_i (2'b01),  // INCR
        .s_axi_ar_valid_i (s_axi_arvalid),
        .s_axi_ar_ready_o (s_axi_arready),
        .s_axi_r_data_o   (s_axi_rdata),
        .s_axi_r_resp_o   (s_axi_rresp),
        .s_axi_r_last_o   (), // Ignoring last out
        .s_axi_r_valid_o  (s_axi_rvalid),
        .s_axi_r_ready_i  (s_axi_rready),

        // Interrupts
        .debug_sys_state_o(debug_sys_state_o),
        .debug_sys_drain_state_o(debug_sys_drain_state_o),
        .debug_linebuf_state_o(debug_linebuf_state_o),
        .debug_linebuf_fetch_main_state_o(debug_linebuf_fetch_main_state_o),
        .debug_linebuf_fetch_background_state_o(debug_linebuf_fetch_background_state_o),
        .debug_linebuf_bypass_state_o(debug_linebuf_bypass_state_o),
        .irq_o            (irq_o)
    );

    // Tie off unused AXI struct fields from DMA Engine
    assign axi_req.aw.id     = '0;
    assign axi_req.aw.lock   = 1'b0;
    assign axi_req.aw.cache  = '0;
    assign axi_req.aw.prot   = '0;
    assign axi_req.aw.qos    = '0;
    assign axi_req.aw.region = '0;
    assign axi_req.aw.atop   = '0;
    assign axi_req.aw.user   = '0;

    assign axi_req.w.user    = '0;

    assign axi_req.ar.id     = '0;
    assign axi_req.ar.lock   = 1'b0;
    assign axi_req.ar.cache  = '0;
    assign axi_req.ar.prot   = '0;
    assign axi_req.ar.qos    = '0;
    assign axi_req.ar.region = '0;
    assign axi_req.ar.user   = '0;

    // Drive/sample away from the active edge of the 1ns clock. Zero-delay
    // acquisition races DMA RREADY changes and can drop a stalled final beat.
    axi_sim_mem #(
        .AddrWidth          (AXI_ADDR_WIDTH),
        .DataWidth          (AXI_DATA_WIDTH),
        .IdWidth            (AXI_ID_WIDTH),
        .UserWidth          (AXI_USER_WIDTH),
        .NumPorts           (1),
        .axi_req_t          (axi_req_t),
        .axi_rsp_t          (axi_resp_t),
        .WarnUninitialized  (1'b0),
        .UninitializedData  ("zeros"),
        .ApplDelay          (100ps),
        .AcqDelay           (400ps)
    ) u_axi_sim_mem (
        .clk_i              (clk_i),
        .rst_ni             (rst_ni),
        .axi_req_i          (axi_req),
        .axi_rsp_o          (axi_rsp),
        .mon_w_valid_o      (),
        .mon_w_addr_o       (),
        .mon_w_data_o       (),
        .mon_w_id_o         (),
        .mon_w_user_o       (),
        .mon_w_beat_count_o (),
        .mon_w_last_o       (),
        .mon_r_valid_o      (),
        .mon_r_addr_o       (),
        .mon_r_data_o       (),
        .mon_r_id_o         (),
        .mon_r_user_o       (),
        .mon_r_beat_count_o (),
        .mon_r_last_o       ()
    );

    // Backdoor write logic for Python/Cocotb to initialize memory
    always_ff @(posedge clk_i) begin
        if (backdoor_we_i) begin
            u_axi_sim_mem.mem[backdoor_addr_i] = backdoor_data_i;
        end
    end

    // Backdoor read logic
    assign backdoor_rdata_o = u_axi_sim_mem.mem[backdoor_addr_i];

    // VPI-driven block backdoor.  The toggle invokes the task without
    // advancing the DUT clock, so large L2 fixtures do not consume one
    // simulated cycle per byte.
    task automatic backdoor_mem_write_block(
        input logic [31:0] address,
        input logic [255:0] data,
        input logic [5:0] bytes
    );
        for (int unsigned index = 0; index < bytes; index++) begin
            u_axi_sim_mem.mem[address + index] = data[index * 8 +: 8];
        end
    endtask

    always @(backdoor_block_toggle_i) begin
        if (backdoor_block_bytes_i != 0 && backdoor_block_bytes_i <= 32) begin
            backdoor_mem_write_block(backdoor_block_addr_i,
                                     backdoor_block_data_i,
                                     backdoor_block_bytes_i);
        end
    end

    always_comb begin
        backdoor_block_rdata_o = '0;
        for (int unsigned index = 0; index < 32; index++) begin
            backdoor_block_rdata_o[index * 8 +: 8] =
                u_axi_sim_mem.mem[backdoor_block_addr_i + index];
        end
    end

endmodule
