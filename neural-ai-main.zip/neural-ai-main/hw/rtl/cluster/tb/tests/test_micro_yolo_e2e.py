import logging
import math
import os
import sys
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
from cocotbext.axi import AxiLiteBus, AxiLiteMaster

from npu_test_utils import (
    PMU_COUNTER_NAMES,
    load_firmware_elf_axi,
    read_dtcm_word,
    read_l2_bytes,
    release_fetch,
    reset_dut,
    wait_for_host_irq,
    write_l2_bytes,
)

TB_DIR = Path(__file__).resolve().parents[1]
if str(TB_DIR) not in sys.path:
    sys.path.insert(0, str(TB_DIR))

from npu_linebuf_precompute import (
    MICRO_YOLO_DESC_L2_BASE,
    micro_yolo_descriptor_blobs,
    micro_yolo_descriptor_manifest,
    micro_yolo_jobs,
)


L2_INPUT = 0x80000000
L2_WEIGHT0 = 0x80008000
L2_SIG_LUT = 0x80009000
L2_WEIGHT1 = 0x8000A000
L2_WEIGHT2 = 0x8000D000
L2_WEIGHT3 = 0x80010000
L2_OUTPUT = 0x80020000
L2_DFL_EXP_LUT = 0x80054000
L2_DFL_RECIP_LUT = 0x80054400
L2_DFL_OUTPUT = 0x80060000
L2_CLASS_OUTPUT = 0x80065000

INPUT_H = 96
INPUT_W = 96
OUTPUT_H = 48
OUTPUT_W = 48
DOWN_H = 24
DOWN_W = 24
WEIGHT_BYTES = 32 * 32
C2F_WEIGHT_BYTES = 3 * 3 * 32 * 32
DOWN_WEIGHT_BYTES = C2F_WEIGHT_BYTES
HEAD_WEIGHT_BYTES = 2 * C2F_WEIGHT_BYTES
LUT_BYTES = 256
OUTPUT_BYTES = OUTPUT_H * OUTPUT_W * 32
HEAD_CHANNELS = 32
HEAD_BOX_CHANNELS = 16
HEAD_CLASS_CHANNELS = HEAD_CHANNELS - HEAD_BOX_CHANNELS
HEAD_BOX_BYTES = OUTPUT_H * OUTPUT_W * HEAD_BOX_CHANNELS
HEAD_CLASS_BYTES = OUTPUT_H * OUTPUT_W * HEAD_CLASS_CHANNELS
DFL_REG_MAX = 4
DFL_SIDES = 4
DFL_OUTPUT_VALUES = OUTPUT_H * OUTPUT_W * DFL_SIDES
DFL_OUTPUT_BYTES = DFL_OUTPUT_VALUES * 2
CLASS_OUTPUT_BYTES = HEAD_CLASS_BYTES
DTCM_STATUS = 0x10008000
DTCM_FAIL_CODE = 0x10008004
DTCM_LAYER = 0x10008008
DTCM_OP = 0x1000800C
DTCM_EVENT = 0x10008010

OP_NAMES = {
    1: "DMA_IN",
    2: "DMA_OUT",
    5: "SPATZ_REQUANT",
    8: "CONV2D_RGB_LINEBUF_REQUANT",
    9: "LOGISTIC_LUT_I8",
    10: "MUL_I8",
    11: "CONV2D_C32_LINEBUF",
    12: "CONV2D_C32_LINEBUF_REQUANT",
    13: "ADD_I8",
    14: "CONV2D_C32_DOWNSAMPLE_LINEBUF_REQUANT",
    15: "MAXPOOL2D_I8",
    16: "UPSAMPLE_NEAREST_I8",
    17: "CONV2D_DUAL_SOURCE_C32_LINEBUF_REQUANT_L2",
    18: "DFL_SOFTMAX_I8_Q8",
    19: "CLASS_SIGMOID_ROW32_HIGH16_I8",
}


def tile_env(name, default=16):
    return int(os.getenv(name, str(default)))


def micro_yolo_linebuf_blobs():
    return micro_yolo_descriptor_blobs(
        c2f_tile_oh=tile_env("MICRO_YOLO_C2F_TILE_OH"),
        c2f_tile_ow=tile_env("MICRO_YOLO_C2F_TILE_OW"),
        down_tile_oh=tile_env("MICRO_YOLO_DOWN_TILE_OH"),
        down_tile_ow=tile_env("MICRO_YOLO_DOWN_TILE_OW"),
        head_tile_oh=tile_env("MICRO_YOLO_HEAD_TILE_OH"),
        head_tile_ow=tile_env("MICRO_YOLO_HEAD_TILE_OW"),
    )


def micro_yolo_linebuf_manifest_and_blobs():
    blobs = micro_yolo_linebuf_blobs()
    return micro_yolo_descriptor_manifest(blobs), blobs


def assert_micro_yolo_linebuf_layout_contract():
    jobs = micro_yolo_jobs(
        c2f_tile_oh=tile_env("MICRO_YOLO_C2F_TILE_OH"),
        c2f_tile_ow=tile_env("MICRO_YOLO_C2F_TILE_OW"),
        down_tile_oh=tile_env("MICRO_YOLO_DOWN_TILE_OH"),
        down_tile_ow=tile_env("MICRO_YOLO_DOWN_TILE_OW"),
        head_tile_oh=tile_env("MICRO_YOLO_HEAD_TILE_OH"),
        head_tile_ow=tile_env("MICRO_YOLO_HEAD_TILE_OW"),
    )

    stem_lb = jobs["STEM"][0]["linebuf"]
    assert stem_lb["input_c"] == 3
    assert stem_lb["pixel_stride_bytes"] == 3
    assert stem_lb["block_valid_bytes"] == 3
    assert stem_lb["c32_fast"] == 0

    for name in ("C2F", "DOWN", "HEAD0"):
        lb = jobs[name][0]["linebuf"]
        assert lb["input_c"] == 32, name
        assert lb["pixel_stride_bytes"] == 32, name
        assert lb["row_stride_bytes"] % 32 == 0, name
        assert lb["block_valid_bytes"] == 32, name
        assert lb["c32_fast"] == 1, name

    head1_lb = jobs["HEAD1_L2"][0]["job"]["linebuf"]
    assert head1_lb["input_c"] == 32
    assert head1_lb["pixel_stride_bytes"] == 32
    assert head1_lb["row_stride_bytes"] % 32 == 0
    assert head1_lb["block_valid_bytes"] == 32
    assert head1_lb["c32_fast"] == 1


def pmu_direct_snapshot(dut):
    pmu = dut.u_npu_cluster.u_pmu
    counters = {}
    for idx, name in enumerate(PMU_COUNTER_NAMES):
        counter = getattr(getattr(pmu, f"gen_counters[{idx}]"), "u_counter")
        raw_value = counter.counter_q.value
        counters[name] = raw_value.to_unsigned() if raw_value.is_resolvable else 0
    return counters


def pmu_delta(end, start):
    return {
        name: end.get(name, 0) - start.get(name, 0)
        for name in PMU_COUNTER_NAMES
    }


def format_layer_pmu(layer, op, counters):
    cycles = counters.get("cycle", 0)

    def pct(name):
        return (100.0 * counters.get(name, 0) / cycles) if cycles else 0.0

    return (
        f"layer {layer}: {OP_NAMES.get(op, f'op{op}')} "
        f"cycles={cycles} "
        f"sys_compute={counters.get('sys_compute', 0)}({pct('sys_compute'):.1f}%) "
        f"ifm_req={counters.get('sys_ifm_req', 0)} "
        f"ofm_req={counters.get('sys_ofm_req', 0)} "
        f"ofm_stall={counters.get('sys_ofm_stall', 0)} "
        f"afu_done={counters.get('afu_done', 0)} "
        f"afu_stall={counters.get('afu_tcdm_stall', 0)} "
        f"idma_busy={counters.get('idma_busy', 0)} "
        f"tcdm_stall={counters.get('tcdm_stall', 0)}"
    )


async def monitor_step_pmu(dut, timeout_cycles):
    # Firmware updates a tiny D-TCM trace page at graph-layer entry/exit.
    # Sampling PMU on those trace transitions gives a per-layer performance
    # breakdown without needing Snitch-side printf or interrupt handlers.
    samples = []
    last_trace = None

    for _ in range(timeout_cycles):
        trace = (
            read_dtcm_word(dut, DTCM_LAYER),
            read_dtcm_word(dut, DTCM_OP),
            read_dtcm_word(dut, DTCM_EVENT),
        )
        if trace != last_trace:
            samples.append((trace, pmu_direct_snapshot(dut)))
            last_trace = trace
        irq_value = dut.irq_o.value
        if irq_value.is_resolvable and int(irq_value) == 1:
            break
        await RisingEdge(dut.clk_i)

    final_trace = (
        read_dtcm_word(dut, DTCM_LAYER),
        read_dtcm_word(dut, DTCM_OP),
        read_dtcm_word(dut, DTCM_EVENT),
    )
    final_sample = (final_trace, pmu_direct_snapshot(dut))
    if not samples or samples[-1][0] != final_trace:
        samples.append(final_sample)
    else:
        samples[-1] = final_sample

    layer_lines = []
    for idx in range(1, len(samples)):
        prev_trace, prev_pmu = samples[idx - 1]
        curr_trace, curr_pmu = samples[idx]
        layer, op, event = prev_trace
        if event != 1:
            continue
        layer_lines.append(format_layer_pmu(layer, op, pmu_delta(curr_pmu, prev_pmu)))
    return layer_lines


def to_u8(value):
    return value & 0xFF


def to_i8(value):
    value &= 0xFF
    return value - 0x100 if value & 0x80 else value


def deterministic_fixture():
    # Keep all fixtures generated in Python so this test is self-contained.
    # The formulas intentionally stay small-valued: they exercise sign,
    # saturation, padding, and accumulation without making mismatches hard to
    # inspect as signed INT8 values.
    input_hwc = [
        ((y * 3 + x * 5 + c * 7) % 7) - 3
        for y in range(INPUT_H)
        for x in range(INPUT_W)
        for c in range(3)
    ]
    weight0 = [
        ((k * 2 + n * 3) % 5) - 2
        for k in range(32)
        for n in range(32)
    ]
    weight1 = [
        ((k * 5 + n * 7 + 3) % 9) - 4
        for k in range(3 * 3 * 32)
        for n in range(32)
    ]
    weight2 = [
        ((k * 11 + n * 13 + 5) % 11) - 5
        for k in range(3 * 3 * 32)
        for n in range(32)
    ]
    weight3 = [
        # The first contiguous C32 chunk is consumed by the upsample branch.
        # The second contiguous C32 chunk is consumed by the skip branch.
        # Firmware does not materialize concat; it runs these chunks separately.
        ((chunk * 17 + k * 7 + n * 5 + 1) % 13) - 6
        for chunk in range(2)
        for k in range(3 * 3 * 32)
        for n in range(32)
    ]
    sigmoid_lut = [
        max(0, min(127, int(round((1.0 / (1.0 + math.exp(-to_i8(index) / 16.0))) * 127.0))))
        for index in range(256)
    ]
    return input_hwc, weight0, weight1, weight2, weight3, sigmoid_lut


def conv3x3s2p1_c3_o32(input_hwc, weight):
    out = []
    for oy in range(OUTPUT_H):
        for ox in range(OUTPUT_W):
            out_row = []
            for n in range(32):
                acc = 0
                k = 0
                for ky in range(-1, 2):
                    iy = oy * 2 + ky
                    for kx in range(-1, 2):
                        ix = ox * 2 + kx
                        for c in range(3):
                            if 0 <= iy < INPUT_H and 0 <= ix < INPUT_W:
                                value = input_hwc[(iy * INPUT_W + ix) * 3 + c]
                            else:
                                value = 0
                            acc += value * weight[k * 32 + n]
                            k += 1
                out_row.append(acc)
            out.append(out_row)
    return out


def conv3x3_c32_o32(input_flat, input_h, input_w, output_h, output_w, stride, weight):
    # ROW32 logical layout: each spatial pixel stores one contiguous C32 vector.
    # Weight layout is K-major, OC-minor: [kh, kw, ic, oc32].
    out = []
    for oy in range(output_h):
        for ox in range(output_w):
            out_row = []
            for n in range(32):
                acc = 0
                k = 0
                for ky in range(-1, 2):
                    iy = oy * stride + ky
                    for kx in range(-1, 2):
                        ix = ox * stride + kx
                        for c in range(32):
                            if 0 <= iy < input_h and 0 <= ix < input_w:
                                value = input_flat[((iy * input_w + ix) * 32) + c]
                            else:
                                value = 0
                            acc += value * weight[k * 32 + n]
                            k += 1
                out_row.append(acc)
            out.append(out_row)
    return out


def conv3x3s1p1_c32_o32(input_flat, weight):
    return conv3x3_c32_o32(input_flat, OUTPUT_H, OUTPUT_W, OUTPUT_H, OUTPUT_W, 1, weight)


def conv3x3s2p1_c32_o32(input_flat, weight):
    return conv3x3_c32_o32(input_flat, OUTPUT_H, OUTPUT_W, DOWN_H, DOWN_W, 2, weight)


def maxpool2d_5x5s1p2_c32(input_flat):
    out = []
    for oh in range(DOWN_H):
        for ow in range(DOWN_W):
            out_pixel = [-128] * 32
            for kh in range(-2, 3):
                ih = oh + kh
                if ih < 0 or ih >= DOWN_H:
                    continue
                for kw in range(-2, 3):
                    iw = ow + kw
                    if iw < 0 or iw >= DOWN_W:
                        continue
                    base = ((ih * DOWN_W + iw) * 32)
                    for c in range(32):
                        out_pixel[c] = max(out_pixel[c], input_flat[base + c])
            out.extend(out_pixel)
    return out


def upsample_nearest2x_c32(input_flat):
    # C32 nearest-neighbor upsample mirrors spatz_upsample_nearest2x_c32_i8:
    # every 24x24x32 input pixel is copied to a 2x2 block in the 48x48 output.
    out = []
    for oh in range(OUTPUT_H):
        ih = oh // 2
        for ow in range(OUTPUT_W):
            iw = ow // 2
            base = ((ih * DOWN_W + iw) * 32)
            out.extend(input_flat[base:base + 32])
    return out


def requant(values, min_val, max_val):
    return [max(min_val, min(max_val, value)) for value in values]


def split_raw_head_box_class(raw_head):
    assert len(raw_head) == OUTPUT_H * OUTPUT_W * HEAD_CHANNELS
    box = []
    cls = []
    for pixel in range(OUTPUT_H * OUTPUT_W):
        base = pixel * HEAD_CHANNELS
        box.extend(raw_head[base:base + HEAD_BOX_CHANNELS])
        cls.extend(raw_head[base + HEAD_BOX_CHANNELS:base + HEAD_CHANNELS])
    assert len(box) == HEAD_BOX_BYTES
    assert len(cls) == HEAD_CLASS_BYTES
    return box, cls


def dfl_exp_lut_value(index):
    if index == 0:
        return 32768
    neg_delta = 256 - index
    shift = neg_delta >> 4
    frac = neg_delta & 15
    base = 1 if shift >= 15 else 32768 >> shift
    next_value = base >> 1 if base > 1 else 1
    value = ((base * (16 - frac)) + (next_value * frac) + 8) >> 4
    return value or 1


def dfl_recip_lut_value(index):
    midpoint_q9 = 512 + (index * 2) + 1
    return ((1 << 37) + (midpoint_q9 >> 1)) // midpoint_q9


def dfl_recip_index_from_sum(total):
    shift = total.bit_length() - 1
    norm_q8 = (total << 8) >> shift
    if norm_q8 < 256:
        return 0
    if norm_q8 > 511:
        return 255
    return norm_q8 & 0xFF


def pack_u32_le(values):
    data = []
    for value in values:
        data.extend([
            value & 0xFF,
            (value >> 8) & 0xFF,
            (value >> 16) & 0xFF,
            (value >> 24) & 0xFF,
        ])
    return data


def dfl_softmax4_q8(box_branch):
    # Bit-exact golden for AFU fused DFL mode. This intentionally follows the
    # reciprocal-LUT approximation and rounding in afu_core.sv rather than an
    # ideal integer divide, so the E2E check must match 1:1.
    assert len(box_branch) == HEAD_BOX_BYTES
    out = []
    for loc in range(OUTPUT_H * OUTPUT_W):
        pixel_base = loc * HEAD_BOX_CHANNELS
        for side in range(DFL_SIDES):
            side_base = pixel_base + side * DFL_REG_MAX
            logits = [to_i8(box_branch[side_base + bin_idx]) for bin_idx in range(DFL_REG_MAX)]
            max_value = max(logits)
            exp_values = [
                dfl_exp_lut_value((value - max_value) & 0xFF)
                for value in logits
            ]
            total = sum(exp_values)
            weighted = sum(bin_idx * exp_values[bin_idx] for bin_idx in range(DFL_REG_MAX))
            shift = total.bit_length() - 1
            recip = dfl_recip_lut_value(dfl_recip_index_from_sum(total))
            total_shift = 28 + shift
            rounded = (((weighted << 8) * recip) + (1 << (total_shift - 1))) >> total_shift
            out.append(min(rounded, 0xFFFF))
    assert len(out) == DFL_OUTPUT_VALUES
    return out


def bytes_to_u16_le(data):
    assert len(data) % 2 == 0
    return [
        data[idx] | (data[idx + 1] << 8)
        for idx in range(0, len(data), 2)
    ]


def golden_micro_yolo(input_hwc, weight0, weight1, weight2, weight3, sigmoid_lut):
    # Golden follows the current hardware graph, not an older materialized
    # concat graph. The head identity is:
    #   Conv([upsample, skip], W) == Conv(upsample, W0) + Conv(skip, W1)
    # Requant/clamp happens only after the two C32 chunks are accumulated.
    conv0 = conv3x3s2p1_c3_o32(input_hwc, weight0)
    stem_flat = requant([value for row in conv0 for value in row], -128, 127)
    sig_flat = [to_i8(sigmoid_lut[to_u8(value)]) for value in stem_flat]
    out_flat = requant(
        [(stem * sig) >> 7 for stem, sig in zip(stem_flat, sig_flat)],
        -128,
        127,
    )
    c2f = conv3x3s1p1_c32_o32(out_flat, weight1)
    c2f_flat = requant([value for row in c2f for value in row], -128, 127)
    residual_flat = requant(
        [conv_value + residual_value for conv_value, residual_value in zip(c2f_flat, out_flat)],
        -128,
        127,
    )
    down = conv3x3s2p1_c32_o32(residual_flat, weight2)
    down_flat = requant([value for row in down for value in row], -128, 127)
    pool_flat = maxpool2d_5x5s1p2_c32(down_flat)
    upsample_flat = upsample_nearest2x_c32(pool_flat)
    head_up = conv3x3s1p1_c32_o32(upsample_flat, weight3[:C2F_WEIGHT_BYTES])
    head_skip = conv3x3s1p1_c32_o32(out_flat, weight3[C2F_WEIGHT_BYTES:])
    head_flat = requant(
        [
            up_value + skip_value
            for up_row, skip_row in zip(head_up, head_skip)
            for up_value, skip_value in zip(up_row, skip_row)
        ],
        -128,
        127,
    )
    return [to_u8(value) for value in head_flat]


@cocotb.test()
async def test_micro_yolo_e2e(dut):
    logging.getLogger("cocotb.tb_npu_cluster.s_axi").setLevel(logging.WARNING)
    timeout_cycles = int(os.getenv("MICRO_YOLO_TIMEOUT_CYCLES", "1200000"))

    clock = Clock(dut.clk_i, 1, unit="ns")
    cocotb.start_soon(clock.start())

    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )

    input_hwc, weight0, weight1, weight2, weight3, sigmoid_lut = deterministic_fixture()
    expected = golden_micro_yolo(input_hwc, weight0, weight1, weight2, weight3, sigmoid_lut)
    expected_box, expected_class = split_raw_head_box_class(expected)
    expected_dfl = dfl_softmax4_q8(expected_box)
    expected_class_sigmoid = [sigmoid_lut[value] for value in expected_class]

    fw_path = os.path.join(
        os.path.dirname(__file__),
        "../../../../../sw/test/micro_yolo/micro_yolo.elf",
    )
    assert os.path.exists(fw_path), "Missing firmware. Run `make -C sw/test/micro_yolo` first."

    assert_micro_yolo_linebuf_layout_contract()
    await reset_dut(dut)
    await write_l2_bytes(dut, L2_INPUT, [to_u8(value) for value in input_hwc])
    await write_l2_bytes(dut, L2_WEIGHT0, [to_u8(value) for value in weight0])
    await write_l2_bytes(dut, L2_SIG_LUT, sigmoid_lut)
    await write_l2_bytes(dut, L2_WEIGHT1, [to_u8(value) for value in weight1])
    await write_l2_bytes(dut, L2_WEIGHT2, [to_u8(value) for value in weight2])
    await write_l2_bytes(dut, L2_WEIGHT3, [to_u8(value) for value in weight3])
    await write_l2_bytes(dut, L2_DFL_EXP_LUT, pack_u32_le(dfl_exp_lut_value(i) for i in range(256)))
    await write_l2_bytes(dut, L2_DFL_RECIP_LUT, pack_u32_le(dfl_recip_lut_value(i) for i in range(256)))
    linebuf_manifest, linebuf_blobs = micro_yolo_linebuf_manifest_and_blobs()
    dut._log.info(
        "Writing Micro-YOLO linebuffer descriptor manifest: addr=0x%08x bytes=%d",
        MICRO_YOLO_DESC_L2_BASE,
        len(linebuf_manifest),
    )
    await write_l2_bytes(dut, MICRO_YOLO_DESC_L2_BASE, list(linebuf_manifest))
    for blob in linebuf_blobs:
        dut._log.info(
            "Writing Micro-YOLO linebuffer descriptor blob %s: addr=0x%08x count=%d bytes=%d",
            blob.name,
            blob.l2_addr,
            blob.count,
            len(blob.data),
        )
        await write_l2_bytes(dut, blob.l2_addr, list(blob.data))
    await load_firmware_elf_axi(dut, axi_master, fw_path)
    await release_fetch(dut, axi_master=axi_master)
    step_pmu_task = cocotb.start_soon(monitor_step_pmu(dut, timeout_cycles))

    try:
        await wait_for_host_irq(
            dut,
            timeout_cycles=timeout_cycles,
            axi_master=axi_master,
            report_name="test_micro_yolo_e2e",
        )
    except AssertionError as exc:
        raise AssertionError(
            f"{exc}: status=0x{read_dtcm_word(dut, DTCM_STATUS):08x} "
            f"fail=0x{read_dtcm_word(dut, DTCM_FAIL_CODE):08x} "
            f"layer={read_dtcm_word(dut, DTCM_LAYER)} "
            f"op={read_dtcm_word(dut, DTCM_OP)} "
            f"event={read_dtcm_word(dut, DTCM_EVENT)}"
        ) from exc
    status = read_dtcm_word(dut, DTCM_STATUS)
    assert status == 0xDEADBEEF, (
        f"micro-YOLO firmware failed: status=0x{status:08x} "
        f"fail=0x{read_dtcm_word(dut, DTCM_FAIL_CODE):08x} "
        f"layer={read_dtcm_word(dut, DTCM_LAYER)} "
        f"op={read_dtcm_word(dut, DTCM_OP)} "
        f"event={read_dtcm_word(dut, DTCM_EVENT)}"
    )
    step_pmu_lines = await step_pmu_task
    dut._log.info("test_micro_yolo_e2e per-layer PMU:\n  %s", "\n  ".join(step_pmu_lines))

    got = await read_l2_bytes(dut, L2_OUTPUT, OUTPUT_BYTES)
    for idx, (got_byte, exp_byte) in enumerate(zip(got, expected)):
        assert got_byte == exp_byte, (
            f"micro-YOLO output mismatch idx={idx}: "
            f"got={to_i8(got_byte)} expected={to_i8(exp_byte)}"
        )
    got_box, got_class = split_raw_head_box_class(got)
    got_dfl_bytes = await read_l2_bytes(dut, L2_DFL_OUTPUT, DFL_OUTPUT_BYTES)
    got_dfl = bytes_to_u16_le(got_dfl_bytes)
    got_class_sigmoid = await read_l2_bytes(dut, L2_CLASS_OUTPUT, CLASS_OUTPUT_BYTES)
    for idx, (got_byte, exp_byte) in enumerate(zip(got_box, expected_box)):
        assert got_byte == exp_byte, (
            f"micro-YOLO box branch mismatch idx={idx}: "
            f"got={to_i8(got_byte)} expected={to_i8(exp_byte)}"
        )
    for idx, (got_byte, exp_byte) in enumerate(zip(got_class, expected_class)):
        assert got_byte == exp_byte, (
            f"micro-YOLO class branch mismatch idx={idx}: "
            f"got={to_i8(got_byte)} expected={to_i8(exp_byte)}"
        )
    for idx, (got_value, exp_value) in enumerate(zip(got_dfl, expected_dfl)):
        assert got_value == exp_value, (
            f"micro-YOLO DFL q8 mismatch idx={idx}: "
            f"got={got_value} expected={exp_value}"
        )
    for idx, (got_byte, exp_byte) in enumerate(zip(got_class_sigmoid, expected_class_sigmoid)):
        assert got_byte == exp_byte, (
            f"micro-YOLO class sigmoid mismatch idx={idx}: "
            f"got={to_i8(got_byte)} expected={to_i8(exp_byte)}"
        )
