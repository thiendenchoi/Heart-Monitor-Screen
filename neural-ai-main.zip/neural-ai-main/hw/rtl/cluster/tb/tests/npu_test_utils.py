import inspect
import os
import struct

from cocotb.triggers import (
    ClockCycles,
    First,
    ReadOnly,
    RisingEdge,
    SimTimeoutError,
    Timer,
    ValueChange,
    with_timeout,
)


PASS_SIGNATURE = 0xDEADBEEF
FAIL_SIGNATURE_MASK = 0xFFF00000
FAIL_SIGNATURE_PREFIX = 0xBAD00000

ITCM_BASE = 0x10000000
TCM_SIZE_BYTES = 32 * 1024
PMU_BASE = 0x20004000
PMU_CTRL = PMU_BASE + 0x0000
PMU_STATUS = PMU_BASE + 0x0004
PMU_NUM_COUNTERS = PMU_BASE + 0x0008
PMU_STATUS1 = PMU_BASE + 0x000C
PMU_STATUS2 = PMU_BASE + 0x0010
PMU_STATUS3 = PMU_BASE + 0x0014
PMU_VERSION = PMU_BASE + 0x0018
PMU_FILTER_CTRL = PMU_BASE + 0x001C
PMU_FILTER_CONTEXT = PMU_BASE + 0x0020
PMU_CURRENT_CONTEXT = PMU_BASE + 0x0024
PMU_CURRENT_PHASE = PMU_BASE + 0x0028
PMU_STATUS4 = PMU_BASE + 0x002C
PMU_STATUS5 = PMU_BASE + 0x0030
PMU_COUNTER_BASE = PMU_BASE + 0x0100
PMU_CTRL_ENABLE = 0x00000001
PMU_CTRL_CLEAR = 0x00000002
PMU_CTRL_SNAPSHOT = 0x00000004

PMU_COUNTER_NAMES = [
    "cycle",
    "snitch_retired_instr",
    "snitch_retired_load",
    "snitch_retired_int",
    "snitch_retired_acc",
    "snitch_tcdm_req",
    "snitch_tcdm_stall",
    "spatz_issue",
    "spatz_rsp",
    "spatz_tcdm_req",
    "spatz_tcdm_stall",
    "idma_busy",
    "idma_start",
    "idma_done",
    "idma_tcdm_req",
    "idma_tcdm_stall",
    "afu_done",
    "afu_tcdm_req",
    "afu_tcdm_stall",
    "sys_compute",
    "sys_weight_load",
    "sys_ofm_valid",
    "sys_ifm_req",
    "sys_ifm_stall",
    "sys_ofm_req",
    "sys_ofm_stall",
    "tcdm_req",
    "tcdm_gnt",
    "tcdm_stall",
    "tcdm_bank_req",
    "tcdm_read_req",
    "tcdm_write_req",
    "command_active_cycles",
    "command_begin",
    "command_end",
    "phase_invocation_cycles",
    "phase_model_cycles",
    "phase_bindings_cycles",
    "phase_validate_cycles",
    "phase_fetch_cycles",
    "phase_execute_cycles",
    "phase_barrier_cycles",
    "phase_complete_cycles",
    "phase_fail_cycles",
    "dma_load_busy_cycles",
    "dma_store_busy_cycles",
    "dma_both_busy_cycles",
    "dma_load_start",
    "dma_load_done",
    "dma_store_start",
    "dma_store_done",
    "dma_load_queue_occupancy",
    "dma_store_queue_occupancy",
    "dma_load_queue_peak",
    "dma_store_queue_peak",
    "axi_ar_accept",
    "axi_r_beat",
    "axi_aw_accept",
    "axi_w_beat",
    "axi_b_accept",
    "axi_read_bytes",
    "axi_write_bytes",
    "axi_ar_blocked_cycles",
    "axi_r_blocked_cycles",
    "axi_aw_blocked_cycles",
    "axi_w_blocked_cycles",
    "axi_read_outstanding_cycles",
    "axi_write_outstanding_cycles",
    "axi_read_outstanding_peak",
    "axi_write_outstanding_peak",
    "axi_read_latency_sum",
    "axi_write_latency_sum",
    "axi_read_latency_max",
    "axi_write_latency_max",
    "sys_active_cycles",
    "sys_load_state_cycles",
    "sys_compute_state_cycles",
    "sys_drain_state_cycles",
    "sys_done_state_cycles",
    "sys_array_useful_cycles",
    "sys_weight_useful_cycles",
    "sys_ofm_fire",
    "sys_ofm_backpressure_cycles",
    "sys_ifm_accept",
    "sys_ifm_blocked_cycles",
    "sys_weight_accept",
    "sys_weight_blocked_cycles",
    "sys_rhs_accept",
    "sys_rhs_blocked_cycles",
    "sys_ofm_accept",
    "sys_ofm_blocked_cycles",
    "linebuf_active_cycles",
    "linebuf_prefetch_cycles",
    "sys_binary_active_cycles",
    "sys_start",
    "sys_done",
    "afu_active_cycles",
    "afu_start",
    "afu_done_pulse",
    "afu_read_state_cycles",
    "afu_process_state_cycles",
    "afu_dfl_state_cycles",
    "afu_class_state_cycles",
    "afu_gap_state_cycles",
    "afu_done_state_cycles",
    "afu_backend_drain_cycles",
    "afu_lhs_consume",
    "afu_rhs_consume",
    "afu_result_produce",
    "afu_input_wait_cycles",
    "afu_rhs_wait_cycles",
    "afu_output_stall_cycles",
    "spatz_active_cycles",
    "spatz_issue_accept",
    "spatz_response_accept",
    "spatz_tcdm_accept",
    "spatz_tcdm_blocked_cycles",
    "tcdm_accept",
    "tcdm_blocked_cycles",
    "tcdm_bank_active",
    "tcdm_bank_conflict_cycles",
    "tcdm_conflicting_banks",
    "tcdm_read_accept",
    "tcdm_write_accept",
    "tcdm_read_bytes",
    "tcdm_write_bytes",
    "compute_dma_overlap_cycles",
    "command_engine_idle_cycles",
    "drain_idle_state_cycles",
    "drain_accum_read_state_cycles",
    "drain_accum_write_state_cycles",
    "drain_accum_requant_state_cycles",
    "linebuf_idle_state_cycles",
    "linebuf_ensure_state_cycles",
    "linebuf_fill_req0_state_cycles",
    "linebuf_fill_req1_state_cycles",
    "linebuf_fill_drain_state_cycles",
    "linebuf_window_req_state_cycles",
    "linebuf_window_wait_state_cycles",
    "linebuf_stream_prime_state_cycles",
    "linebuf_stream_emit_state_cycles",
    "linebuf_bypass_prep_state_cycles",
    "linebuf_bypass_req0_state_cycles",
    "linebuf_bypass_wait0_state_cycles",
    "linebuf_bypass_req1_state_cycles",
    "linebuf_bypass_wait1_state_cycles",
    "linebuf_stream_done_state_cycles",
    "linebuf_fetch_main_req0_state_cycles",
    "linebuf_fetch_main_req1_state_cycles",
    "linebuf_fetch_main_drain_state_cycles",
    "linebuf_fetch_main_idle_state_cycles",
    "linebuf_fetch_bg_idle_state_cycles",
    "linebuf_fetch_bg_scan_state_cycles",
    "linebuf_fetch_bg_req0_state_cycles",
    "linebuf_fetch_bg_req1_state_cycles",
    "linebuf_fetch_bg_drain_state_cycles",
    "linebuf_bypass_idle_engine_state_cycles",
    "linebuf_bypass_prep_engine_state_cycles",
    "linebuf_bypass_req0_engine_state_cycles",
    "linebuf_bypass_wait0_engine_state_cycles",
    "linebuf_bypass_req1_engine_state_cycles",
    "linebuf_bypass_wait1_engine_state_cycles",
    "linebuf_bypass_emit_engine_state_cycles",
]

TCDM_NUM_BANKS = 16
TCDM_BANK_WORDS = 1024
TCDM_WORD_BYTES = 32
TCDM_TOTAL_BYTES = TCDM_NUM_BANKS * TCDM_BANK_WORDS * TCDM_WORD_BYTES
NPU_DTCM_BASE = 0x10008000
NPU_CMD_CTRL_BASE = 0x20005000
NPU_CMD_L2_BASE = NPU_CMD_CTRL_BASE + 0x00
NPU_CMD_TOTAL_BYTES = NPU_CMD_CTRL_BASE + 0x04
NPU_CMD_TCDM_BASE_REG = NPU_CMD_CTRL_BASE + 0x08
NPU_CMD_TCDM_BYTES = NPU_CMD_CTRL_BASE + 0x0C
NPU_CMD_START = NPU_CMD_CTRL_BASE + 0x10
NPU_CMD_STATUS = NPU_CMD_CTRL_BASE + 0x14
NPU_CMD_FAIL_CODE = NPU_CMD_CTRL_BASE + 0x18
NPU_CMD_FAIL_PTR = NPU_CMD_CTRL_BASE + 0x1C
NPU_CMD_DONE_COUNT = NPU_CMD_CTRL_BASE + 0x20
NPU_CMD_TCDM_BASE = 0x1017F000
NPU_CMD_TCDM_SIZE = 0x00001000
NPU_CMD_STATUS_IDLE = 0
NPU_CMD_STATUS_LOADING = 1
NPU_CMD_STATUS_RUNNING = 2
NPU_CMD_STATUS_PASS = 3
NPU_CMD_STATUS_FAIL = 4


async def reset_dut(dut):
    dut.rst_ni.value = 0
    if hasattr(dut, "fetch_enable_i"):
        dut.fetch_enable_i.value = 0
    dut.backdoor_we_i.value = 0
    if hasattr(dut, "backdoor_block_toggle_i"):
        dut.backdoor_block_bytes_i.value = 0
        dut.backdoor_block_addr_i.value = 0
        dut.backdoor_block_data_i.value = 0
        dut.backdoor_block_toggle_i.value = 0
    await Timer(20, unit="ns")
    dut.rst_ni.value = 1
    await Timer(20, unit="ns")


async def hold_reset(dut):
    dut.rst_ni.value = 0
    if hasattr(dut, "fetch_enable_i"):
        dut.fetch_enable_i.value = 0
    dut.backdoor_we_i.value = 0
    if hasattr(dut, "backdoor_block_toggle_i"):
        dut.backdoor_block_bytes_i.value = 0
        dut.backdoor_block_addr_i.value = 0
        dut.backdoor_block_data_i.value = 0
        dut.backdoor_block_toggle_i.value = 0
    await Timer(20, unit="ns")


async def release_reset(dut):
    dut.rst_ni.value = 1
    await Timer(20, unit="ns")


async def load_firmware_axi(axi_master, filename, base_addr=ITCM_BASE, width=4):
    with open(filename, "rb") as firmware_file:
        firmware = firmware_file.read()

    if len(firmware) % width != 0:
        firmware += b"\x00" * (width - (len(firmware) % width))

    # Reject the entire raw image before touching hardware. A BIN spanning
    # I-TCM and D-TCM must use the segment-aware ELF loader instead.
    if base_addr < ITCM_BASE or base_addr + len(firmware) > ITCM_BASE + TCM_SIZE_BYTES:
        raise AssertionError("AXI boot image exceeds I-TCM; use the ELF loader for multi-segment firmware")

    for offset in range(0, len(firmware), width):
        addr = base_addr + offset
        if not (ITCM_BASE <= addr < ITCM_BASE + TCM_SIZE_BYTES):
            raise AssertionError(f"AXI boot image exceeds I-TCM at 0x{addr:08x}")
        await axi_master.write(base_addr + offset, firmware[offset : offset + width])


def _is_tcm_addr(addr):
    return (
        ITCM_BASE <= addr < ITCM_BASE + TCM_SIZE_BYTES
        or NPU_DTCM_BASE <= addr < NPU_DTCM_BASE + TCM_SIZE_BYTES
    )


def _write_dtcm_bytes(dut, addr, data, width=4):
    if addr < NPU_DTCM_BASE:
        raise AssertionError(f"D-TCM write below base at 0x{addr:08x}")
    if len(data) % width != 0:
        data += b"\x00" * (width - (len(data) % width))
    for offset in range(0, len(data), width):
        index = (addr + offset - NPU_DTCM_BASE) >> 2
        word = int.from_bytes(data[offset : offset + width], "little")
        dut.u_npu_cluster.u_sram_d_tcm.mem[index].value = word


async def load_firmware_elf_axi(dut, axi_master, filename, width=4):
    with open(filename, "rb") as firmware_file:
        elf = firmware_file.read()

    if len(elf) < 52 or elf[:4] != b"\x7fELF" or elf[4] != 1 or elf[5] != 1:
        raise AssertionError("expected little-endian ELF32 firmware")

    header = struct.unpack_from("<16sHHIIIIIHHHHHH", elf, 0)
    e_phoff = header[5]
    e_phentsize = header[9]
    e_phnum = header[10]
    if e_phentsize < 32:
        raise AssertionError("unsupported ELF program header size")

    for ph_idx in range(e_phnum):
        ph_off = e_phoff + ph_idx * e_phentsize
        if ph_off + 32 > len(elf):
            raise AssertionError("ELF program header exceeds file size")
        p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, _p_flags, _p_align = struct.unpack_from(
            "<IIIIIIII", elf, ph_off
        )
        if p_type != 1 or p_memsz == 0:
            continue

        addr = p_paddr or p_vaddr
        end_addr = addr + p_memsz
        if not _is_tcm_addr(addr) or not _is_tcm_addr(end_addr - 1):
            raise AssertionError(f"ELF load segment outside TCM at 0x{addr:08x}")
        if p_offset + p_filesz > len(elf):
            raise AssertionError("ELF load segment exceeds file size")

        payload = elf[p_offset : p_offset + p_filesz]
        if p_memsz > p_filesz:
            payload += b"\x00" * (p_memsz - p_filesz)
        if len(payload) % width != 0:
            payload += b"\x00" * (width - (len(payload) % width))

        if ITCM_BASE <= addr < ITCM_BASE + TCM_SIZE_BYTES:
            for offset in range(0, len(payload), width):
                await axi_master.write(addr + offset, payload[offset : offset + width])
        else:
            _write_dtcm_bytes(dut, addr, payload, width)

async def _axi_read32(axi_master, addr):
    resp = await axi_master.read(addr, 4)
    data = resp.data if hasattr(resp, "data") else resp
    return int.from_bytes(bytes(data), "little")


async def _axi_write32(axi_master, addr, value):
    await axi_master.write(addr, int(value & 0xFFFFFFFF).to_bytes(4, "little"))


async def program_command_queue(axi_master, l2_base, total_bytes, tcdm_base=NPU_CMD_TCDM_BASE, tcdm_size=NPU_CMD_TCDM_SIZE):
    await _axi_write32(axi_master, NPU_CMD_L2_BASE, l2_base)
    await _axi_write32(axi_master, NPU_CMD_TOTAL_BYTES, total_bytes)
    await _axi_write32(axi_master, NPU_CMD_TCDM_BASE_REG, tcdm_base)
    await _axi_write32(axi_master, NPU_CMD_TCDM_BYTES, tcdm_size)
    await _axi_write32(axi_master, NPU_CMD_FAIL_CODE, 0)
    await _axi_write32(axi_master, NPU_CMD_FAIL_PTR, 0)
    await _axi_write32(axi_master, NPU_CMD_DONE_COUNT, 0)
    await _axi_write32(axi_master, NPU_CMD_STATUS, 0)
    await _axi_write32(axi_master, NPU_CMD_START, 1)


async def pmu_start(axi_master, command_id=None):
    await _axi_write32(axi_master, PMU_CTRL, PMU_CTRL_CLEAR)
    await _axi_write32(axi_master, PMU_FILTER_CONTEXT, command_id or 0)
    await _axi_write32(axi_master, PMU_FILTER_CTRL, int(command_id is not None))
    await _axi_write32(axi_master, PMU_CTRL, PMU_CTRL_ENABLE)


async def pmu_snapshot_report(axi_master):
    await _axi_write32(axi_master, PMU_CTRL, PMU_CTRL_ENABLE | PMU_CTRL_SNAPSHOT)
    await _axi_write32(axi_master, PMU_CTRL, 0)

    hardware_num_counters = await _axi_read32(axi_master, PMU_NUM_COUNTERS)
    num_counters = min(hardware_num_counters, len(PMU_COUNTER_NAMES))
    counters = {}
    for counter_id in range(num_counters):
        lo = await _axi_read32(axi_master, PMU_COUNTER_BASE + counter_id * 8)
        hi = await _axi_read32(axi_master, PMU_COUNTER_BASE + counter_id * 8 + 4)
        counters[PMU_COUNTER_NAMES[counter_id]] = (hi << 32) | lo

    overflow_words = [
        await _axi_read32(axi_master, address)
        for address in (
            PMU_STATUS,
            PMU_STATUS1,
            PMU_STATUS2,
            PMU_STATUS3,
            PMU_STATUS4,
            PMU_STATUS5,
        )
    ]
    counters["overflow_status"] = sum(word << (32 * index) for index, word in enumerate(overflow_words))
    counters["num_counters"] = hardware_num_counters
    counters["pmu_version"] = await _axi_read32(axi_master, PMU_VERSION)
    counters["filter_context"] = await _axi_read32(axi_master, PMU_FILTER_CONTEXT)
    counters["current_context"] = await _axi_read32(axi_master, PMU_CURRENT_CONTEXT)
    counters["current_phase"] = await _axi_read32(axi_master, PMU_CURRENT_PHASE)
    return counters


def format_pmu_report(counters):
    cycles = counters.get("cycle", 0)

    def pct(name):
        return (100.0 * counters.get(name, 0) / cycles) if cycles else 0.0

    def ratio(numerator, denominator):
        divisor = counters.get(denominator, 0)
        return (counters.get(numerator, 0) / divisor) if divisor else 0.0

    def states(entries):
        return " ".join(f"{label}={counters.get(name, 0)}" for label, name in entries)

    lines = [
        "PMU performance report:",
        f"  cycles={cycles}",
        (
            "  snitch: "
            f"instr={counters.get('snitch_retired_instr', 0)} "
            f"load={counters.get('snitch_retired_load', 0)} "
            f"tcdm_req={counters.get('snitch_tcdm_req', 0)} "
            f"stall={counters.get('snitch_tcdm_stall', 0)}"
        ),
        (
            "  systolic: "
            f"active={counters.get('sys_active_cycles', 0)} "
            f"useful={counters.get('sys_array_useful_cycles', 0)} ({pct('sys_array_useful_cycles'):.2f}%) "
            f"ifm={counters.get('sys_ifm_accept', 0)} "
            f"ofm={counters.get('sys_ofm_accept', 0)} "
            f"blocked={counters.get('sys_ifm_blocked_cycles', 0) + counters.get('sys_ofm_blocked_cycles', 0)}"
        ),
        "  systolic states: " + states(
            (
                ("load", "sys_load_state_cycles"),
                ("compute", "sys_compute_state_cycles"),
                ("drain", "sys_drain_state_cycles"),
                ("done", "sys_done_state_cycles"),
            )
        ),
        "  drain states: " + states(
            (
                ("idle", "drain_idle_state_cycles"),
                ("read", "drain_accum_read_state_cycles"),
                ("write", "drain_accum_write_state_cycles"),
                ("requant", "drain_accum_requant_state_cycles"),
            )
        ),
        "  linebuf states: " + states(
            (
                ("idle", "linebuf_idle_state_cycles"),
                ("ensure", "linebuf_ensure_state_cycles"),
                ("fill_req0", "linebuf_fill_req0_state_cycles"),
                ("fill_req1", "linebuf_fill_req1_state_cycles"),
                ("fill_drain", "linebuf_fill_drain_state_cycles"),
                ("window_req", "linebuf_window_req_state_cycles"),
                ("window_wait", "linebuf_window_wait_state_cycles"),
                ("stream_prime", "linebuf_stream_prime_state_cycles"),
                ("stream_emit", "linebuf_stream_emit_state_cycles"),
                ("bypass_prep", "linebuf_bypass_prep_state_cycles"),
                ("bypass_req0", "linebuf_bypass_req0_state_cycles"),
                ("bypass_wait0", "linebuf_bypass_wait0_state_cycles"),
                ("bypass_req1", "linebuf_bypass_req1_state_cycles"),
                ("bypass_wait1", "linebuf_bypass_wait1_state_cycles"),
                ("stream_done", "linebuf_stream_done_state_cycles"),
            )
        ),
        "  linebuf fetch-main states: " + states(
            (
                ("req0", "linebuf_fetch_main_req0_state_cycles"),
                ("req1", "linebuf_fetch_main_req1_state_cycles"),
                ("drain", "linebuf_fetch_main_drain_state_cycles"),
                ("idle", "linebuf_fetch_main_idle_state_cycles"),
            )
        ),
        "  linebuf background states: " + states(
            (
                ("idle", "linebuf_fetch_bg_idle_state_cycles"),
                ("scan", "linebuf_fetch_bg_scan_state_cycles"),
                ("req0", "linebuf_fetch_bg_req0_state_cycles"),
                ("req1", "linebuf_fetch_bg_req1_state_cycles"),
                ("drain", "linebuf_fetch_bg_drain_state_cycles"),
            )
        ),
        "  linebuf bypass-engine states: " + states(
            (
                ("idle", "linebuf_bypass_idle_engine_state_cycles"),
                ("prep", "linebuf_bypass_prep_engine_state_cycles"),
                ("req0", "linebuf_bypass_req0_engine_state_cycles"),
                ("wait0", "linebuf_bypass_wait0_engine_state_cycles"),
                ("req1", "linebuf_bypass_req1_engine_state_cycles"),
                ("wait1", "linebuf_bypass_wait1_engine_state_cycles"),
                ("emit", "linebuf_bypass_emit_engine_state_cycles"),
            )
        ),
        (
            "  spatz: "
            f"active={counters.get('spatz_active_cycles', 0)} "
            f"issue={counters.get('spatz_issue_accept', 0)} "
            f"rsp={counters.get('spatz_response_accept', 0)} "
            f"tcdm={counters.get('spatz_tcdm_accept', 0)} "
            f"blocked={counters.get('spatz_tcdm_blocked_cycles', 0)}"
        ),
        (
            "  idma: "
            f"load_busy={counters.get('dma_load_busy_cycles', 0)} "
            f"store_busy={counters.get('dma_store_busy_cycles', 0)} "
            f"overlap={counters.get('dma_both_busy_cycles', 0)} "
            f"read={counters.get('axi_read_bytes', 0)}B "
            f"write={counters.get('axi_write_bytes', 0)}B"
        ),
        (
            "  axi: "
            f"read_latency_avg/max={ratio('axi_read_latency_sum', 'axi_ar_accept'):.2f}/"
            f"{counters.get('axi_read_latency_max', 0)} "
            f"write_latency_avg/max={ratio('axi_write_latency_sum', 'axi_b_accept'):.2f}/"
            f"{counters.get('axi_write_latency_max', 0)} "
            f"outstanding_peak={counters.get('axi_read_outstanding_peak', 0)}/"
            f"{counters.get('axi_write_outstanding_peak', 0)}"
        ),
        (
            "  afu: "
            f"active={counters.get('afu_active_cycles', 0)} "
            f"start={counters.get('afu_start', 0)} "
            f"done={counters.get('afu_done_pulse', 0)} "
            f"input_wait={counters.get('afu_input_wait_cycles', 0)} "
            f"output_stall={counters.get('afu_output_stall_cycles', 0)}"
        ),
        (
            "  tcdm: "
            f"accept={counters.get('tcdm_accept', 0)} "
            f"blocked={counters.get('tcdm_blocked_cycles', 0)} "
            f"conflict_cycles={counters.get('tcdm_bank_conflict_cycles', 0)} "
            f"read={counters.get('tcdm_read_bytes', 0)}B "
            f"write={counters.get('tcdm_write_bytes', 0)}B"
        ),
        (
            "  overlap/control: "
            f"compute_dma={counters.get('compute_dma_overlap_cycles', 0)} "
            f"command_idle={counters.get('command_engine_idle_cycles', 0)} "
            f"commands={counters.get('command_begin', 0)}/{counters.get('command_end', 0)}"
        ),
    ]
    if counters.get("overflow_status", 0):
        lines.append(f"  overflow_status=0x{counters['overflow_status']:08x}")
    return "\n".join(lines)


def pmu_direct_snapshot(dut):
    """Read live PMU counters without perturbing simulated software."""
    pmu = dut.u_npu_cluster.u_pmu
    counters = {}
    for counter_id, name in enumerate(PMU_COUNTER_NAMES):
        counter = getattr(getattr(pmu, f"gen_counters[{counter_id}]"), "u_counter")
        value = counter.counter_q.value
        counters[name] = value.to_unsigned() if value.is_resolvable else 0
    return counters


def pmu_counter_delta(end, start):
    return {
        name: end.get(name, 0) - start.get(name, 0)
        for name in PMU_COUNTER_NAMES
    }


def _dtcm_word_handle(dut, addr):
    index = (addr - NPU_DTCM_BASE) >> 2
    return dut.u_npu_cluster.u_sram_d_tcm.mem[index]


def _dtcm_header(dut, addr):
    return b"".join(
        read_dtcm_word(dut, addr + offset).to_bytes(4, "little")
        for offset in range(0, 16, 4)
    )


async def _emit_command_sample(callback, index, counters):
    if callback is not None:
        result = callback(index, counters)
        if inspect.isawaitable(result):
            await result


async def monitor_command_buffer_pmu(
    dut,
    command_buffer_address,
    command_headers,
    sample_callback=None,
    command_pointer_address=None,
):
    """Return PMU deltas for successive streamed ABI commands.

    Prefer the explicit firmware PMU context begin/end pulses.  Unlike watching
    the reused D-TCM command buffer, these pulses cannot skip short commands
    when all four header words change in one simulator time step.  The callback
    runs after every command and can therefore flush live CSV output before a
    segment completes. Async callbacks may also read the existing L2 backdoor;
    they must finish before the next context begins (sequence checks reject a
    missed command). Keep the D-TCM watcher as a compatibility fallback for
    testbenches without command-context signals.
    """
    headers = [bytes(header) for header in command_headers]
    if len(headers) < 2 or any(len(header) != 16 for header in headers):
        raise ValueError("command PMU tracing requires command headers plus END")

    cluster = dut.u_npu_cluster
    context_begin = getattr(cluster, "pmu_context_begin", None)
    context_end = getattr(cluster, "pmu_context_end", None)
    context_id = getattr(cluster, "pmu_context_id", None)
    if context_begin is not None and context_end is not None and context_id is not None:
        deltas = []
        for expected_id in range(len(headers) - 1):
            await RisingEdge(context_begin)
            await ReadOnly()
            actual_id = int(context_id.value)
            if actual_id != expected_id:
                raise AssertionError(
                    f"PMU command begin sequence mismatch: expected {expected_id}, "
                    f"observed {actual_id}"
                )
            begin_sample = pmu_direct_snapshot(dut)

            await RisingEdge(context_end)
            await ReadOnly()
            actual_id = int(context_id.value)
            if actual_id != expected_id:
                raise AssertionError(
                    f"PMU command end sequence mismatch: expected {expected_id}, "
                    f"observed {actual_id}"
                )
            delta = pmu_counter_delta(pmu_direct_snapshot(dut), begin_sample)
            deltas.append(delta)
            await _emit_command_sample(sample_callback, expected_id, delta)
        return deltas

    samples = []
    deltas = []
    for expected in headers:
        while True:
            address = command_buffer_address
            header_words = []
            if command_pointer_address is not None:
                pointer = _dtcm_word_handle(dut, command_pointer_address)
                header_words.append(pointer)
                address = read_dtcm_word(dut, command_pointer_address)
            if address:
                if _dtcm_header(dut, address) == expected:
                    break
                header_words.extend(
                    _dtcm_word_handle(dut, address + offset) for offset in range(0, 16, 4)
                )
            await First(*(ValueChange(word) for word in header_words))
            await ReadOnly()
        samples.append(pmu_direct_snapshot(dut))
        if len(samples) > 1:
            delta = pmu_counter_delta(samples[-1], samples[-2])
            deltas.append(delta)
            await _emit_command_sample(sample_callback, len(deltas) - 1, delta)

    return deltas


async def release_fetch(dut, axi_master=None, enable_pmu=True, pmu_command_id=None):
    if axi_master is not None and enable_pmu:
        await pmu_start(axi_master, command_id=pmu_command_id)
    dut.fetch_enable_i.value = 1
    await Timer(1, unit="ns")


async def wait_for_host_irq(
    dut,
    timeout_cycles=50000,
    axi_master=None,
    report_name=None,
    progress_callback=None,
):
    # Cluster tests use a 1 ns clock.  Waiting on each edge from Python makes
    # full-model simulations needlessly slow, so let the simulator run until
    # IRQ or the next progress interval instead.
    progress_interval_cycles = 100_000
    elapsed_cycles = 0
    while elapsed_cycles < timeout_cycles:
        irq_value = dut.irq_o.value
        if irq_value.is_resolvable and int(irq_value) == 1:
            if axi_master is not None:
                report = await pmu_snapshot_report(axi_master)
                prefix = f"{report_name}: " if report_name else ""
                dut._log.info("%s%s", prefix, format_pmu_report(report))
                return report
            return None
        interval_cycles = min(
            progress_interval_cycles,
            timeout_cycles - elapsed_cycles,
        )
        try:
            await with_timeout(
                RisingEdge(dut.irq_o),
                interval_cycles,
                timeout_unit="ns",
            )
        except SimTimeoutError:
            elapsed_cycles += interval_cycles
            progress = progress_callback() if progress_callback is not None else ""
            dut._log.info(
                f"waiting for host irq: {elapsed_cycles:,}/{timeout_cycles:,} cycles"
                f"{'; ' + progress if progress else ''}"
            )
    raise AssertionError("timeout waiting for host irq")

async def write_l2_bytes(dut, base_addr, data):
    if hasattr(dut, "backdoor_block_toggle_i"):
        dut.backdoor_we_i.value = 0
        toggle = dut.backdoor_block_toggle_i.value
        toggle_value = int(toggle) if toggle.is_resolvable else 0
        for offset in range(0, len(data), 32):
            block = bytes(data[offset : offset + 32])
            dut.backdoor_block_addr_i.value = base_addr + offset
            dut.backdoor_block_bytes_i.value = len(block)
            dut.backdoor_block_data_i.value = int.from_bytes(block, "little")
            toggle_value ^= 1
            dut.backdoor_block_toggle_i.value = toggle_value
            await Timer(1, unit="ps")
        dut.backdoor_block_bytes_i.value = 0
        return

    dut.backdoor_we_i.value = 0
    await RisingEdge(dut.clk_i)
    for offset, byte_val in enumerate(data):
        dut.backdoor_we_i.value = 1
        dut.backdoor_addr_i.value = base_addr + offset
        dut.backdoor_data_i.value = byte_val & 0xFF
        await RisingEdge(dut.clk_i)
    dut.backdoor_we_i.value = 0
    await RisingEdge(dut.clk_i)


async def read_l2_bytes(dut, base_addr, length):
    if hasattr(dut, "backdoor_block_rdata_o"):
        data = bytearray()
        dut.backdoor_we_i.value = 0
        for offset in range(0, length, 32):
            block_bytes = min(32, length - offset)
            dut.backdoor_block_addr_i.value = base_addr + offset
            await Timer(1, unit="ps")
            block = dut.backdoor_block_rdata_o.value.to_unsigned().to_bytes(32, "little")
            data.extend(block[:block_bytes])
        return data

    data = []
    dut.backdoor_we_i.value = 0
    await RisingEdge(dut.clk_i)
    for offset in range(length):
        dut.backdoor_addr_i.value = base_addr + offset
        await Timer(1, unit="ps")
        data.append(dut.backdoor_rdata_o.value.to_unsigned() & 0xFF)
        if (offset & 0x1F) == 0x1F:
            await ClockCycles(dut.clk_i, 1)
    return data


def read_tcdm_byte(dut, addr):
    bank_idx = (addr >> 5) % TCDM_NUM_BANKS
    word_index = ((addr >> 5) // TCDM_NUM_BANKS) & (TCDM_BANK_WORDS - 1)
    bit_offset = (addr % TCDM_WORD_BYTES) * 8
    val_256 = dut.u_npu_cluster.gen_sram_banks[bank_idx].u_sram_bank.mem[word_index].value
    if not val_256.is_resolvable:
        return 0
    return (val_256.to_unsigned() >> bit_offset) & 0xFF


def read_tcdm_word32(dut, addr):
    word = 0
    for byte_idx in range(4):
        word |= read_tcdm_byte(dut, addr + byte_idx) << (byte_idx * 8)
    return word


def read_tcdm_bytes(dut):
    """Read the complete interleaved TCDM image in logical address order."""
    data = bytearray(TCDM_TOTAL_BYTES)
    for bank_idx in range(TCDM_NUM_BANKS):
        memory = dut.u_npu_cluster.gen_sram_banks[bank_idx].u_sram_bank.mem
        for word_index in range(TCDM_BANK_WORDS):
            value = memory[word_index].value
            if not value.is_resolvable:
                raise AssertionError(
                    f"unresolved TCDM word bank={bank_idx} word={word_index}"
                )
            logical_word = word_index * TCDM_NUM_BANKS + bank_idx
            offset = logical_word * TCDM_WORD_BYTES
            data[offset : offset + TCDM_WORD_BYTES] = value.to_unsigned().to_bytes(
                TCDM_WORD_BYTES, "little"
            )
    return bytes(data)


def write_tcdm_bytes(dut, data):
    """Restore a complete logical-address TCDM image through VPI deposits."""
    if len(data) != TCDM_TOTAL_BYTES:
        raise ValueError(
            f"TCDM snapshot has {len(data)} bytes, expected {TCDM_TOTAL_BYTES}"
        )
    for bank_idx in range(TCDM_NUM_BANKS):
        memory = dut.u_npu_cluster.gen_sram_banks[bank_idx].u_sram_bank.mem
        for word_index in range(TCDM_BANK_WORDS):
            logical_word = word_index * TCDM_NUM_BANKS + bank_idx
            offset = logical_word * TCDM_WORD_BYTES
            memory[word_index].value = int.from_bytes(
                data[offset : offset + TCDM_WORD_BYTES], "little"
            )


def read_dtcm_word(dut, addr):
    index = (addr - NPU_DTCM_BASE) >> 2
    value = dut.u_npu_cluster.u_sram_d_tcm.mem[index].value
    return value.to_unsigned() if value.is_resolvable else 0


def firmware_path(test_file, relative_fw):
    return os.path.join(os.path.dirname(test_file), "../../../../../", relative_fw)
