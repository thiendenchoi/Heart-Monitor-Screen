import os

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
from cocotbext.axi import AxiLiteBus, AxiLiteMaster

from systolic_independent_common import signal_to_int

from npu_test_utils import (
    firmware_path,
    load_firmware_axi,
    read_l2_bytes,
    release_fetch,
    reset_dut,
    wait_for_host_irq,
    write_l2_bytes,
)


L2_CONV1_INPUT = 0x80000000
L2_CONV1_WEIGHT = 0x80002000
L2_CONV1_OUT = 0x80010000
L2_CONV1_STATS = 0x80018000
L2_CONV3_INPUT = 0x80020000
L2_CONV3_WEIGHT = 0x80022000
L2_CONV3_OUT = 0x80030000
L2_CONV3_STATS = 0x80038000
L2_CONV1_C32_INPUT = 0x80040000
L2_CONV1_C32_WEIGHT = 0x80044000
L2_CONV1_C32_OUT = 0x80050000
L2_CONV1_C32_STATS = 0x80058000
L2_CONV1_C64_INPUT = 0x80060000
L2_CONV1_C64_WEIGHT = 0x80068000
L2_CONV1_C64_OUT = 0x80070000
L2_CONV1_C64_STATS = 0x80078000
L2_CONV_PERF_CONFIG = 0x8007F000
L2_P3_BASE = 0x80080000
P3_CASE_STRIDE = 0x00040000
P3_C120_C32B_INPUT_ADDR = 0x81300000
P3_C120_C32B_WEIGHT_ADDR = 0x81410000
P3_C120_C32B_OUT_ADDR = 0x81420000
P3_C120_C32B_STATS_ADDR = 0x81540000
P3_C32T_INPUT_ADDR = 0x81600000
P3_C32T_WEIGHT_ADDR = 0x81610000
P3_C32T_OUT_ADDR = 0x81620000
P3_C32T_STATS_ADDR = 0x81630000
P3_H = 4
P3_W = 4
P3_C120_H = 16
P3_C120_W = 16
P3_C32T_H = 32
P3_C32T_W = 32
CONV1_H = 4
CONV1_W = 5
CONV1_C = 33
CONV3_H = 5
CONV3_W = 5
CONV3_C = 3
OC = 32
K_TILE = 32
STATUS_BASE = 0x10008000

P3_CASE_IC1 = 0
P3_CASE_IC3 = 1
P3_CASE_IC31 = 2
P3_CASE_OC64 = 3
P3_CASE_3X3_P0_C32 = 4
P3_CASE_3X3_P1_C32 = 5
P3_CASE_5X5_P2_C3 = 6
P3_CASE_7X7_P3_C1 = 7
P3_CASE_1X3_C3 = 8
P3_CASE_3X1_C3 = 9
P3_CASE_1X5_C3 = 10
P3_CASE_5X1_C3 = 11
P3_CASE_3X3_S2_C3 = 12
P3_CASE_3X3_C1 = 13
P3_CASE_3X3_C5 = 14
P3_CASE_REQUANT = 15
P3_CASE_YOLO_RGB_TCDM_SPATZ = 16
P3_CASE_LINEBUF_3X3_C3 = 17
P3_CASE_LINEBUF_KGEN_3X3_C32 = 18
P3_CASE_LINEBUF_KGEN_3X3_C96 = 19
# Case ID 20 was the raw IC120 slow-path regression. Keep the ID reserved; use
# case 22 for production C32-padded IC120 coverage.
P3_CASE_LINEBUF_KGEN_3X3_C65 = 21
P3_CASE_LINEBUF_3X3_C120_C32B = 22
P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT = 23

YOLO_RGB_H = 64
YOLO_RGB_W = 64
YOLO_RGB_C = 3
YOLO_RGB_OH = 32
YOLO_RGB_OW = 32
YOLO_RGB_TILE_OH = 8

SYSTOLIC_STATE_NAMES = {
    0: "IDLE",
    1: "LOAD_WEIGHTS",
    2: "COMPUTE",
    3: "WAIT_DRAIN",
    4: "DONE",
}

DRAIN_STATE_NAMES = {
    0: "DRAIN_IDLE",
    1: "DRAIN_ACCUM_READ",
    2: "DRAIN_ACCUM_WRITE",
    3: "DRAIN_ACCUM_REQUANT",
}

LINEBUF_STATE_NAMES = {
    0: "CH_IDLE",
    1: "CH_ENSURE",
    2: "CH_FILL_REQ0",
    3: "CH_FILL_REQ1",
    4: "CH_FILL_DRAIN",
    5: "CH_WINDOW_REQ",
    6: "CH_WINDOW_WAIT",
    7: "CH_STREAM_PRIME",
    8: "CH_STREAM_EMIT",
    9: "CH_BYPASS_PREP",
    10: "CH_BYPASS_REQ0",
    11: "CH_BYPASS_WAIT0",
    12: "CH_BYPASS_REQ1",
    13: "CH_BYPASS_WAIT1",
    14: "CH_STREAM_DONE",
}

LINEBUF_FETCH_MAIN_STATE_NAMES = {0: "MAIN_REQ0", 1: "MAIN_REQ1", 2: "MAIN_DRAIN", 3: "MAIN_IDLE"}
LINEBUF_FETCH_BACKGROUND_STATE_NAMES = {
    0: "BG_IDLE",
    1: "BG_SCAN",
    2: "BG_REQ0",
    3: "BG_REQ1",
    4: "BG_DRAIN",
}
LINEBUF_BYPASS_STATE_NAMES = {
    0: "BYPASS_IDLE",
    1: "BYPASS_PREP",
    2: "BYPASS_REQ0",
    3: "BYPASS_WAIT0",
    4: "BYPASS_REQ1",
    5: "BYPASS_WAIT1",
    6: "BYPASS_EMIT",
}

PMU_DRAIN_STATE_COUNTERS = (
    "drain_idle_state_cycles",
    "drain_accum_read_state_cycles",
    "drain_accum_write_state_cycles",
    "drain_accum_requant_state_cycles",
)
PMU_LINEBUF_STATE_COUNTERS = tuple(
    f"linebuf_{state}_state_cycles"
    for state in (
        "idle", "ensure", "fill_req0", "fill_req1", "fill_drain",
        "window_req", "window_wait", "stream_prime", "stream_emit",
        "bypass_prep", "bypass_req0", "bypass_wait0", "bypass_req1",
        "bypass_wait1", "stream_done",
    )
)
PMU_LINEBUF_FETCH_MAIN_STATE_COUNTERS = tuple(
    f"linebuf_fetch_main_{state}_state_cycles" for state in ("req0", "req1", "drain", "idle")
)
PMU_LINEBUF_FETCH_BACKGROUND_STATE_COUNTERS = tuple(
    f"linebuf_fetch_bg_{state}_state_cycles" for state in ("idle", "scan", "req0", "req1", "drain")
)
PMU_LINEBUF_BYPASS_STATE_COUNTERS = tuple(
    f"linebuf_bypass_{state}_engine_state_cycles"
    for state in ("idle", "prep", "req0", "wait0", "req1", "wait1", "emit")
)

P3_CASES = {
    P3_CASE_IC1: ("conv1x1 IC1", 4, 4, 1, 4, 4, 1, 1, 1, 1, 0, 0, 32, 1, 1, 0, False),
    P3_CASE_IC3: ("conv1x1 IC3", 4, 4, 3, 4, 4, 1, 1, 1, 1, 0, 0, 32, 1, 1, 0, False),
    P3_CASE_IC31: ("conv1x1 IC31", 4, 4, 31, 4, 4, 1, 1, 1, 1, 0, 0, 32, 1, 1, 0, False),
    P3_CASE_OC64: ("conv1x1 IC33 OC64", 4, 4, 33, 4, 4, 1, 1, 1, 1, 0, 0, 64, 2, 2, 0, False),
    P3_CASE_3X3_P0_C32: ("conv3x3 pad0 IC32", 4, 4, 32, 2, 2, 3, 3, 1, 1, 0, 0, 32, 9, 9, 0, False),
    P3_CASE_3X3_P1_C32: ("conv3x3 pad1 IC32", 4, 4, 32, 4, 4, 3, 3, 1, 1, 1, 1, 32, 9, 9, 0, False),
    P3_CASE_5X5_P2_C3: ("conv5x5 pad2 IC3", 4, 4, 3, 4, 4, 5, 5, 1, 1, 2, 2, 32, 3, 0, 3, False),
    P3_CASE_7X7_P3_C1: ("conv7x7 pad3 IC1", 4, 4, 1, 4, 4, 7, 7, 1, 1, 3, 3, 32, 2, 0, 2, False),
    P3_CASE_1X3_C3: ("conv1x3 IC3", 4, 4, 3, 4, 4, 1, 3, 1, 1, 0, 1, 32, 1, 0, 1, False),
    P3_CASE_3X1_C3: ("conv3x1 IC3", 4, 4, 3, 4, 4, 3, 1, 1, 1, 1, 0, 32, 1, 0, 1, False),
    P3_CASE_1X5_C3: ("conv1x5 IC3", 4, 4, 3, 4, 4, 1, 5, 1, 1, 0, 2, 32, 1, 0, 1, False),
    P3_CASE_5X1_C3: ("conv5x1 IC3", 4, 4, 3, 4, 4, 5, 1, 1, 1, 2, 0, 32, 1, 0, 1, False),
    P3_CASE_3X3_S2_C3: ("conv3x3 stride2 IC3", 4, 4, 3, 2, 2, 3, 3, 2, 2, 1, 1, 32, 1, 0, 1, False),
    P3_CASE_3X3_C1: ("conv3x3 IC1 K9", 4, 4, 1, 4, 4, 3, 3, 1, 1, 1, 1, 32, 1, 0, 1, False),
    P3_CASE_3X3_C5: ("conv3x3 IC5 K45", 4, 4, 5, 4, 4, 3, 3, 1, 1, 1, 1, 32, 2, 0, 2, False),
    P3_CASE_REQUANT: ("conv1x1 IC64 requant", 4, 4, 64, 4, 4, 1, 1, 1, 1, 0, 0, 32, 2, 2, 0, True),
    P3_CASE_YOLO_RGB_TCDM_SPATZ: (
        "yolo RGB 3x3 s2 p1 TCDM Spatz tiled",
        YOLO_RGB_H,
        YOLO_RGB_W,
        YOLO_RGB_C,
        YOLO_RGB_OH,
        YOLO_RGB_OW,
        3,
        3,
        2,
        2,
        1,
        1,
        32,
        YOLO_RGB_OH // YOLO_RGB_TILE_OH,
        0,
        YOLO_RGB_OH // YOLO_RGB_TILE_OH,
        False,
    ),
    P3_CASE_LINEBUF_3X3_C3: ("default linebuffer conv3x3 IC3", 4, 4, 3, 4, 4, 3, 3, 1, 1, 1, 1, 32, 1, 0, 0, False),
    P3_CASE_LINEBUF_KGEN_3X3_C32: (
        "linebuffer KGEN conv3x3 IC32",
        4,
        4,
        32,
        4,
        4,
        3,
        3,
        1,
        1,
        1,
        1,
        32,
        9,
        0,
        0,
        False,
    ),
    P3_CASE_LINEBUF_KGEN_3X3_C96: (
        "linebuffer KGEN conv3x3 IC96",
        4,
        4,
        96,
        4,
        4,
        3,
        3,
        1,
        1,
        1,
        1,
        32,
        27,
        0,
        0,
        False,
    ),
    P3_CASE_LINEBUF_KGEN_3X3_C65: (
        "linebuffer KGEN small-cache conv3x3 IC65",
        4,
        4,
        65,
        4,
        4,
        3,
        3,
        1,
        1,
        1,
        1,
        32,
        19,
        0,
        0,
        False,
    ),
    P3_CASE_LINEBUF_3X3_C120_C32B: (
        "linebuffer C32-blocked full-height conv3x3 IC120",
        P3_C120_H,
        P3_C120_W,
        120,
        P3_C120_H,
        P3_C120_W,
        3,
        3,
        1,
        1,
        1,
        1,
        32,
        36,
        0,
        0,
        False,
    ),
    P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT: (
        "linebuffer 2D tiled conv3x3 IC32 requant",
        P3_C32T_H,
        P3_C32T_W,
        32,
        P3_C32T_H,
        P3_C32T_W,
        3,
        3,
        1,
        1,
        1,
        1,
        32,
        36,
        0,
        0,
        True,
    ),
}

CONV_PERF_GROUP = int(os.environ.get("CONV_PERF_GROUP", "0"))
CONV_PERF_CASE = int(os.environ.get("CONV_PERF_CASE", "-1"))
CONV_PERF_TIMEOUT_CYCLES = int(os.environ.get("CONV_PERF_TIMEOUT_CYCLES", "1600000"))
CONV_PERF_GROUP_ALL = 0
CONV_PERF_GROUP_POINTWISE = 1
CONV_PERF_GROUP_KERNELS = 2
CONV_PERF_GROUP_REQUANT = 3
CONV_PERF_GROUP_YOLO = 4
CONV_PERF_CONFIG_MAGIC = 0x43504647


def legacy_enabled():
    if CONV_PERF_CASE >= 0:
        return False
    return CONV_PERF_GROUP in (CONV_PERF_GROUP_ALL, CONV_PERF_GROUP_POINTWISE)


def p3_case_enabled(case_id):
    if CONV_PERF_CASE >= 0:
        return case_id == CONV_PERF_CASE
    if CONV_PERF_GROUP == CONV_PERF_GROUP_ALL:
        return True
    if CONV_PERF_GROUP == CONV_PERF_GROUP_POINTWISE:
        return case_id <= P3_CASE_OC64
    if CONV_PERF_GROUP == CONV_PERF_GROUP_KERNELS:
        return (P3_CASE_3X3_P0_C32 <= case_id <= P3_CASE_3X3_C5) or (
            case_id == P3_CASE_LINEBUF_KGEN_3X3_C96
            or case_id == P3_CASE_LINEBUF_KGEN_3X3_C65
            or case_id == P3_CASE_LINEBUF_3X3_C120_C32B
            or case_id == P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT
        )
    if CONV_PERF_GROUP == CONV_PERF_GROUP_REQUANT:
        return case_id == P3_CASE_REQUANT
    if CONV_PERF_GROUP == CONV_PERF_GROUP_YOLO:
        return case_id == P3_CASE_YOLO_RGB_TCDM_SPATZ
    return False


def p3_case_is_linebuf(case_id):
    return case_id in {
        P3_CASE_5X5_P2_C3,
        P3_CASE_1X3_C3,
        P3_CASE_3X1_C3,
        P3_CASE_1X5_C3,
        P3_CASE_5X1_C3,
        P3_CASE_3X3_S2_C3,
        P3_CASE_3X3_C1,
        P3_CASE_3X3_C5,
        P3_CASE_YOLO_RGB_TCDM_SPATZ,
        P3_CASE_LINEBUF_3X3_C3,
        P3_CASE_LINEBUF_KGEN_3X3_C32,
        P3_CASE_LINEBUF_KGEN_3X3_C96,
        P3_CASE_LINEBUF_KGEN_3X3_C65,
        P3_CASE_LINEBUF_3X3_C120_C32B,
        P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT,
    }


def read_dtcm_word(dut, addr):
    index = (addr - STATUS_BASE) >> 2
    value = dut.u_npu_cluster.u_sram_d_tcm.mem[index].value
    return value.to_unsigned() if value.is_resolvable else 0


def bytes_to_u32(data, word_index):
    value = 0
    for byte_index in range(4):
        value |= data[(word_index * 4) + byte_index] << (byte_index * 8)
    return value


def bytes_to_s32(data, word_index):
    value = bytes_to_u32(data, word_index)
    return value - 0x100000000 if value & 0x80000000 else value


def to_u8(value):
    return value & 0xFF


def s32_to_bytes(value):
    return [(value >> shift) & 0xFF for shift in (0, 8, 16, 24)]


def u32_to_bytes(value):
    return [(value >> shift) & 0xFF for shift in (0, 8, 16, 24)]


def conv_perf_runtime_config_bytes():
    return (
        u32_to_bytes(CONV_PERF_CONFIG_MAGIC)
        + u32_to_bytes(CONV_PERF_GROUP)
        + u32_to_bytes(CONV_PERF_CASE & 0xFFFFFFFF)
    )


def conv1_input_value(h, w, c):
    return ((h * 17 + w * 11 + c * 5) % 19) - 9


def conv1_weight_value(c, oc):
    return ((c * 7 + oc * 3) % 17) - 8


def conv3_input_value(h, w, c):
    return ((h * 13 + w * 7 + c * 5) % 11) - 5


def conv3_weight_value(kh, kw, c, oc):
    return ((kh * 19 + kw * 11 + c * 7 + oc * 3) % 15) - 7


def make_conv1_input():
    return [
        to_u8(conv1_input_value(h, w, c))
        for h in range(CONV1_H)
        for w in range(CONV1_W)
        for c in range(CONV1_C)
    ]


def make_conv1_weight_packed():
    return make_conv1_weight_packed_generic(CONV1_C)


def make_conv3_input():
    return [
        to_u8(conv3_input_value(h, w, c))
        for h in range(CONV3_H)
        for w in range(CONV3_W)
        for c in range(CONV3_C)
    ]


def make_conv3_weight_packed():
    packed = []
    k_total = 3 * 3 * CONV3_C
    for lane in range(K_TILE):
        kh = kw = c = 0
        if lane < k_total:
            spatial = lane // CONV3_C
            c = lane - spatial * CONV3_C
            kh = spatial // 3
            kw = spatial - kh * 3
        for oc in range(OC):
            value = conv3_weight_value(kh, kw, c, oc) if lane < k_total else 0
            packed.append(to_u8(value))
    return packed


def golden_conv1():
    out = []
    for h in range(CONV1_H):
        for w in range(CONV1_W):
            for oc in range(OC):
                acc = 0
                for c in range(CONV1_C):
                    acc += conv1_input_value(h, w, c) * conv1_weight_value(c, oc)
                out.extend(s32_to_bytes(acc & 0xFFFFFFFF))
    return out


def golden_conv3():
    out = []
    for oh in range(CONV3_H):
        for ow in range(CONV3_W):
            for oc in range(OC):
                acc = 0
                for kh in range(3):
                    ih = oh + kh - 1
                    for kw in range(3):
                        iw = ow + kw - 1
                        for c in range(CONV3_C):
                            if 0 <= ih < CONV3_H and 0 <= iw < CONV3_W:
                                acc += conv3_input_value(ih, iw, c) * conv3_weight_value(kh, kw, c, oc)
                out.extend(s32_to_bytes(acc & 0xFFFFFFFF))
    return out


def p3_input_addr(case_id):
    if case_id == P3_CASE_LINEBUF_3X3_C120_C32B:
        return P3_C120_C32B_INPUT_ADDR
    if case_id == P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT:
        return P3_C32T_INPUT_ADDR
    return L2_P3_BASE + case_id * P3_CASE_STRIDE + 0x0000


def p3_weight_addr(case_id):
    if case_id == P3_CASE_LINEBUF_3X3_C120_C32B:
        return P3_C120_C32B_WEIGHT_ADDR
    if case_id == P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT:
        return P3_C32T_WEIGHT_ADDR
    return L2_P3_BASE + case_id * P3_CASE_STRIDE + 0x3000


def p3_out_addr(case_id):
    if case_id == P3_CASE_LINEBUF_3X3_C120_C32B:
        return P3_C120_C32B_OUT_ADDR
    if case_id == P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT:
        return P3_C32T_OUT_ADDR
    return L2_P3_BASE + case_id * P3_CASE_STRIDE + 0x10000


def p3_stats_addr(case_id):
    if case_id == P3_CASE_LINEBUF_3X3_C120_C32B:
        return P3_C120_C32B_STATS_ADDR
    if case_id == P3_CASE_LINEBUF_3X3_C32_TILED_REQUANT:
        return P3_C32T_STATS_ADDR
    return L2_P3_BASE + case_id * P3_CASE_STRIDE + 0x3E000


def p3_input_value(h, w, c):
    return ((h * 13 + w * 7 + c * 5) % 19) - 9


def p3_weight_value(kh, kw, c, oc):
    return ((kh * 17 + kw * 11 + c * 7 + oc * 3) % 17) - 8


def make_conv1_input_generic(input_c, input_h=P3_H, input_w=P3_W):
    return [
        to_u8(conv1_input_value(h, w, c))
        for h in range(input_h)
        for w in range(input_w)
        for c in range(input_c)
    ]


def make_conv1_weight_packed_generic(input_c):
    packed = []
    k_blocks = (input_c + K_TILE - 1) // K_TILE
    for block in range(k_blocks):
        for lane in range(K_TILE):
            c = block * K_TILE + lane
            for oc in range(OC):
                value = conv1_weight_value(c, oc) if c < input_c else 0
                packed.append(to_u8(value))
    return packed


def golden_conv1_generic(input_c, input_h=P3_H, input_w=P3_W):
    out = []
    for h in range(input_h):
        for w in range(input_w):
            for oc in range(OC):
                acc = 0
                for c in range(input_c):
                    acc += conv1_input_value(h, w, c) * conv1_weight_value(c, oc)
                out.extend(s32_to_bytes(acc & 0xFFFFFFFF))
    return out


def p3_qparams(channel):
    return {
        "bias": (channel - 16) * 3,
        "multiplier": (channel % 5) + 1,
        "shift": channel % 4,
        "zero_point": (channel % 7) - 3,
        "clamp_min": -50,
        "clamp_max": 60,
    }


def round_shift_right(value, shift):
    if shift == 0:
        return value
    offset = 1 << (shift - 1)
    if value >= 0:
        return (value + offset) >> shift
    return -(((-value) + offset) >> shift)


def clamp(value, min_value, max_value):
    return max(min_value, min(max_value, value))


def p3_requant(acc, channel):
    params = p3_qparams(channel)
    biased = acc + params["bias"]
    scaled = biased * params["multiplier"]
    rounded = round_shift_right(scaled, params["shift"])
    with_zp = rounded + params["zero_point"]
    return clamp(with_zp, params["clamp_min"], params["clamp_max"]) & 0xFF


def make_p3_input(input_h, input_w, input_c):
    if input_h == P3_C120_H and input_w == P3_C120_W and input_c == 120:
        import numpy as np

        h = np.arange(input_h, dtype=np.int32)[:, None, None]
        w = np.arange(input_w, dtype=np.int32)[None, :, None]
        c = np.arange(input_c, dtype=np.int32)[None, None, :]
        values = ((h * 13 + w * 7 + c * 5) % 19) - 9
        return values.astype(np.int8).tobytes()
    return [
        to_u8(p3_input_value(h, w, c))
        for h in range(input_h)
        for w in range(input_w)
        for c in range(input_c)
    ]


def make_p3_input_c32_blocked(input_h, input_w, input_c):
    c_blocks = (input_c + K_TILE - 1) // K_TILE
    data = []
    for c_block in range(c_blocks):
        c_base = c_block * K_TILE
        for h in range(input_h):
            for w in range(input_w):
                for lane in range(K_TILE):
                    c = c_base + lane
                    value = p3_input_value(h, w, c) if c < input_c else 0
                    data.append(to_u8(value))
    return data


def make_p3_input_for_case(case_id, input_h, input_w, input_c):
    if case_id == P3_CASE_LINEBUF_3X3_C120_C32B:
        return make_p3_input_c32_blocked(input_h, input_w, input_c)
    return make_p3_input(input_h, input_w, input_c)


def make_p3_weight_packed(input_c, kernel_h, kernel_w, oc_count):
    packed = []
    k_total = input_c * kernel_h * kernel_w
    k_blocks = (k_total + K_TILE - 1) // K_TILE
    oc_tiles = (oc_count + OC - 1) // OC
    for oc_tile in range(oc_tiles):
        oc_base = oc_tile * OC
        for block in range(k_blocks):
            for lane in range(K_TILE):
                k_index = block * K_TILE + lane
                if k_index < k_total:
                    spatial = k_index // input_c
                    c = k_index - spatial * input_c
                    kh = spatial // kernel_w
                    kw = spatial - kh * kernel_w
                for oc_lane in range(OC):
                    oc = oc_base + oc_lane
                    value = p3_weight_value(kh, kw, c, oc) if k_index < k_total and oc < oc_count else 0
                    packed.append(to_u8(value))
    return packed


def make_p3_weight_packed_channel_slice(input_c_total, kernel_h, kernel_w, oc_count, c_base, c_count):
    packed = []
    k_total = c_count * kernel_h * kernel_w
    k_blocks = (k_total + K_TILE - 1) // K_TILE
    oc_tiles = (oc_count + OC - 1) // OC
    for oc_tile in range(oc_tiles):
        oc_base = oc_tile * OC
        for block in range(k_blocks):
            for lane in range(K_TILE):
                k_index = block * K_TILE + lane
                if k_index < k_total:
                    spatial = k_index // c_count
                    local_c = k_index - spatial * c_count
                    kh = spatial // kernel_w
                    kw = spatial - kh * kernel_w
                    c = c_base + local_c
                for oc_lane in range(OC):
                    oc = oc_base + oc_lane
                    value = (
                        p3_weight_value(kh, kw, c, oc)
                        if k_index < k_total and c < input_c_total and oc < oc_count
                        else 0
                    )
                    packed.append(to_u8(value))
    return packed


def linebuf_channel_slices(input_c):
    if input_c > K_TILE and input_c % K_TILE:
        aligned_c = (input_c // K_TILE) * K_TILE
        return [(0, aligned_c), (aligned_c, input_c - aligned_c)]
    return [(0, input_c)]


def c32_blocked_channel_slices(input_c):
    # Keep weights packed per physical C32 group, including the final padded
    # group. RTL group-stationary consumes tiles in group-spatial order:
    # C0 kh/kw sweep, then C32, then C64, etc. Lanes beyond logical input_c
    # are zeroed by make_p3_weight_packed_channel_slice().
    slices = []
    c_base = 0
    while c_base < input_c:
        slices.append((c_base, K_TILE))
        c_base += K_TILE
    return slices


def use_linebuf_channel_slice_plan(case_id):
    return case_id in (
        P3_CASE_LINEBUF_KGEN_3X3_C96,
        P3_CASE_LINEBUF_KGEN_3X3_C65,
        P3_CASE_LINEBUF_3X3_C120_C32B,
    )


def make_p3_weight_packed_for_case(case_id, input_c, kernel_h, kernel_w, oc_count):
    if use_linebuf_channel_slice_plan(case_id):
        packed = []
        channel_slices = (
            c32_blocked_channel_slices(input_c)
            if case_id == P3_CASE_LINEBUF_3X3_C120_C32B
            else linebuf_channel_slices(input_c)
        )
        for c_base, c_count in channel_slices:
            packed += make_p3_weight_packed_channel_slice(input_c, kernel_h, kernel_w, oc_count, c_base, c_count)
        return packed
    return make_p3_weight_packed(input_c, kernel_h, kernel_w, oc_count)


def golden_p3_case(case_id):
    (
        _name,
        input_h,
        input_w,
        input_c,
        output_h,
        output_w,
        kernel_h,
        kernel_w,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
        oc_count,
        _k_tiles,
        _idma,
        _spatz,
        requant_output,
    ) = P3_CASES[case_id]
    out = []
    for oh in range(output_h):
        for ow in range(output_w):
            for oc in range(oc_count):
                acc = 0
                for kh in range(kernel_h):
                    ih = oh * stride_h + kh - pad_h
                    for kw in range(kernel_w):
                        iw = ow * stride_w + kw - pad_w
                        if 0 <= ih < input_h and 0 <= iw < input_w:
                            for c in range(input_c):
                                acc += p3_input_value(ih, iw, c) * p3_weight_value(kh, kw, c, oc)
                if requant_output:
                    out.append(p3_requant(acc, oc))
                else:
                    out.extend(s32_to_bytes(acc & 0xFFFFFFFF))
    return out


def bump_counter(counters, names, value):
    name = names.get(value, f"UNKNOWN_{value}")
    counters[name] = counters.get(name, 0) + 1


def safe_signal_to_int(signal_getter):
    try:
        return signal_to_int(signal_getter())
    except AttributeError:
        return None


def first_signal_value(*signal_getters):
    for signal_getter in signal_getters:
        value = safe_signal_to_int(signal_getter)
        if value is not None:
            return value
    return None


def format_state_counts(title, counts, total, idle_name=None, limit=None):
    active_total = total - counts.get(idle_name, 0) if idle_name else total
    lines = [f"{title}: total={total} active={active_total}"]
    items = sorted(counts.items(), key=lambda item: item[1], reverse=True)
    if limit is not None:
        items = items[:limit]
    for name, cycles in items:
        pct_total = (100.0 * cycles / total) if total else 0.0
        if idle_name and name == idle_name:
            lines.append(f"  {name}: cycles={cycles} total={pct_total:.2f}% active=-")
        else:
            pct_active = (100.0 * cycles / active_total) if active_total else 0.0
            lines.append(f"  {name}: cycles={cycles} total={pct_total:.2f}% active={pct_active:.2f}%")
    return "\n".join(lines)


async def monitor_conv_perf_states(dut, stats):
    ctrl = dut.u_npu_cluster.u_sys_ctrl
    linebuf = ctrl.i_input_engine.i_linebuf
    cluster = dut.u_npu_cluster

    while not stats["done"]:
        await RisingEdge(dut.clk_i)
        stats["cycles"] += 1

        systolic_state = first_signal_value(lambda: dut.debug_sys_state_o, lambda: ctrl.debug_state_o, lambda: cluster.sys_debug_state)
        drain_state = first_signal_value(
            lambda: dut.debug_sys_drain_state_o,
            lambda: ctrl.debug_drain_state_o,
            lambda: cluster.sys_debug_drain_state,
        )
        linebuf_state = first_signal_value(
            lambda: dut.debug_linebuf_state_o,
            lambda: ctrl.debug_linebuf_state_o,
            lambda: cluster.sys_debug_linebuf_state,
        )
        fetch_main_state = safe_signal_to_int(lambda: dut.debug_linebuf_fetch_main_state_o)
        fetch_background_state = safe_signal_to_int(lambda: dut.debug_linebuf_fetch_background_state_o)
        bypass_state = safe_signal_to_int(lambda: dut.debug_linebuf_bypass_state_o)

        if systolic_state is not None:
            bump_counter(stats["systolic"], SYSTOLIC_STATE_NAMES, systolic_state)
        if drain_state is not None:
            bump_counter(stats["drain"], DRAIN_STATE_NAMES, drain_state)
        if linebuf_state is not None:
            bump_counter(stats["linebuf"], LINEBUF_STATE_NAMES, linebuf_state)
        if fetch_main_state is not None:
            bump_counter(stats["linebuf_fetch_main"], LINEBUF_FETCH_MAIN_STATE_NAMES, fetch_main_state)
        if fetch_background_state is not None:
            bump_counter(
                stats["linebuf_fetch_background"],
                LINEBUF_FETCH_BACKGROUND_STATE_NAMES,
                fetch_background_state,
            )
        if bypass_state is not None:
            bump_counter(stats["linebuf_bypass"], LINEBUF_BYPASS_STATE_NAMES, bypass_state)

        if safe_signal_to_int(lambda: cluster.sys_compute_en) == 1:
            stats["events"]["compute"] += 1
        if safe_signal_to_int(lambda: cluster.sys_weight_load_en) == 1:
            stats["events"]["weight_load"] += 1
        if safe_signal_to_int(lambda: cluster.sys_ofm_valid) == 1:
            stats["events"]["ofm_valid"] += 1
        if safe_signal_to_int(lambda: ctrl.linebuf_row_valid) == 1:
            stats["events"]["linebuf_row_valid"] += 1
        if safe_signal_to_int(lambda: ctrl.linebuf_row_ready) == 1:
            stats["events"]["linebuf_row_ready"] += 1
        if safe_signal_to_int(lambda: linebuf.obi_req_o) == 1:
            stats["events"]["linebuf_obi_req"] += 1
        if safe_signal_to_int(lambda: linebuf.obi_req_o) == 1 and safe_signal_to_int(lambda: linebuf.obi_gnt_i) != 1:
            stats["events"]["linebuf_obi_stall"] += 1
        if safe_signal_to_int(lambda: ctrl.ofm_fifo_empty) == 1:
            stats["events"]["ofm_fifo_empty"] += 1
        if safe_signal_to_int(lambda: ctrl.ofm_fifo_full) == 1:
            stats["events"]["ofm_fifo_full"] += 1


def log_conv_perf_state_report(dut, stats):
    ctrl = dut.u_npu_cluster.u_sys_ctrl
    linebuf = ctrl.i_input_engine.i_linebuf
    scheduler = linebuf.i_spatial_scheduler
    weight = ctrl.i_weight_engine
    terminal_signals = (
        ("sys_state", lambda: ctrl.state_q),
        ("drain_remaining", lambda: ctrl.drain_cnt_q),
        ("ofm_empty", lambda: ctrl.ofm_fifo_empty),
        ("input_done", lambda: ctrl.input_feed_done),
        ("has_next_tile", lambda: ctrl.linebuf_has_next_k_tile),
        ("k_tile", lambda: ctrl.k_tile_idx_q),
        ("weight_load_done", lambda: ctrl.weight_load_done),
        ("weight_preload_done", lambda: ctrl.weight_preload_done),
        ("linebuf_busy", lambda: ctrl.linebuf_busy),
        ("linebuf_prefetch_busy", lambda: ctrl.linebuf_prefetch_busy),
        ("linebuf_tile", lambda: scheduler.k_tile_idx_q),
        ("linebuf_more_tiles", lambda: scheduler.more_k_tiles),
        ("linebuf_stream_drained", lambda: scheduler.formatter_stream_drained),
        ("linebuf_prefetch_active", lambda: scheduler.prefetch_active_q),
        ("linebuf_prefetch_ready", lambda: scheduler.prefetch_ready_q),
        ("weight_req_remaining", lambda: weight.req_cnt_q),
        ("weight_rsp_remaining", lambda: weight.rsp_cnt_q),
        ("weight_obi_rsp_remaining", lambda: weight.obi_rsp_cnt_q),
        ("weight_preload_active", lambda: weight.preload_active_q),
        ("weight_fifo_empty", lambda: weight.fifo_empty),
        ("weight_fifo_full", lambda: weight.fifo_full),
    )
    dut._log.info(
        "conv_perf terminal handshake snapshot: %s",
        " ".join(
            f"{name}={safe_signal_to_int(reader)}"
            for name, reader in terminal_signals
        ),
    )
    dut._log.info(
        "conv_perf state monitor events: cycles=%d compute=%d weight_load=%d ofm_valid=%d "
        "linebuf_row_valid=%d linebuf_row_ready=%d linebuf_obi_req=%d linebuf_obi_stall=%d "
        "ofm_fifo_empty=%d ofm_fifo_full=%d",
        stats["cycles"],
        stats["events"].get("compute", 0),
        stats["events"].get("weight_load", 0),
        stats["events"].get("ofm_valid", 0),
        stats["events"].get("linebuf_row_valid", 0),
        stats["events"].get("linebuf_row_ready", 0),
        stats["events"].get("linebuf_obi_req", 0),
        stats["events"].get("linebuf_obi_stall", 0),
        stats["events"].get("ofm_fifo_empty", 0),
        stats["events"].get("ofm_fifo_full", 0),
    )
    dut._log.info("%s", format_state_counts("systolic state cycles", stats["systolic"], stats["cycles"], "IDLE"))
    dut._log.info("%s", format_state_counts("drain state cycles", stats["drain"], stats["cycles"], None))
    dut._log.info("%s", format_state_counts("linebuffer state cycles", stats["linebuf"], stats["cycles"], "CH_IDLE"))
    dut._log.info(
        "%s",
        format_state_counts(
            "linebuffer main-fetch state cycles", stats["linebuf_fetch_main"], stats["cycles"], "MAIN_IDLE"
        ),
    )
    dut._log.info(
        "%s",
        format_state_counts(
            "linebuffer background state cycles",
            stats["linebuf_fetch_background"],
            stats["cycles"],
            "BG_IDLE",
        ),
    )
    dut._log.info(
        "%s",
        format_state_counts(
            "linebuffer bypass state cycles", stats["linebuf_bypass"], stats["cycles"], "BYPASS_IDLE"
        ),
    )


def check_pmu_fsm_partitions(report):
    scope_cycles = sum(report[name] for name in PMU_DRAIN_STATE_COUNTERS)
    assert scope_cycles > 0, "systolic job state scope was never active"
    for label, names in (
        ("linebuffer scheduler", PMU_LINEBUF_STATE_COUNTERS),
        ("linebuffer main fetch", PMU_LINEBUF_FETCH_MAIN_STATE_COUNTERS),
        ("linebuffer background fetch", PMU_LINEBUF_FETCH_BACKGROUND_STATE_COUNTERS),
        ("linebuffer bypass", PMU_LINEBUF_BYPASS_STATE_COUNTERS),
    ):
        state_cycles = sum(report[name] for name in names)
        assert state_cycles == scope_cycles, (
            f"{label} state partition mismatch: states={state_cycles} scope={scope_cycles}"
        )


async def boot_and_run(dut, test_file):
    clock = Clock(dut.clk_i, 1, unit="ns")
    cocotb.start_soon(clock.start())
    axi_master = AxiLiteMaster(AxiLiteBus.from_prefix(dut, "s_axi"), dut.clk_i, dut.rst_ni, reset_active_level=False)

    fw_path = firmware_path(test_file, "sw/test/conv_perf/conv_perf.bin")
    assert os.path.exists(fw_path), "Run `make -C sw/test/conv_perf` first."

    await reset_dut(dut)
    await load_firmware_axi(axi_master, fw_path)
    await write_l2_bytes(dut, L2_CONV_PERF_CONFIG, conv_perf_runtime_config_bytes())
    if legacy_enabled():
        await write_l2_bytes(dut, L2_CONV1_INPUT, make_conv1_input())
        await write_l2_bytes(dut, L2_CONV1_WEIGHT, make_conv1_weight_packed())
        await write_l2_bytes(dut, L2_CONV3_INPUT, make_conv3_input())
        await write_l2_bytes(dut, L2_CONV3_WEIGHT, make_conv3_weight_packed())
        await write_l2_bytes(dut, L2_CONV1_C32_INPUT, make_conv1_input_generic(32))
        await write_l2_bytes(dut, L2_CONV1_C32_WEIGHT, make_conv1_weight_packed_generic(32))
        await write_l2_bytes(dut, L2_CONV1_C64_INPUT, make_conv1_input_generic(64))
        await write_l2_bytes(dut, L2_CONV1_C64_WEIGHT, make_conv1_weight_packed_generic(64))
    for case_id, case in P3_CASES.items():
        if not p3_case_enabled(case_id):
            continue
        (
            _name,
            input_h,
            input_w,
            input_c,
            _output_h,
            _output_w,
            kernel_h,
            kernel_w,
            _stride_h,
            _stride_w,
            _pad_h,
            _pad_w,
            oc_count,
            _k_tiles,
            _idma,
            _spatz,
            _requant_output,
        ) = case
        await write_l2_bytes(dut, p3_input_addr(case_id), make_p3_input_for_case(case_id, input_h, input_w, input_c))
        await write_l2_bytes(
            dut,
            p3_weight_addr(case_id),
            make_p3_weight_packed_for_case(case_id, input_c, kernel_h, kernel_w, oc_count),
        )
    monitor_stats = {
        "done": False,
        "cycles": 0,
        "systolic": {},
        "drain": {},
        "linebuf": {},
        "linebuf_fetch_main": {},
        "linebuf_fetch_background": {},
        "linebuf_bypass": {},
        "events": {
            "compute": 0,
            "weight_load": 0,
            "ofm_valid": 0,
            "linebuf_row_valid": 0,
            "linebuf_row_ready": 0,
            "linebuf_obi_req": 0,
            "linebuf_obi_stall": 0,
            "ofm_fifo_empty": 0,
            "ofm_fifo_full": 0,
        },
    }
    monitor_task = cocotb.start_soon(monitor_conv_perf_states(dut, monitor_stats))
    await release_fetch(dut, axi_master=axi_master)
    try:
        timeout_cycles = CONV_PERF_TIMEOUT_CYCLES
        report = await wait_for_host_irq(
            dut,
            timeout_cycles=timeout_cycles,
            axi_master=axi_master,
            report_name="test_conv_perf",
        )
        check_pmu_fsm_partitions(report)
    except AssertionError as exc:
        status = read_dtcm_word(dut, STATUS_BASE + 0x00)
        pass_count = read_dtcm_word(dut, STATUS_BASE + 0x04)
        phase = read_dtcm_word(dut, STATUS_BASE + 0x18)
        op = read_dtcm_word(dut, STATUS_BASE + 0x1C)
        raise AssertionError(
            f"{exc}: status=0x{status:08x} pass_count={pass_count} phase={phase} op={op}"
        ) from exc
    finally:
        monitor_stats["done"] = True
        await RisingEdge(dut.clk_i)
        monitor_task.cancel()
        log_conv_perf_state_report(dut, monitor_stats)


async def check_output(dut, name, addr, expected):
    got = await read_l2_bytes(dut, addr, len(expected))
    for index, (got_byte, expected_byte) in enumerate(zip(got, expected)):
        assert got_byte == expected_byte, (
            f"{name} byte {index}: got=0x{got_byte:02x} expected=0x{expected_byte:02x}; "
            f"got_word={bytes_to_s32(got, index // 4)} expected_word={bytes_to_s32(expected, index // 4)}"
        )


async def check_stats(
    dut,
    name,
    addr,
    expected_rows,
    expected_k_tiles,
    expected_idma_tiles=None,
    expected_spatz_tiles=None,
    allow_linebuf=False,
):
    stats = await read_l2_bytes(dut, addr, 48)
    rows = bytes_to_u32(stats, 0)
    k_tiles = bytes_to_u32(stats, 1)
    prepare_cycles = bytes_to_u32(stats, 2)
    gemm_cycles = bytes_to_u32(stats, 3)
    total_cycles = bytes_to_u32(stats, 4)
    last_prepare_cycles = bytes_to_u32(stats, 5)
    last_gemm_cycles = bytes_to_u32(stats, 6)
    status = bytes_to_u32(stats, 7)
    idma_tiles = bytes_to_u32(stats, 8)
    idma_transfers = bytes_to_u32(stats, 9)
    spatz_tiles = bytes_to_u32(stats, 10)
    scalar_tiles = bytes_to_u32(stats, 11)

    assert status == 0, f"{name}: scheduler status=0x{status:08x}"
    assert rows == expected_rows, f"{name}: rows={rows} expected={expected_rows}"
    assert k_tiles == expected_k_tiles, f"{name}: k_tiles={k_tiles} expected={expected_k_tiles}"
    if allow_linebuf:
        assert prepare_cycles == 0, f"{name}: linebuffer prepare_cycles={prepare_cycles} expected=0"
        assert last_prepare_cycles == 0, f"{name}: linebuffer last_prepare_cycles={last_prepare_cycles} expected=0"
    else:
        assert prepare_cycles > 0, f"{name}: prepare_cycles must be non-zero"
        assert last_prepare_cycles > 0, f"{name}: last_prepare_cycles must be non-zero"
    assert gemm_cycles > 0, f"{name}: gemm_cycles must be non-zero"
    assert total_cycles >= prepare_cycles + gemm_cycles, (
        f"{name}: total_cycles={total_cycles} prepare={prepare_cycles} gemm={gemm_cycles}"
    )
    assert last_gemm_cycles > 0, f"{name}: last_gemm_cycles must be non-zero"
    if allow_linebuf:
        assert idma_tiles + spatz_tiles + scalar_tiles == 0, (
            f"{name}: linebuffer backend counters idma={idma_tiles} spatz={spatz_tiles} scalar={scalar_tiles} expected=0"
        )
    else:
        assert idma_tiles + spatz_tiles + scalar_tiles == expected_k_tiles, (
            f"{name}: backend tiles idma={idma_tiles} spatz={spatz_tiles} scalar={scalar_tiles}"
        )
    assert scalar_tiles == 0, f"{name}: scalar prepare backend must not be used"
    if (not allow_linebuf) and expected_idma_tiles is not None:
        assert idma_tiles == expected_idma_tiles, f"{name}: idma_tiles={idma_tiles} expected={expected_idma_tiles}"
        if expected_idma_tiles:
            assert idma_transfers >= idma_tiles, (
                f"{name}: idma_transfers={idma_transfers} must cover idma_tiles={idma_tiles}"
            )
        else:
            assert idma_transfers == 0, f"{name}: idma_transfers={idma_transfers} expected=0"
    if (not allow_linebuf) and expected_spatz_tiles is not None:
        assert spatz_tiles == expected_spatz_tiles, f"{name}: spatz_tiles={spatz_tiles} expected={expected_spatz_tiles}"

    dut._log.info(
        "%s stats: rows=%d k_tiles=%d prepare=%d gemm=%d total=%d last_prepare=%d last_gemm=%d idma=%d idma_tx=%d spatz=%d scalar=%d",
        name,
        rows,
        k_tiles,
        prepare_cycles,
        gemm_cycles,
        total_cycles,
        last_prepare_cycles,
        last_gemm_cycles,
        idma_tiles,
        idma_transfers,
        spatz_tiles,
        scalar_tiles,
    )


async def check_stats_pair(
    dut,
    name,
    addr,
    expected_rows,
    expected_k_tiles,
    expected_idma_tiles,
    expected_spatz_tiles,
    allow_linebuf=False,
):
    stats = await read_l2_bytes(dut, addr, 96)
    for tile in range(2):
        base = tile * 48
        rows = bytes_to_u32(stats[base:], 0)
        k_tiles = bytes_to_u32(stats[base:], 1)
        prepare_cycles = bytes_to_u32(stats[base:], 2)
        gemm_cycles = bytes_to_u32(stats[base:], 3)
        total_cycles = bytes_to_u32(stats[base:], 4)
        last_prepare_cycles = bytes_to_u32(stats[base:], 5)
        last_gemm_cycles = bytes_to_u32(stats[base:], 6)
        status = bytes_to_u32(stats[base:], 7)
        idma_tiles = bytes_to_u32(stats[base:], 8)
        idma_transfers = bytes_to_u32(stats[base:], 9)
        spatz_tiles = bytes_to_u32(stats[base:], 10)
        scalar_tiles = bytes_to_u32(stats[base:], 11)
        assert status == 0, f"{name} tile {tile}: scheduler status=0x{status:08x}"
        assert rows == expected_rows, f"{name} tile {tile}: rows={rows} expected={expected_rows}"
        assert k_tiles == expected_k_tiles, f"{name} tile {tile}: k_tiles={k_tiles} expected={expected_k_tiles}"
        if allow_linebuf:
            assert prepare_cycles == 0, f"{name} tile {tile}: linebuffer prepare_cycles={prepare_cycles} expected=0"
            assert last_prepare_cycles == 0, f"{name} tile {tile}: linebuffer last_prepare_cycles={last_prepare_cycles} expected=0"
        else:
            assert prepare_cycles > 0, f"{name} tile {tile}: prepare_cycles must be non-zero"
            assert last_prepare_cycles > 0, f"{name} tile {tile}: last_prepare_cycles must be non-zero"
        assert gemm_cycles > 0, f"{name} tile {tile}: gemm_cycles must be non-zero"
        assert total_cycles >= prepare_cycles + gemm_cycles, (
            f"{name} tile {tile}: total_cycles={total_cycles} prepare={prepare_cycles} gemm={gemm_cycles}"
        )
        assert last_gemm_cycles > 0, f"{name} tile {tile}: last_gemm_cycles must be non-zero"
        if allow_linebuf:
            assert idma_tiles + spatz_tiles + scalar_tiles == 0, (
                f"{name} tile {tile}: linebuffer backend counters idma={idma_tiles} spatz={spatz_tiles} "
                f"scalar={scalar_tiles} expected=0"
            )
        else:
            assert idma_tiles == expected_idma_tiles, f"{name} tile {tile}: idma={idma_tiles} expected={expected_idma_tiles}"
            if expected_idma_tiles:
                assert idma_transfers >= idma_tiles, (
                    f"{name} tile {tile}: idma_transfers={idma_transfers} must cover idma_tiles={idma_tiles}"
                )
            else:
                assert idma_transfers == 0, f"{name} tile {tile}: idma_transfers={idma_transfers} expected=0"
            assert spatz_tiles == expected_spatz_tiles, f"{name} tile {tile}: spatz={spatz_tiles} expected={expected_spatz_tiles}"
        assert scalar_tiles == 0, f"{name} tile {tile}: scalar prepare backend must not be used"
        dut._log.info(
            "%s tile %d stats: rows=%d k_tiles=%d prepare=%d gemm=%d total=%d idma=%d idma_tx=%d spatz=%d scalar=%d",
            name,
            tile,
            rows,
            k_tiles,
            prepare_cycles,
            gemm_cycles,
            total_cycles,
            idma_tiles,
            idma_transfers,
            spatz_tiles,
            scalar_tiles,
        )


@cocotb.test()
async def test_conv_perf(dut):
    await boot_and_run(dut, __file__)

    if legacy_enabled():
        await check_output(dut, "conv1x1 packed", L2_CONV1_OUT, golden_conv1())
        await check_stats(
            dut,
            "conv1x1 packed",
            L2_CONV1_STATS,
            expected_rows=20,
            expected_k_tiles=2,
            expected_idma_tiles=2,
            expected_spatz_tiles=0,
        )

        await check_output(dut, "conv3x3 packed", L2_CONV3_OUT, golden_conv3())
        await check_stats(
            dut,
            "conv3x3 packed",
            L2_CONV3_STATS,
            expected_rows=25,
            expected_k_tiles=1,
            expected_idma_tiles=1,
            expected_spatz_tiles=0,
        )

        await check_output(dut, "conv1x1 IC32 packed", L2_CONV1_C32_OUT, golden_conv1_generic(32))
        await check_stats(
            dut,
            "conv1x1 IC32 packed",
            L2_CONV1_C32_STATS,
            expected_rows=P3_H * P3_W,
            expected_k_tiles=1,
            expected_idma_tiles=1,
            expected_spatz_tiles=0,
        )

        await check_output(dut, "conv1x1 IC64 packed", L2_CONV1_C64_OUT, golden_conv1_generic(64))
        await check_stats(
            dut,
            "conv1x1 IC64 packed",
            L2_CONV1_C64_STATS,
            expected_rows=P3_H * P3_W,
            expected_k_tiles=2,
            expected_idma_tiles=2,
            expected_spatz_tiles=0,
        )

    for case_id, case in P3_CASES.items():
        if not p3_case_enabled(case_id):
            continue
        (
            name,
            _input_h,
            _input_w,
            _input_c,
            output_h,
            output_w,
            _kernel_h,
            _kernel_w,
            _stride_h,
            _stride_w,
            _pad_h,
            _pad_w,
            oc_count,
            expected_k_tiles,
            expected_idma_tiles,
            expected_spatz_tiles,
            _requant_output,
        ) = case
        await check_output(dut, name, p3_out_addr(case_id), golden_p3_case(case_id))
        if oc_count == 64:
            await check_stats_pair(
                dut,
                name,
                p3_stats_addr(case_id),
                expected_rows=output_h * output_w,
                expected_k_tiles=expected_k_tiles,
                expected_idma_tiles=expected_idma_tiles,
                expected_spatz_tiles=expected_spatz_tiles,
                allow_linebuf=p3_case_is_linebuf(case_id),
            )
        else:
            await check_stats(
                dut,
                name,
                p3_stats_addr(case_id),
                expected_rows=output_h * output_w,
                expected_k_tiles=expected_k_tiles,
                expected_idma_tiles=expected_idma_tiles,
                expected_spatz_tiles=expected_spatz_tiles,
                allow_linebuf=p3_case_is_linebuf(case_id),
            )
