OUTPUT_ARCH(riscv)
ENTRY(_start)

MEMORY
{
    I_TCM (rx)  : ORIGIN = 0x10000000, LENGTH = 32K
    D_TCM (rw)  : ORIGIN = 0x10008000, LENGTH = 32K
}

SECTIONS
{
    .text : {
        *(.text.init)
        *(.text)
        *(.text.*)
        *(.rodata)
        *(.rodata.*)
    } > I_TCM

    .status (NOLOAD) : {
        . = . + 0x100;
    } > D_TCM

    .data : {
        *(.data)
        *(.data.*)
        *(.sdata)
        *(.sdata.*)
    } > D_TCM

    .bss : {
        *(.bss)
        *(.bss.*)
        *(.sbss)
        *(COMMON)
    } > D_TCM

    . = ALIGN(8);
    __stack_top = ORIGIN(D_TCM) + LENGTH(D_TCM);
}
