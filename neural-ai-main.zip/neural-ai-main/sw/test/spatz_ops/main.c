#include "npu_types.h"
#include "npu_memory_map.h"
#include "hal_afu.h"
#include "spatz_ops.h"
#include "spatz_copy.h"
#include "npu_stream_prefetch.h"
#include "idma_mm_utils.h"

/*
 * Scenario: C-callable Spatz/AFU operator library smoke/regression test.
 * Target: prove scheduler-facing wrappers produce exact data for the non-Conv
 * operators needed by the Micro-YOLOv8 raw-head path.
 */
#define PASS_SIGNATURE 0xDEADBEEFu
#define FAIL_SIGNATURE 0xBAD20000u

#define SPATZ_OP_TEST_ALL      0u
#define SPATZ_OP_TEST_COPY     1u
#define SPATZ_OP_TEST_RELU     2u
#define SPATZ_OP_TEST_REQUANT  3u
#define SPATZ_OP_TEST_ADD      4u
#define SPATZ_OP_TEST_MUL      5u
#define SPATZ_OP_TEST_LOGISTIC 6u
#define SPATZ_OP_TEST_MAXPOOL  7u
#define SPATZ_OP_TEST_UPSAMPLE 8u
#define SPATZ_OP_TEST_CONCAT   9u
#define SPATZ_OP_TEST_LOGISTIC_FULL 10u
#define SPATZ_OP_TEST_MUL_Q7_FULL 11u
#define SPATZ_OP_TEST_ADD_FULL 12u
#define SPATZ_OP_TEST_DFL_FUSED 14u
#define SPATZ_OP_TEST_CLASS_SIGMOID 15u
#define SPATZ_OP_TEST_GLOBAL_AVGPOOL 16u
#define SPATZ_OP_TEST_CLAMP_RELU6 17u
#define SPATZ_OP_TEST_QUANT_ADD 18u
#define SPATZ_OP_TEST_DFL16_FUSED 19u
#define SPATZ_OP_TEST_DFL_Q8 20u
#define SPATZ_OP_TEST_DFL16_PACK 21u
#define SPATZ_OP_TEST_QUANT_SUB 22u
#define SPATZ_OP_TEST_COPY_BATCH 23u
#define SPATZ_OP_TEST_COPY_1D 24u
#define SPATZ_OP_TEST_STREAM_PREFETCH 25u

#ifndef SPATZ_OP_TEST_ID
#define SPATZ_OP_TEST_ID SPATZ_OP_TEST_ALL
#endif

#define SIG_STATUS     (*(volatile uint32_t *)0x10008000u)
#define SIG_PASS_COUNT (*(volatile uint32_t *)0x10008004u)
#define SIG_FAIL_TEST  (*(volatile uint32_t *)0x10008008u)
#define SIG_FAIL_INDEX (*(volatile uint32_t *)0x1000800Cu)
#define SIG_FAIL_GOT   (*(volatile uint32_t *)0x10008010u)
#define SIG_FAIL_EXP   (*(volatile uint32_t *)0x10008014u)

#define SRC_I8       ((volatile int8_t *)0x10100000u)
#define DST_I8       ((volatile int8_t *)0x10100100u)
#define RELU_I8      ((volatile int8_t *)0x10100200u)
#define SRC_I32      ((volatile int32_t *)0x10100300u)
#define DST_REQUANT  ((volatile int8_t *)0x10100500u)

#define ADD_LHS      ((volatile int8_t *)0x10100600u)
#define ADD_RHS      ((volatile int8_t *)0x10100700u)
#define ADD_DST      ((volatile int8_t *)0x10100800u)
#define QUANT_ADD_LHS ((volatile int8_t *)0x1013FF00u)
#define QUANT_ADD_RHS ((volatile int8_t *)0x10130000u)
#define QUANT_ADD_DST ((volatile int8_t *)0x10120000u)
#define MUL_LHS      ((volatile int8_t *)0x10100900u)
#define MUL_RHS      ((volatile int8_t *)0x10100A00u)
#define MUL_DST      ((volatile int8_t *)0x10100B00u)
#define LOG_SRC      ((volatile int8_t *)0x10100C00u)
#define LOG_DST      ((volatile int8_t *)0x10100D00u)
#define LOG_LUT      ((volatile uint8_t *)0x10100E00u)
#define POOL_SRC     ((volatile int8_t *)0x10101000u)
#define POOL_DST     ((volatile int8_t *)0x10101200u)
#define UP_SRC       ((volatile int8_t *)0x10101400u)
#define UP_DST       ((volatile int8_t *)0x10101500u)
#define UP_C32_SRC   ((volatile int8_t *)0x10102000u)
#define UP_C32_DST   ((volatile int8_t *)0x10103000u)
#define CONCAT_SRC0  ((volatile int8_t *)0x10101800u)
#define CONCAT_SRC1  ((volatile int8_t *)0x10101A00u)
#define CONCAT_DST   ((volatile int8_t *)0x10101C00u)

#define LOG_FULL_LUT ((volatile uint8_t *)0x10106000u)
#define LOG_FULL_SRC ((volatile int8_t *)0x10108000u)
#define LOG_FULL_DST ((volatile int8_t *)0x1011A000u)
#define MUL_Q7_LHS   ((volatile int8_t *)0x10108000u)
#define MUL_Q7_RHS   ((volatile int8_t *)0x1011A000u)
#define MUL_Q7_DST   ((volatile int8_t *)0x1012C000u)
#define ADD_FULL_LHS MUL_Q7_LHS
#define ADD_FULL_RHS MUL_Q7_RHS
#define ADD_FULL_DST MUL_Q7_DST
#define DFL_ROW32_SRC ((volatile int8_t *)0x10155000u)
#define DFL_ROW32_DST ((volatile uint16_t *)0x10156000u)
#define DFL_EXP_LUT32 ((volatile uint32_t *)0x10157000u)
#define DFL_RECIP_LUT ((volatile uint32_t *)0x10158000u)
#define CLASS_ROW32_SRC ((volatile int8_t *)0x10159000u)
#define CLASS_DST       ((volatile int8_t *)0x1015A000u)
#define GAP_SRC         ((volatile int8_t *)0x1015B000u)
#define GAP_DST         ((volatile int8_t *)0x1015D000u)
#define CLAMP_SRC       ((volatile int8_t *)0x10160000u)
#define CLAMP_DST       ((volatile int8_t *)0x10168000u)
#define DFL16_PACK_SRC  ((volatile int8_t *)0x10150000u)
#define DFL16_PACK_DST  ((volatile int8_t *)0x10151000u)

#define VL 32u
#define QUANT_BINARY_VL 137u
#define QUANT_ADD_OVERLAP_VL 1024u
#define LOG_FULL_H 48u
#define LOG_FULL_W 48u
#define LOG_FULL_C 32u
#define LOG_FULL_PIXELS (LOG_FULL_H * LOG_FULL_W)
#define LOG_FULL_BYTES (LOG_FULL_PIXELS * LOG_FULL_C)
#define POOL_H 4u
#define POOL_W 5u
#define POOL_C 2u
#define POOL_K 5u
#define POOL_PAD 2u
#define UP_H 2u
#define UP_W 3u
#define UP_C 2u
#define UP_SCALE 2u
#define UP_C32_H 3u
#define UP_C32_W 4u
#define UP_C32_C 32u
#define CONCAT_H 2u
#define CONCAT_W 3u
#define CONCAT_C0 32u
#define CONCAT_C1 32u
#define DFL_FUSED_LOCATIONS 64u
#define DFL16_FUSED_RECORDS 19u
#define DFL_Q8_RECORDS 45u
#define DFL16_PACK_STRIDE 37u
#define CLASS_SIGMOID_LOCATIONS 17u
#define GAP_H 7u
#define GAP_W 5u
#define GAP_C 65u
#define GAP_PIXELS (GAP_H * GAP_W)
#define GAP_GROUPS ((GAP_C + 31u) / 32u)
#define CLAMP_H 17u
#define CLAMP_W 13u
#define CLAMP_C 65u
#define CLAMP_GROUPS ((CLAMP_C + 31u) / 32u)
#define CLAMP_PHYS_C (CLAMP_GROUPS * 32u)
#define CLAMP_BYTES (CLAMP_H * CLAMP_W * CLAMP_PHYS_C)
#define CLAMP_MIN 0
#define CLAMP_MAX 63

static void fail(uint32_t test_id, uint32_t index, int32_t got, int32_t expected) {
    // Standard status/debug page lets cocotb report failing op, element, got, expected.
    SIG_FAIL_TEST = test_id;
    SIG_FAIL_INDEX = index;
    SIG_FAIL_GOT = (uint32_t)got;
    SIG_FAIL_EXP = (uint32_t)expected;
    SIG_STATUS = FAIL_SIGNATURE | test_id;
    REG_WRITE(NPU_IRQ_HOST_NOTIFY, FAIL_SIGNATURE | test_id);
    while (1) {
    }
}

static uint8_t sigmoid_lut_value(uint32_t index) {
    return (uint8_t)((index * 3u + 7u) & 0xffu);
}

static int8_t pool_input_value(uint32_t h, uint32_t w, uint32_t c) {
    return (int8_t)((int32_t)((h * 11u + w * 7u + c * 5u) % 31u) - 15);
}

static int8_t up_input_value(uint32_t h, uint32_t w, uint32_t c) {
    return (int8_t)((int32_t)(h * 17u + w * 9u + c * 3u) - 20);
}

static int8_t up_c32_input_value(uint32_t h, uint32_t w, uint32_t c) {
    return (int8_t)((int32_t)((h * 17u + w * 11u + c * 5u) % 127u) - 63);
}

static uint32_t c32_offset(uint32_t height, uint32_t width,
                           uint32_t y, uint32_t x, uint32_t c) {
    uint32_t pixel = y * width + x;
    return (((c >> 5) * (height * width) + pixel) * 32u) + (c & 31u);
}

static int8_t gap_input_value(uint32_t h, uint32_t w, uint32_t c) {
    return (int8_t)((int32_t)(((h * 23u) + (w * 17u) + (c * 11u) + 9u) & 0x7fu) - 64);
}

static void mark_pass(void) {
    SIG_PASS_COUNT = SIG_PASS_COUNT + 1;
}

static void run_copy(void) {
    for (uint32_t i = 0; i < VL; i++) {
        SRC_I8[i] = (int8_t)((int32_t)i - 16);
        DST_I8[i] = 0;
    }

    spatz_vec_copy_i8((const int8_t *)SRC_I8, (int8_t *)DST_I8, VL);
    mark_pass();
}

static void run_copy_batch(void) {
    const spatz_copy_geometry_t cases[] = {
        {16, 32, 16, 137, 0, 0, 1},
        {16, 16, 32, 137, 0, 0, 1},
        {16, 32, 32, 137, 0, 0, 1},
        {32, 64, 32, 73, 0, 0, 1},
        {16, 0, 32, 137, 0, 0, 1},
        {32, 0, 32, 137, 0, 0, 1},
        {16, 32, 32, 19, 640, 672, 3},
        {32, 32, 32, 20, 640, 640, 9},
        {15, 32, 32, 19, 640, 672, 3},
        {16, 1, 32, 1, 64, 96, 19},
        {4, 8, 4, 1031, 0, 0, 1},
        {16, 32, 16, 19, 608, 304, 3},
        {1280, 1280, 1344, 4, 0, 0, 1},
        {640, 640, 704, 4, 0, 0, 1},
        {320, 320, 384, 4, 0, 0, 1},
        {2560, 2560, 2592, 2, 0, 0, 1},
        {516, 516, 544, 3, 0, 0, 1},
        {100, 100, 2100, 5, 0, 0, 1},
        {68, 80, 96, 3, 320, 384, 3},
        {132, 0, 160, 17, 0, 0, 1},
    };
    volatile int8_t *source = (volatile int8_t *)0x10100000u;
    volatile int8_t *destination = (volatile int8_t *)0x10110000u;
    volatile int8_t *expected = (volatile int8_t *)0x10120000u;
    volatile uint32_t *timings = (volatile uint32_t *)0x10130000u;
    for (uint32_t trial = 0; trial < sizeof(cases) / sizeof(cases[0]); trial++) {
        const spatz_copy_geometry_t copy = cases[trial];
        uint32_t source_bytes = copy.length + (copy.repetitions_2 - 1u) * copy.source_stride_2 +
            (copy.repetitions_3 - 1u) * copy.source_stride_3;
        uint32_t destination_bytes = copy.length + (copy.repetitions_2 - 1u) * copy.destination_stride_2 +
            (copy.repetitions_3 - 1u) * copy.destination_stride_3 + 32u;
        for (uint32_t i = 0; i < source_bytes; i++) source[i] = (int8_t)(i * 17u + 93u);
        for (uint32_t i = 0; i < destination_bytes; i++) destination[i] = expected[i] = (int8_t)0xa5;
        for (uint32_t plane = 0; plane < copy.repetitions_3; plane++)
            for (uint32_t run = 0; run < copy.repetitions_2; run++)
                for (uint32_t byte = 0; byte < copy.length; byte++)
                    expected[plane * copy.destination_stride_3 + run * copy.destination_stride_2 + byte] =
                        source[plane * copy.source_stride_3 + run * copy.source_stride_2 + byte];
        uint32_t start;
        uint32_t finish;
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(start) :: "memory");
        for (uint32_t plane = 0; plane < copy.repetitions_3; plane++)
            for (uint32_t run = 0; run < copy.repetitions_2; run++)
                spatz_vec_copy_i8((const int8_t *)source + plane * copy.source_stride_3 +
                    run * copy.source_stride_2, (int8_t *)destination + plane * copy.destination_stride_3 +
                    run * copy.destination_stride_2, copy.length);
        __asm__ volatile ("fence" ::: "memory");
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(finish) :: "memory");
        timings[trial * 3u] = finish - start;
        for (uint32_t i = 0; i < destination_bytes; i++) {
            if (destination[i] != expected[i]) fail(SPATZ_OP_TEST_COPY_BATCH, trial * 65536u + i,
                destination[i], expected[i]);
            destination[i] = (int8_t)0xa5;
        }
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(start) :: "memory");
        spatz_copy_affine_i8((const int8_t *)source, (int8_t *)destination, copy);
        __asm__ volatile ("fence" ::: "memory");
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(finish) :: "memory");
        timings[trial * 3u + 1u] = finish - start;
        timings[trial * 3u + 2u] = copy.length * copy.repetitions_2 * copy.repetitions_3;
        for (uint32_t i = 0; i < destination_bytes; i++)
            if (destination[i] != expected[i]) fail(SPATZ_OP_TEST_COPY_BATCH, trial * 65536u + i,
                destination[i], expected[i]);
        mark_pass();
    }
}

/* Backdoor-seeded source/canaries and independent host byte oracle avoid
 * spending millions of simulation cycles on scalar test initialization. */
static void run_copy_1d(void) {
    static const uint32_t lengths[] = {0, 31, 255, 256, 257, 511, 512, 513, 4096, 8191, 51200};
    volatile uint32_t *timings = (volatile uint32_t *)0x10170000u;
    uint32_t destination = 0x10110000u;
    for (uint32_t trial = 0; trial < sizeof(lengths) / sizeof(lengths[0]); trial++) {
        const uint32_t length = lengths[trial];
        const uint32_t allocation = (length + 95u) & ~31u;
        const int8_t *source = (const int8_t *)(0x10100000u + (trial & 3u));
        int8_t *legacy = (int8_t *)(destination + 32u + ((trial + 1u) & 3u));
        int8_t *batched = (int8_t *)(destination + allocation + 32u + ((trial + 1u) & 3u));
        uint32_t start, finish;
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(start) :: "memory");
        spatz_vec_copy_i8(source, legacy, length);
        __asm__ volatile ("fence" ::: "memory");
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(finish) :: "memory");
        timings[trial * 3u] = finish - start;
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(start) :: "memory");
        spatz_copy_1d_i8(source, batched, length);
        __asm__ volatile ("fence" ::: "memory");
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(finish) :: "memory");
        timings[trial * 3u + 1u] = finish - start;
        timings[trial * 3u + 2u] = length;
        destination += 2u * allocation;
        mark_pass();
    }
    /* Preserve self/overlap behavior of the original 64-byte-VL kernel. */
    spatz_copy_1d_i8((const int8_t *)0x10160000u, (int8_t *)0x10160000u, 513u);
    spatz_vec_copy_i8((const int8_t *)0x10161000u, (int8_t *)0x10161020u, 513u);
    spatz_copy_1d_i8((const int8_t *)0x10162000u, (int8_t *)0x10162020u, 513u);
    __asm__ volatile ("fence" ::: "memory");
    mark_pass();
}

typedef struct {
    uint32_t submits;
    uint32_t waits;
} prefetch_test_context_t;

static uint32_t stream_submit(void *context, uint32_t source, void *destination, uint32_t bytes) {
    ((prefetch_test_context_t *)context)->submits++;
    return (uint32_t)idma_L2ToL1(source, (uint32_t)(unsigned long)destination, bytes);
}

static uint32_t stream_wait(void *context, uint32_t id) {
    ((prefetch_test_context_t *)context)->waits++;
    return idma_mm_wait_for_completion(IDMA_DIR_L2_TO_L1, id);
}

static void run_stream_prefetch(void) {
    static const uint32_t begins[] = {4095u, 32u, 4064u, 32u};
    static const uint32_t lengths[] = {12321u, 16417u, 24593u, 128u};
    static const uint32_t capacities[] = {1024u, 2048u, 4096u, 4096u};
    volatile uint32_t *timings = (volatile uint32_t *)0x10170000u;
    for (uint32_t trial = 0; trial < 4u; trial++) {
        prefetch_test_context_t context = {0};
        nai_stream_prefetch_ops_t ops = {&context, stream_submit, stream_wait};
        nai_stream_prefetch_t state;
        const uint32_t begin = begins[trial];
        const uint32_t end = begin + (trial == 3u ? 16384u : lengths[trial]);
        uint32_t start, finish;
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(start) :: "memory");
        if (nai_stream_prefetch_init(&state, &ops, 0x81000000u, begin, end,
                (void *)0x1016d000u, capacities[trial]) != 0u || context.waits != 0u)
            fail(SPATZ_OP_TEST_STREAM_PREFETCH, trial, 1, 0);
        uint32_t copied = 0u;
        uint32_t step = 0u;
        while (copied < lengths[trial]) {
            uint32_t bytes = 1u + (step * 97u) % 2048u;
            if (bytes > lengths[trial] - copied) bytes = lengths[trial] - copied;
            if ((step % 7u) == 0u) {
                const uint32_t id = (uint32_t)idma_L2ToL1(0x81000000u,
                    0x10165000u + trial * 32u, 32u);
                if (!idma_mm_wait_for_completion(IDMA_DIR_L2_TO_L1, id))
                    fail(SPATZ_OP_TEST_STREAM_PREFETCH, trial, 2, 0);
            }
            if (nai_stream_prefetch_read(&state, begin + copied,
                    (void *)(0x10110000u + trial * 0x10000u + 1u + copied), bytes) != 0u)
                fail(SPATZ_OP_TEST_STREAM_PREFETCH, trial, 3, 0);
            copied += bytes;
            step++;
        }
        if (nai_stream_prefetch_finish(&state) != 0u || idma_mm_is_busy_dir(0u, 0u))
            fail(SPATZ_OP_TEST_STREAM_PREFETCH, trial, 4, 0);
        __asm__ volatile ("fence" ::: "memory");
        __asm__ volatile ("csrr %0, 0xB00" : "=r"(finish) :: "memory");
        timings[trial * 3u] = finish - start;
        timings[trial * 3u + 1u] = context.submits;
        timings[trial * 3u + 2u] = context.waits;
        mark_pass();
    }
}

static void run_relu(void) {
    for (uint32_t i = 0; i < VL; i++) {
        RELU_I8[i] = (int8_t)((int32_t)i - 12);
    }

    spatz_vec_relu_i8((int8_t *)RELU_I8, VL);
    mark_pass();
}

static void run_requant(void) {
    for (uint32_t i = 0; i < VL; i++) {
        SRC_I32[i] = ((int32_t)i - 16) * 37;
        DST_REQUANT[i] = 0;
    }

    spatz_requant_i32_to_i8((const int32_t *)SRC_I32, (int8_t *)DST_REQUANT,
                            VL, 2, 3, -20, 31);
    mark_pass();
}

static void run_add(void) {
    for (uint32_t i = 0; i < VL; i++) {
        ADD_LHS[i] = (int8_t)((int32_t)i - 16);
        ADD_RHS[i] = (int8_t)((int32_t)(i % 9u) - 4);
        ADD_DST[i] = 0;
    }
    spatz_add_i8((const int8_t *)ADD_LHS, (const int8_t *)ADD_RHS,
                 (int8_t *)ADD_DST, VL, -12, 18);
    mark_pass();
}

static void run_quantized_add(void) {
    spatz_quantized_add_params_t params;
    params.lhs_scale = 1610612736;
    params.lhs_shift = 20;
    params.rhs_scale = 1073741824;
    params.rhs_shift = 20;
    params.output_scale = 1073741824;
    params.output_shift = 41;
    params.lhs_zero_point = -3;
    params.rhs_zero_point = 5;
    params.output_zero_point = 7;
    params.clamp_min = -100;
    params.clamp_max = 100;
    params.double_round_shift = 20;
    params.mode = 0;
    for (uint32_t i = 0; i < QUANT_ADD_OVERLAP_VL; i++) {
        QUANT_ADD_LHS[i] = (int8_t)((i * 17u + 3u) & 0xffu);
        QUANT_ADD_RHS[i] = (int8_t)((i * 29u + 11u) & 0xffu);
        QUANT_ADD_DST[i] = 0;
    }
    spatz_quantized_add_i8((const int8_t *)QUANT_ADD_LHS,
                           (const int8_t *)QUANT_ADD_RHS,
                           (int8_t *)QUANT_ADD_DST,
                           QUANT_ADD_OVERLAP_VL, &params);
    mark_pass();
}

static void run_quantized_sub(void) {
    spatz_quantized_add_params_t params;
    params.lhs_scale = 1610612736;
    params.lhs_shift = 20;
    params.rhs_scale = 1073741824;
    params.rhs_shift = 20;
    params.output_scale = 1073741824;
    params.output_shift = 41;
    params.lhs_zero_point = -3;
    params.rhs_zero_point = 5;
    params.output_zero_point = 7;
    params.clamp_min = -100;
    params.clamp_max = 100;
    params.double_round_shift = 20;
    params.mode = 1;
    for (uint32_t i = 0; i < QUANT_BINARY_VL; i++) {
        ADD_LHS[i] = (int8_t)((i * 17u + 3u) & 0xffu);
        ADD_RHS[i] = (int8_t)((i * 29u + 11u) & 0xffu);
        ADD_DST[i] = 0;
    }
    spatz_quantized_add_i8((const int8_t *)ADD_LHS,
                           (const int8_t *)ADD_RHS,
                           (int8_t *)ADD_DST, QUANT_BINARY_VL, &params);
    mark_pass();
}

static void run_mul(void) {
    for (uint32_t i = 0; i < VL; i++) {
        MUL_LHS[i] = (int8_t)((int32_t)(i % 9u) - 4);
        MUL_RHS[i] = (int8_t)((int32_t)(i % 7u) - 3);
        MUL_DST[i] = 0;
    }
    spatz_mul_i8((const int8_t *)MUL_LHS, (const int8_t *)MUL_RHS,
                 (int8_t *)MUL_DST, VL, 3, 2, -30, 31);
    mark_pass();
}

static void run_logistic(void) {
    for (uint32_t i = 0; i < 256u; i++) {
        LOG_LUT[i] = (uint8_t)((i * 3u + 7u) & 0xffu);
    }
    for (uint32_t i = 0; i < VL; i++) {
        LOG_SRC[i] = (int8_t)((i * 13u + 5u) & 0xffu);
        LOG_DST[i] = 0;
    }
    if (!npu_logistic_i8((const int8_t *)LOG_SRC, (int8_t *)LOG_DST,
                         VL, (const uint8_t *)LOG_LUT)) {
        fail(6, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }
    mark_pass();
}

static int8_t logistic_full_input_value(uint32_t pixel, uint32_t channel) {
    return (int8_t)(((pixel * 17u) + (channel * 13u) + 5u) & 0xffu);
}

static uint8_t logistic_full_lut_value(uint32_t index) {
    return (uint8_t)(((index * 5u) + 11u) & 0x7fu);
}

static uint32_t run_logistic_full_afu(uint32_t timeout_cycles) {
    for (uint32_t i = 0; i < 256u; i++) {
        afu_load_lut_entry(i, (uint32_t)LOG_FULL_LUT[i]);
    }

    afu_start((uint32_t)LOG_FULL_SRC, (uint32_t)LOG_FULL_DST,
              LOG_FULL_BYTES, NPU_AFU_MODE_E8);
    for (uint32_t i = 0; i < timeout_cycles; i++) {
        uint32_t status = afu_status();
        SIG_FAIL_INDEX = i;
        SIG_FAIL_GOT = status;
        SIG_FAIL_EXP = NPU_AFU_STATUS_DONE;
        if ((status & NPU_AFU_STATUS_ERROR) != 0u) {
            return 0u;
        }
        if ((status & NPU_AFU_STATUS_DONE) != 0u) {
            return 1u;
        }
        __asm__ volatile("nop");
    }
    return 0u;
}

static void run_logistic_full(void) {
    SIG_STATUS = 0x30001001u;
    for (uint32_t i = 0; i < 256u; i++) {
        LOG_FULL_LUT[i] = logistic_full_lut_value(i);
    }

    SIG_STATUS = 0x30001002u;
    // Source tensor is preloaded by cocotb backdoor to avoid measuring scalar seed time.

    SIG_STATUS = 0x30001003u;
    if (!run_logistic_full_afu(300000u)) {
        fail(10, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001004u;
    // Full tensor output is checked by cocotb backdoor.  Scalar verification on
    // Snitch is too slow for this large AFU throughput regression.
    mark_pass();
}

static void run_mul_q7_full(void) {
    SIG_STATUS = 0x30001101u;
    // Full tensor inputs are preloaded by cocotb backdoor to isolate the vector helper.
    if (!npu_mul_q7_i8((const int8_t *)MUL_Q7_LHS, (const int8_t *)MUL_Q7_RHS,
                       (int8_t *)MUL_Q7_DST, LOG_FULL_BYTES)) {
        fail(11, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001102u;
    // Full tensor output is checked by cocotb backdoor.
    mark_pass();
}

static void run_add_full(void) {
    SIG_STATUS = 0x30001201u;
    // Full tensor inputs are preloaded by cocotb backdoor to isolate AFU add.
    if (!npu_add_i8((const int8_t *)ADD_FULL_LHS, (const int8_t *)ADD_FULL_RHS,
                    (int8_t *)ADD_FULL_DST, LOG_FULL_BYTES)) {
        fail(12, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001202u;
    // Full tensor output is checked by cocotb backdoor.
    mark_pass();
}

static void run_dfl_fused(void) {
    SIG_STATUS = 0x30001402u;
    if (!npu_dfl_softmax4_row32_i8_q8((const int8_t *)DFL_ROW32_SRC,
                                      (uint16_t *)DFL_ROW32_DST,
                                      DFL_FUSED_LOCATIONS,
                                      (const uint32_t *)DFL_EXP_LUT32,
                                      (const uint32_t *)DFL_RECIP_LUT)) {
        fail(14, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001403u;
    mark_pass();
}

static void run_dfl16_fused(void) {
    SIG_STATUS = 0x30001902u;
    if (!npu_dfl_softmax16_row32_i8_q8((const int8_t *)DFL_ROW32_SRC,
                                       (uint16_t *)DFL_ROW32_DST,
                                       DFL16_FUSED_RECORDS,
                                       (const uint32_t *)DFL_EXP_LUT32,
                                       (const uint32_t *)DFL_RECIP_LUT)) {
        fail(19, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001903u;
    mark_pass();
}

static void run_dfl_q8(void) {
    volatile uint16_t *src = (volatile uint16_t *)DFL_ROW32_SRC;
    volatile int8_t *dst = (volatile int8_t *)DFL_ROW32_DST;
    for (uint32_t index = 0; index < DFL_Q8_RECORDS; index++) {
        uint32_t source_index = index < 13u ? index :
            (index < 25u ? index + 3u :
             (index < 37u ? index + 7u : index + 11u));
        src[source_index] = index == 0u ? 0u :
            (index == 1u ? 3840u : (uint16_t)((index * 379u + 127u) % 4096u));
        dst[index] = 0;
    }
    spatz_dfl_q8_to_i8((const uint16_t *)src, (int8_t *)dst,
                       (int32_t *)SPATZ_OP_SCRATCH_I32_ADDR, 13u,
                       58267, 21u, -128, -128, 127);
    spatz_dfl_q8_to_i8((const uint16_t *)(src + 16u), (int8_t *)(dst + 13u),
                       (int32_t *)SPATZ_OP_SCRATCH_I32_ADDR, 12u,
                       58267, 20u, -128, -128, 127);
    spatz_dfl_q8_to_i8((const uint16_t *)(src + 32u), (int8_t *)(dst + 25u),
                       (int32_t *)SPATZ_OP_SCRATCH_I32_ADDR, 12u,
                       58039, 19u, -128, -128, 127);
    spatz_dfl_q8_to_i8((const uint16_t *)(src + 48u), (int8_t *)(dst + 37u),
                       (int32_t *)SPATZ_OP_SCRATCH_I32_ADDR, 8u,
                       51003, 8u, -128, -128, 127);
    mark_pass();
}

static void run_dfl16_pack(void) {
    for (uint32_t test = 0; test < 2u; test++) {
        uint32_t records = test == 0u ? 32u : 5u;
        for (uint32_t channel = 0; channel < 16u; channel++) {
            for (uint32_t record = 0; record < DFL16_PACK_STRIDE; record++) {
                DFL16_PACK_SRC[channel * DFL16_PACK_STRIDE + record] =
                    (int8_t)((channel * 23u + record * 17u + test * 11u) & 0xffu);
            }
        }
        for (uint32_t index = 0; index < 32u * 32u; index++) {
            DFL16_PACK_DST[index] = (int8_t)0x5a;
        }

        spatz_pack_dfl16_chw_tile_i8((const int8_t *)DFL16_PACK_SRC,
                                     (int8_t *)DFL16_PACK_DST, records,
                                     DFL16_PACK_STRIDE);

        for (uint32_t record = 0; record < records; record++) {
            for (uint32_t channel = 0; channel < 16u; channel++) {
                int8_t expected = DFL16_PACK_SRC[channel * DFL16_PACK_STRIDE + record];
                int8_t got = DFL16_PACK_DST[record * 32u + channel];
                if (got != expected) fail(21, record * 32u + channel, got, expected);
            }
            for (uint32_t channel = 16u; channel < 32u; channel++) {
                int8_t got = DFL16_PACK_DST[record * 32u + channel];
                if (got != (int8_t)0x5a) fail(21, record * 32u + channel, got, 0x5a);
            }
        }
    }
    for (uint32_t test = 0; test < 2u; test++) {
        uint32_t records = test == 0u ? 32u : 5u;
        for (uint32_t record = 0; record < records; record++) {
            for (uint32_t channel = 0; channel < 32u; channel++) {
                DFL16_PACK_SRC[record * 32u + channel] =
                    (int8_t)((record * 29u + channel * 13u + test * 7u) & 0xffu);
                DFL16_PACK_DST[record * 32u + channel] = (int8_t)0x5a;
            }
        }

        spatz_pack_dfl16_c32_tile_i8((const int8_t *)DFL16_PACK_SRC,
                                     (int8_t *)DFL16_PACK_DST, records, 32u);

        for (uint32_t record = 0; record < records; record++) {
            for (uint32_t channel = 0; channel < 16u; channel++) {
                int8_t expected = DFL16_PACK_SRC[record * 32u + channel];
                int8_t got = DFL16_PACK_DST[record * 32u + channel];
                if (got != expected) fail(21, 0x1000u + record * 32u + channel, got, expected);
            }
            for (uint32_t channel = 16u; channel < 32u; channel++) {
                int8_t got = DFL16_PACK_DST[record * 32u + channel];
                if (got != (int8_t)0x5a)
                    fail(21, 0x1000u + record * 32u + channel, got, 0x5a);
            }
        }
    }
    mark_pass();
}

static void run_class_sigmoid(void) {
    SIG_STATUS = 0x30001501u;
#if SPATZ_OP_TEST_ID != SPATZ_OP_TEST_CLASS_SIGMOID
    for (uint32_t i = 0; i < 256u; i++) {
        LOG_LUT[i] = sigmoid_lut_value(i);
    }
    for (uint32_t loc = 0; loc < CLASS_SIGMOID_LOCATIONS; loc++) {
        for (uint32_t ch = 0; ch < 32u; ch++) {
            CLASS_ROW32_SRC[(loc * 32u) + ch] =
                (int8_t)((int32_t)(((loc * 29u) + (ch * 13u) + 5u) & 0xffu) - 128);
        }
    }
    for (uint32_t i = 0; i < CLASS_SIGMOID_LOCATIONS * 16u; i++) {
        CLASS_DST[i] = 0;
    }
#endif

    SIG_STATUS = 0x30001502u;
    if (!npu_class_sigmoid_row32_high16_i8((const int8_t *)CLASS_ROW32_SRC,
                                           (int8_t *)CLASS_DST,
                                           CLASS_SIGMOID_LOCATIONS,
                                           (const uint8_t *)LOG_LUT)) {
        fail(15, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001503u;
    mark_pass();
}

static void run_global_avgpool(void) {
    SIG_STATUS = 0x30001601u;
#if SPATZ_OP_TEST_ID != SPATZ_OP_TEST_GLOBAL_AVGPOOL
    for (uint32_t h = 0; h < GAP_H; h++) {
        for (uint32_t w = 0; w < GAP_W; w++) {
            for (uint32_t c = 0; c < GAP_C; c++) {
                GAP_SRC[c32_offset(GAP_H, GAP_W, h, w, c)] = gap_input_value(h, w, c);
            }
        }
    }
    for (uint32_t i = 0; i < GAP_GROUPS * 32u; i++) {
        GAP_DST[i] = (int8_t)0x5a;
    }
#endif

    SIG_STATUS = 0x30001602u;
    if (!npu_global_avgpool_c32_i8((const int8_t *)GAP_SRC,
                                   (int8_t *)GAP_DST,
                                   GAP_H,
                                   GAP_W,
                                   GAP_C)) {
        fail(16, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001603u;
    mark_pass();
}

static void run_clamp_relu6(void) {
    SIG_STATUS = 0x30001702u;
    if (!npu_clamp_i8((const int8_t *)CLAMP_SRC,
                      (int8_t *)CLAMP_DST,
                      CLAMP_BYTES,
                      CLAMP_MIN,
                      CLAMP_MAX)) {
        fail(17, 0, (int32_t)REG_READ(NPU_AFU_STATUS), NPU_AFU_STATUS_DONE);
    }

    SIG_STATUS = 0x30001703u;
    mark_pass();
}

static void run_maxpool(void) {
    for (uint32_t h = 0; h < POOL_H; h++) {
        for (uint32_t w = 0; w < POOL_W; w++) {
            for (uint32_t c = 0; c < POOL_C; c++) {
                POOL_SRC[((h * POOL_W + w) * POOL_C) + c] = pool_input_value(h, w, c);
            }
        }
    }
    spatz_maxpool2d_i8((const int8_t *)POOL_SRC, (int8_t *)POOL_DST,
                       POOL_H, POOL_W, POOL_C,
                       POOL_K, POOL_K, 1, 1, POOL_PAD, POOL_PAD);
    mark_pass();
}

static void run_upsample(void) {
    for (uint32_t h = 0; h < UP_H; h++) {
        for (uint32_t w = 0; w < UP_W; w++) {
            for (uint32_t c = 0; c < UP_C; c++) {
                UP_SRC[((h * UP_W + w) * UP_C) + c] = up_input_value(h, w, c);
            }
        }
    }
    spatz_upsample_nearest_i8((const int8_t *)UP_SRC, (int8_t *)UP_DST,
                              UP_H, UP_W, UP_C, UP_SCALE, UP_SCALE);

    for (uint32_t h = 0; h < UP_C32_H; h++) {
        for (uint32_t w = 0; w < UP_C32_W; w++) {
            for (uint32_t c = 0; c < UP_C32_C; c++) {
                UP_C32_SRC[((h * UP_C32_W + w) * UP_C32_C) + c] =
                    up_c32_input_value(h, w, c);
            }
        }
    }
    spatz_upsample_nearest_i8((const int8_t *)UP_C32_SRC, (int8_t *)UP_C32_DST,
                              UP_C32_H, UP_C32_W, UP_C32_C, UP_SCALE, UP_SCALE);
    mark_pass();
}

static void run_concat(void) {
    for (uint32_t p = 0; p < (CONCAT_H * CONCAT_W); p++) {
        for (uint32_t c = 0; c < 32u; c++) {
            CONCAT_SRC0[(p * 32u) + c] = (int8_t)((int32_t)p + (int32_t)c - 20);
            CONCAT_SRC1[(p * 32u) + c] = (int8_t)(50 + (int32_t)p - (int32_t)c);
        }
    }
    spatz_concat_c32_i8((const int8_t *)CONCAT_SRC0, CONCAT_C0,
                        (const int8_t *)CONCAT_SRC1, CONCAT_C1,
                        (int8_t *)CONCAT_DST, CONCAT_H, CONCAT_W);
    mark_pass();
}

int main(void) {
    SIG_STATUS = 0;
    SIG_PASS_COUNT = 0;
    SIG_FAIL_TEST = 0;
    SIG_FAIL_INDEX = 0;
    SIG_FAIL_GOT = 0;
    SIG_FAIL_EXP = 0;

    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_COPY) {
        run_copy();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_COPY_BATCH) run_copy_batch();
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_COPY_1D) run_copy_1d();
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_STREAM_PREFETCH) run_stream_prefetch();
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_RELU) {
        run_relu();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_REQUANT) {
        run_requant();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ADD) {
        run_add();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_MUL) {
        run_mul();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_LOGISTIC) {
        run_logistic();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_MAXPOOL) {
        run_maxpool();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_UPSAMPLE) {
        run_upsample();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ALL || SPATZ_OP_TEST_ID == SPATZ_OP_TEST_CONCAT) {
        run_concat();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_LOGISTIC_FULL) {
        run_logistic_full();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_MUL_Q7_FULL) {
        run_mul_q7_full();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_ADD_FULL) {
        run_add_full();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_DFL_FUSED) {
        run_dfl_fused();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_CLASS_SIGMOID) {
        run_class_sigmoid();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_GLOBAL_AVGPOOL) {
        run_global_avgpool();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_CLAMP_RELU6) {
        run_clamp_relu6();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_QUANT_ADD) {
        run_quantized_add();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_DFL16_FUSED) {
        run_dfl16_fused();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_DFL_Q8) {
        run_dfl_q8();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_DFL16_PACK) {
        run_dfl16_pack();
    }
    if (SPATZ_OP_TEST_ID == SPATZ_OP_TEST_QUANT_SUB) {
        run_quantized_sub();
    }

    SIG_STATUS = PASS_SIGNATURE;
    REG_WRITE(NPU_IRQ_HOST_NOTIFY, PASS_SIGNATURE);
    while (1) {
    }
}
