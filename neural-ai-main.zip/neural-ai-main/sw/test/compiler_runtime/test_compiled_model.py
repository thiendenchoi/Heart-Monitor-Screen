import base64
import csv
import logging
import math
import os
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.utils import get_sim_time
from cocotbext.axi import AxiLiteBus, AxiLiteMaster

from npu_test_utils import (
    NPU_CMD_DONE_COUNT,
    NPU_CMD_FAIL_CODE,
    NPU_CMD_FAIL_PTR,
    NPU_CMD_STATUS,
    NPU_CMD_STATUS_FAIL,
    NPU_CMD_STATUS_PASS,
    TCDM_TOTAL_BYTES,
    _axi_read32,
    format_pmu_report,
    hold_reset,
    load_firmware_elf_axi,
    monitor_command_buffer_pmu,
    pmu_direct_snapshot,
    program_command_queue,
    read_dtcm_word,
    read_l2_bytes,
    read_tcdm_bytes,
    release_fetch,
    release_reset,
    reset_dut,
    wait_for_host_irq,
    write_l2_bytes,
    write_tcdm_bytes,
)


INPUT_BASE = 0x80000000
OUTPUT_BASE = 0x80001000
INPUT2_BASE = 0x80002000
INVOCATION_BASE = 0x80040000
MODEL_BASE = 0x80041000
BINDING_TABLE_BASE = 0x80044000
WEIGHT_SCRATCH_OFFSET = 0x00010000
IFM_SCRATCH_OFFSET = 0x00020000
OFM_SCRATCH_OFFSET = 0x00030000

NAI_MODEL_MAGIC = 0x4D49414E
NAI_INVOCATION_MAGIC = 0x5649414E
NPU_CMD_FAIL_BAD_MODEL = 0xBADCD00B
NPU_CMD_FAIL_BAD_BINDING = 0xBADCD00C
NPU_CMD_FAIL_V2_OPERATION = 0xBADCD012


def _ref(region, index=0, offset=0):
    return struct.pack("<HHI", region, index, offset)


def _command_header(command_type, size, layer=0, tile=0, flags=0):
    return struct.pack("<HHIII", command_type, size, flags, layer, tile)


def _dma_1d(source, destination, length, direction, tile):
    command = _command_header(2, 64, tile=tile)
    command += source + destination
    command += struct.pack("<II6I", length, direction, 0, 0, 0, 0, 0, 0)
    assert len(command) == 64
    return command


def _dma_2d(source, destination, length, source_stride, destination_stride,
            repetitions, direction, tile):
    command = _command_header(3, 64, tile=tile)
    command += source + destination
    command += struct.pack(
        "<5I3I",
        length,
        source_stride,
        destination_stride,
        repetitions,
        direction,
        0,
        0,
        0,
    )
    assert len(command) == 64
    return command


def _dma_submit_2d(source, destination, length, source_stride,
                   destination_stride, repetitions, direction, tile):
    command = bytearray(_dma_2d(
        source, destination, length, source_stride, destination_stride,
        repetitions, direction, tile,
    ))
    struct.pack_into("<H", command, 0, 25)
    return bytes(command)


def _dma_wait(direction, tile):
    command = _command_header(27, 32, tile=tile) + struct.pack("<4I", direction, 0, 0, 0)
    assert len(command) == 32
    return command


def _dma_3d(source, destination, length, source_stride_2,
            destination_stride_2, repetitions_2, source_stride_3,
            destination_stride_3, repetitions_3, direction, tile):
    command = _command_header(4, 64, tile=tile)
    command += source + destination
    command += struct.pack(
        "<8I",
        length,
        source_stride_2,
        destination_stride_2,
        repetitions_2,
        source_stride_3,
        destination_stride_3,
        repetitions_3,
        direction,
    )
    assert len(command) == 64
    return command


def _binding(direction, index, data_type=1, dimensions=(1, 1, 1, 32)):
    element_bytes = 1 if data_type == 1 else 4
    byte_size = element_bytes
    for dimension in dimensions:
        byte_size *= dimension
    descriptor = struct.pack(
        "<6HI4IIIiI4I",
        direction,
        index,
        data_type,
        1,
        4,
        0,
        index,
        *dimensions,
        byte_size,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    )
    assert len(descriptor) == 64
    return descriptor


def _gemm(weights, ifm, ofm, dim_m, tile):
    command = _command_header(6, 96, tile=tile)
    command += weights + ifm + _ref(6) + ofm
    command += struct.pack("<4I8I", dim_m, 128, 128, 0, *([0] * 8))
    assert len(command) == 96
    return command


def _pointwise_c32(weights, ifm, partial, ofm, rows, input_groups, output_groups,
                   qparam_block, input_group_stride, output_group_stride, tile):
    command = _command_header(10, 96, tile=tile)
    command += weights + ifm + partial + ofm
    command += struct.pack("<6I6I", rows, input_groups, output_groups, qparam_block,
                           input_group_stride, output_group_stride, *([0] * 6))
    assert len(command) == 96
    return command


def _depthwise_c32(weights, ifm, ofm, input_h, input_w, output_h, output_w,
                   channels, stride_h, stride_w, pad_h, pad_w, qparam_block, tile):
    command = _command_header(11, 96, tile=tile)
    command += weights + ifm + ofm
    command += struct.pack(
        "<10I4I",
        input_h,
        input_w,
        output_h,
        output_w,
        channels,
        stride_h,
        stride_w,
        pad_h,
        pad_w,
        qparam_block,
        *([0] * 4),
    )
    assert len(command) == 96
    return command


def _afu_binary(lhs, rhs, ofm, length, mode, tile, bias=0):
    command = _command_header(13, 64, tile=tile)
    command += lhs + rhs + ofm
    command += struct.pack("<2Ii3I", length, mode, bias, 0, 0, 0)
    assert len(command) == 64
    return command


def _afu_lut(ifm, ofm, lut, length, tile):
    command = _command_header(12, 64, tile=tile)
    command += ifm + ofm + lut
    command += struct.pack("<I5I", length, 0, 0, 0, 0, 0)
    assert len(command) == 64
    return command


def _afu_binary_quant(lhs, rhs, ofm, length, mode, tile, *, lut_chain=False):
    command = _command_header(34, 96, tile=tile, flags=(1 << 3) if lut_chain else 0)
    command += lhs + rhs + ofm
    command += struct.pack(
        "<IiIiIiIiiiiiII",
        length,
        1,
        0,
        1,
        0,
        1,
        0,
        0,
        0,
        0,
        -128,
        127,
        0,
        mode,
    )
    assert len(command) == 96
    return command


def _linebuf_job(k_tiles, tile):
    linebuf = struct.pack(
        "<I8H4I14H4I",
        0,
        3, 3, 32, 2, 1, 1, 1, 1,
        96, 32, 32, 96,
        3, 3, 0, 0, 1, 1, 0, 1, 0, 1, 32, 0, 0, 0,
        k_tiles, 4, 0, 27,
    )
    gemm = struct.pack("<9I", 0, 0, 0, 0, 4, 0, 64, 2, 512)
    command = _command_header(9, 160, tile=tile) + linebuf + gemm
    command += struct.pack("<2I", 4, k_tiles) + bytes(20)
    assert len(command) == 160
    return command


def _copy_layout(source, destination, mode, dimensions, tile):
    command = _command_header(18, 96, tile=tile)
    command += source + destination
    source_layout, destination_layout = {
        1: (1, 2),
        2: (2, 1),
        3: (1, 3),
        4: (3, 1),
    }[mode]
    channels = dimensions[3]
    compact_stride = channels
    native_stride = ((channels + 31) // 32) * 32
    command += struct.pack(
        "<4H4I3I7I",
        mode,
        source_layout,
        destination_layout,
        1,
        *dimensions,
        channels,
        compact_stride if mode == 1 else native_stride,
        native_stride if mode == 1 else compact_stride,
        *([0] * 7),
    )
    assert len(command) == 96
    return command


def _afu_dfl16(source, destination, scratch, exp_lut, recip_lut, tile):
    command = _command_header(28, 96, tile=tile)
    command += source + destination + scratch + exp_lut + recip_lut
    command += struct.pack("<2I", 2100, 0)
    command += struct.pack("<iIiii3I", 51003, 8, -128, -128, 127, 0, 0, 0)
    assert len(command) == 96
    return command


def _package(commands, constants, bindings, command_count, required_tcdm_bytes,
             input_count, output_count, qparams=b""):
    payloads = [commands, constants, b"", bindings, qparams]
    section_types = [1, 2, 3, 4, 5]
    element_counts = [command_count + 1, len(constants), 0,
                      input_count + output_count, len(qparams) // 32]
    section_table_offset = 64
    offset = section_table_offset + 5 * 32
    sections = []
    for section_type, element_count, payload in zip(section_types, element_counts, payloads):
        assert offset % 32 == 0 and len(payload) % 32 == 0
        sections.append(
            struct.pack(
                "<8I",
                section_type,
                0,
                offset,
                len(payload),
                32,
                element_count,
                0,
                0,
            )
        )
        offset += len(payload)

    header = struct.pack(
        "<IHH11I3I",
        NAI_MODEL_MAGIC,
        1,
        1,
        1,
        0,
        offset,
        5,
        section_table_offset,
        224,
        command_count,
        required_tcdm_bytes,
        32,
        input_count,
        output_count,
        0,
        0,
        0,
    )
    model = header + b"".join(sections) + b"".join(payloads)
    assert len(header) == 64 and len(model) == offset
    return model


def build_model():
    commands = b"".join(
        [
            _dma_1d(_ref(3), _ref(6), 32, 0, 0),
            _dma_1d(_ref(6), _ref(4), 32, 1, 1),
            _command_header(0, 32, tile=2).ljust(32, b"\x00"),
        ]
    )
    bindings = _binding(1, 0) + _binding(2, 0)
    return _package(commands, b"", bindings, 2, 32, 1, 1)


def build_unaligned_dma_model(dimension):
    binding_bytes = 192
    if dimension == 1:
        commands = [
            _dma_1d(_ref(3, offset=3), _ref(6, offset=5), 37, 0, 0),
            _dma_1d(_ref(6, offset=5), _ref(4, offset=7), 37, 1, 1),
        ]
        copies = [(3, 7, 37)]
    elif dimension == 2:
        commands = [
            _dma_2d(_ref(3, offset=3), _ref(6),
                    3, 3, 32, 11, 0, 0),
            _dma_2d(_ref(6), _ref(4, offset=5),
                    3, 32, 3, 11, 1, 1),
        ]
        copies = [(3 + row * 3, 5 + row * 3, 3) for row in range(11)]
    elif dimension == 3:
        commands = [
            _dma_3d(_ref(3, offset=3), _ref(6),
                    31, 31, 32, 2, 67, 96, 2, 0, 0),
            _dma_3d(_ref(6), _ref(4, offset=7),
                    31, 32, 31, 2, 96, 67, 2, 1, 1),
        ]
        copies = [
            (3 + plane * 67 + row * 31,
             7 + plane * 67 + row * 31,
             31)
            for plane in range(2)
            for row in range(2)
        ]
    else:
        raise ValueError(f"unsupported DMA dimension {dimension}")
    commands.append(_command_header(0, 32, tile=2).ljust(32, b"\x00"))
    bindings = (
        _binding(1, 0, dimensions=(1, 1, 1, binding_bytes))
        + _binding(2, 0, dimensions=(1, 1, 1, binding_bytes))
    )
    return (
        _package(b"".join(commands), b"", bindings, 2, 384, 1, 1),
        copies,
        binding_bytes,
    )


def build_async_dma_2d_wait_model():
    row_bytes = 1280
    rows = 16
    binding_bytes = row_bytes * rows
    commands = b"".join(
        [
            _dma_submit_2d(
                _ref(3), _ref(6, offset=0x19540), row_bytes,
                row_bytes, 1312, rows, 0, 0,
            ),
            _dma_2d(
                _ref(6, offset=0x20B20), _ref(6, offset=0x19020),
                row_bytes, row_bytes, row_bytes, 1, 2, 1,
            ),
            _dma_wait(0, 2),
            _dma_2d(
                _ref(6, offset=0x19540), _ref(4), row_bytes,
                1312, row_bytes, rows, 1, 3,
            ),
            _command_header(0, 32, tile=4).ljust(32, b"\x00"),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=(1, 1, 1, binding_bytes))
        + _binding(2, 0, dimensions=(1, 1, 1, binding_bytes))
    )
    return (
        _package(commands, b"", bindings, 4, 0x24000, 1, 1),
        binding_bytes,
    )


def build_async_dma_before_afu_lut_model():
    afu_bytes = 4096
    input_bytes = 0x6000
    lut = bytes(range(256))
    commands = b"".join(
        [
            _dma_1d(_ref(3), _ref(6), afu_bytes, 0, 0),
            _dma_2d(
                _ref(6, offset=0x5A900), _ref(6, offset=0x53800),
                14, 14, 14, 1, 2, 1,
            ),
            _dma_submit_2d(
                _ref(3, offset=0x1000), _ref(6, offset=0x54620),
                14, 14, 0xE20, 8, 0, 2,
            ),
            _dma_2d(
                _ref(6, offset=0x62820), _ref(6, offset=0x5B720),
                14, 14, 14, 1, 2, 3,
            ),
            _dma_submit_2d(
                _ref(3, offset=0x2000), _ref(6, offset=0x5C540),
                14, 14, 0xE20, 8, 0, 4,
            ),
            _dma_2d(
                _ref(6, offset=0x6A740), _ref(6, offset=0x63640),
                14, 14, 14, 1, 2, 5,
            ),
            _dma_submit_2d(
                _ref(3, offset=0x3000), _ref(6, offset=0x64460),
                14, 14, 0xE20, 8, 0, 6,
            ),
            _afu_lut(
                _ref(6), _ref(6, offset=0x49800), _ref(1), afu_bytes, 7,
            ),
            _dma_wait(0, 8),
            _dma_1d(
                _ref(6, offset=0x49800), _ref(4), afu_bytes, 1, 9,
            ),
            _command_header(0, 32, tile=10).ljust(32, b"\x00"),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=(1, 1, 1, input_bytes))
        + _binding(2, 0, dimensions=(1, 1, 1, afu_bytes))
    )
    return (
        _package(commands, lut, bindings, 10, 0x6B000, 1, 1),
        input_bytes,
        afu_bytes,
    )


def build_dma_transfer_id_stress_model(iterations):
    assert iterations > 0
    commands = []
    for iteration in range(iterations):
        commands.extend(
            [
                _dma_submit_2d(
                    _ref(3), _ref(6), 4, 4, 4, 1, 0, iteration * 2,
                ),
                _dma_wait(0, iteration * 2 + 1),
            ]
        )
    commands.extend(
        [
            _dma_1d(_ref(6), _ref(4), 4, 1, iterations * 2),
            _command_header(0, 32, tile=iterations * 2 + 1).ljust(
                32, b"\x00"
            ),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=(1, 1, 1, 4))
        + _binding(2, 0, dimensions=(1, 1, 1, 4))
    )
    return _package(
        b"".join(commands), b"", bindings, iterations * 2 + 1, 32, 1, 1
    )


def build_layout_model():
    dimensions = (1, 2, 2, 33)
    commands = b"".join(
        [
            _copy_layout(_ref(3), _ref(6), 1, dimensions, 0),
            _command_header(0, 32, tile=2).ljust(32, b"\x00"),
        ]
    )
    bindings = _binding(1, 0, dimensions=dimensions) + _binding(2, 0, dimensions=dimensions)
    return _package(commands, b"", bindings, 2, 256, 1, 1)


def build_c32_layout_model():
    dimensions = (1, 2, 2, 33)
    commands = b"".join(
        [
            _copy_layout(_ref(3), _ref(6), 3, dimensions, 0),
            _copy_layout(_ref(6), _ref(4), 4, dimensions, 1),
            _command_header(0, 32, tile=2).ljust(32, b"\x00"),
        ]
    )
    bindings = _binding(1, 0, dimensions=dimensions) + _binding(2, 0, dimensions=dimensions)
    return _package(commands, b"", bindings, 2, 256, 1, 1)


def build_afu_add_model():
    dimensions = (1, 2, 2, 32)
    tensor_bytes = 2 * 2 * 32
    commands = b"".join(
        [
            _copy_layout(_ref(3, 0), _ref(6), 3, dimensions, 0),
            _copy_layout(_ref(3, 1), _ref(6, offset=0x200), 3, dimensions, 1),
            _afu_binary(
                _ref(6), _ref(6, offset=0x200), _ref(6, offset=0x400),
                tensor_bytes, 1, 2,
            ),
            _copy_layout(_ref(6, offset=0x400), _ref(4), 4, dimensions, 3),
            _command_header(0, 32, tile=4).ljust(32, b"\x00"),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=dimensions)
        + _binding(1, 1, dimensions=dimensions)
        + _binding(2, 0, dimensions=dimensions)
    )
    return _package(commands, b"", bindings, 4, 0x480, 2, 1)


def build_afu_add_bias_model(bias):
    dimensions = (1, 2, 2, 32)
    tensor_bytes = 2 * 2 * 32
    commands = b"".join(
        [
            _copy_layout(_ref(3, 0), _ref(6), 3, dimensions, 0),
            _copy_layout(_ref(3, 1), _ref(6, offset=0x200), 3, dimensions, 1),
            _afu_binary(
                _ref(6), _ref(6, offset=0x200), _ref(6, offset=0x400),
                tensor_bytes, 2, 2, bias,
            ),
            _copy_layout(_ref(6, offset=0x400), _ref(4), 4, dimensions, 3),
            _command_header(0, 32, tile=4).ljust(32, b"\x00"),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=dimensions)
        + _binding(1, 1, dimensions=dimensions)
        + _binding(2, 0, dimensions=dimensions)
    )
    return _package(commands, b"", bindings, 4, 0x480, 2, 1)


def build_afu_lut_binary_chain_model(length=73):
    lut = bytes((index * 3 + 7) & 0xFF for index in range(256))
    dimensions = (1, 1, 1, length)
    commands = b"".join(
        [
            _dma_1d(_ref(3, 0), _ref(6), length, 0, 0),
            _dma_1d(_ref(3, 1), _ref(6, offset=0x100), length, 0, 1),
            # Run one LUT command to stage and activate the table. Its output is
            # intentionally temporary; the following command exercises the
            # direct LUT-output-to-binary pipeline instead of reading it back.
            _afu_lut(_ref(6), _ref(6, offset=0x200), _ref(1), length, 2),
            _afu_binary_quant(
                _ref(6),
                _ref(6, offset=0x100),
                _ref(6, offset=0x300),
                length,
                0,
                3,
                lut_chain=True,
            ),
            _dma_1d(_ref(6, offset=0x300), _ref(4), length, 1, 4),
            _command_header(0, 32, tile=5).ljust(32, b"\x00"),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=dimensions)
        + _binding(1, 1, dimensions=dimensions)
        + _binding(2, 0, dimensions=dimensions)
    )
    return _package(commands, lut, bindings, 5, 0x380, 2, 1), lut


def _dfl_exp_lut_value(index):
    if index == 0:
        return 32768
    neg_delta = 256 - index
    shift = neg_delta >> 4
    fraction = neg_delta & 15
    base = 1 if shift >= 15 else 32768 >> shift
    next_value = base >> 1 if base > 1 else 1
    return (((base * (16 - fraction)) + (next_value * fraction) + 8) >> 4) or 1


def _dfl_recip_lut_value(index):
    midpoint_q9 = 513 + index * 2
    return ((1 << 37) + (midpoint_q9 >> 1)) // midpoint_q9


def _dfl16_q8(values):
    maximum = max(values)
    exponentials = [
        _dfl_exp_lut_value((value - maximum) & 0xFF) for value in values
    ]
    total = sum(exponentials)
    weighted = sum(index * value for index, value in enumerate(exponentials))
    shift = total.bit_length() - 1
    normalized = (total << 8) >> shift
    reciprocal_index = min(max(normalized, 256), 511) & 0xFF
    reciprocal = _dfl_recip_lut_value(reciprocal_index)
    total_shift = 28 + shift
    return min(
        (((weighted << 8) * reciprocal) + (1 << (total_shift - 1))) >> total_shift,
        0xFFFF,
    )


def build_afu_dfl16_model():
    locations = 2100
    source_bytes = 144 * locations
    output_bytes = 4 * locations
    source_offset = 0
    destination_offset = source_bytes
    scratch_offset = (destination_offset + output_bytes + 31) & ~31
    required_tcdm = scratch_offset + 34 * 32
    constants = b"".join(
        struct.pack("<I", _dfl_exp_lut_value(index)) for index in range(256)
    ) + b"".join(
        struct.pack("<I", _dfl_recip_lut_value(index)) for index in range(256)
    )
    commands = b"".join(
        [
            _dma_1d(_ref(3), _ref(6, offset=source_offset), source_bytes, 0, 0),
            _afu_dfl16(
                _ref(6, offset=source_offset),
                _ref(6, offset=destination_offset),
                _ref(6, offset=scratch_offset),
                _ref(1),
                _ref(1, offset=1024),
                1,
            ),
            _dma_1d(_ref(6, offset=destination_offset), _ref(4), output_bytes, 1, 2),
            _command_header(0, 32, tile=3).ljust(32, b"\x00"),
        ]
    )
    bindings = (
        _binding(1, 0, dimensions=(1, 1, 144, locations))
        + _binding(2, 0, dimensions=(1, 1, 4, locations))
    )
    return _package(commands, constants, bindings, 3, required_tcdm, 1, 1)


def build_row32_layout_model(channels, height, width):
    dimensions = (1, height, width, channels)
    commands = b"".join(
        [
            _copy_layout(_ref(3), _ref(6), 1, dimensions, 0),
            _copy_layout(_ref(6), _ref(4), 2, dimensions, 1),
            _command_header(0, 32, tile=2).ljust(32, b"\x00"),
        ]
    )
    compact_bytes = height * width * channels
    bindings = _binding(1, 0, dimensions=dimensions) + _binding(2, 0, dimensions=dimensions)
    return _package(
        commands,
        b"",
        bindings,
        2,
        ((channels + 31) // 32) * height * width * 32,
        1,
        1,
    ), compact_bytes


def build_pointwise_c32_model(height=2, width=2, channels=64, output_channels=None,
                              clamp_min=-128, clamp_max=127, qparam_specs=None,
                              qparam_block_delta=0):
    rows = height * width
    if output_channels is None:
        output_channels = channels
    input_groups = (channels + 31) // 32
    output_groups = (output_channels + 31) // 32
    weights = bytes([1]) * (output_groups * input_groups * 32 * 32)
    if qparam_specs is None:
        qparam_specs = [(0, 1 << 30, 30, 0, clamp_min, clamp_max)] * (output_groups * 32)
    assert len(qparam_specs) == output_groups * 32
    qparams = b"".join(
        struct.pack("<iiIiiiII", *spec, 0, 0) for spec in qparam_specs
    )
    input_dimensions = (1, height, width, channels)
    output_dimensions = (1, height, width, output_channels)
    commands = [_copy_layout(_ref(3), _ref(6), 3, input_dimensions, 0)]
    for output_group in range(output_groups):
        commands.append(
            _command_header(5, 32, tile=output_group * 2 + 1) +
            struct.pack("<4I", output_group * 32, 32, output_group, 0)
        )
        commands.append(
            _pointwise_c32(
                _ref(1, offset=output_group * input_groups * 32 * 32),
                _ref(6),
                _ref(6, offset=0x1000) if input_groups > 1 else _ref(0),
                _ref(6, offset=0x2000 + output_group * rows * 32),
                rows, input_groups, 1, output_group + qparam_block_delta,
                rows * 32, rows * 32, output_group * 2 + 2
            )
        )
    commands.extend([
        _copy_layout(_ref(6, offset=0x2000), _ref(4), 4, output_dimensions, 3),
        _command_header(0, 32, tile=len(commands)).ljust(32, b"\x00"),
    ])
    commands = b"".join(commands)
    bindings = _binding(1, 0, dimensions=input_dimensions) + _binding(2, 0, dimensions=output_dimensions)
    return _package(commands, weights, bindings, 2 + output_groups * 2, 0x2200, 1, 1, qparams)


def build_depthwise_c32_model(height=3, width=3, channels=32, stride=1,
                              repetitions=1):
    assert repetitions > 0
    groups = (channels + 31) // 32
    weights = bytearray(groups * 3 * 3 * 32)
    for group in range(groups):
        for lane in range(32):
            channel = group * 32 + lane
            if channel < channels:
                weights[((group * 9 + 4) * 32) + lane] = 1
    qparams = b"".join(
        struct.pack("<iiIiiiII", 0, 1 << 30, 30, 0, -128, 127, 0, 0)
        for _ in range(groups * 32)
    )
    output_height = ((height - 1) // stride) + 1
    output_width = ((width - 1) // stride) + 1
    input_dimensions = (1, height, width, channels)
    output_dimensions = (1, output_height, output_width, channels)
    input_pixels = height * width
    output_pixels = output_height * output_width
    commands = [_copy_layout(_ref(3), _ref(6), 3, input_dimensions, 0)]
    for group in range(groups):
        valid_channels = min(32, channels - group * 32)
        commands.append(
            _command_header(5, 32, tile=len(commands)) +
            struct.pack("<4I", group * 32, 32, group, 0)
        )
        for _ in range(repetitions):
            commands.append(
                _depthwise_c32(
                    _ref(1, offset=group * 9 * 32),
                    _ref(6, offset=group * input_pixels * 32),
                    _ref(6, offset=0x1000 + group * output_pixels * 32),
                    height, width, output_height, output_width, valid_channels,
                    stride, stride, 1, 1, group, len(commands),
                )
            )
    commands.extend([
        _copy_layout(_ref(6, offset=0x1000), _ref(4), 4, output_dimensions,
                     len(commands)),
        _command_header(0, 32, tile=len(commands)).ljust(32, b"\x00"),
    ])
    command_count = len(commands) - 1
    commands = b"".join(commands)
    bindings = _binding(1, 0, dimensions=input_dimensions) + _binding(2, 0, dimensions=output_dimensions)
    return _package(commands, bytes(weights), bindings, command_count, 0x2200, 1, 1, qparams)


def build_pointwise_depthwise_chain_model(height=2, width=2):
    channels = 32
    rows = height * width
    input_dimensions = (1, height, width, channels)
    output_dimensions = input_dimensions
    pointwise_weights = bytes([1]) * (32 * 32)
    depthwise_weights = bytearray(9 * 32)
    depthwise_weights[4 * 32:5 * 32] = bytes([1]) * 32
    constants = pointwise_weights + bytes(depthwise_weights)
    qparam = struct.pack("<iiIiiiII", 0, 1 << 30, 30, 0, -128, 127, 0, 0)
    qparams = qparam * 64
    commands = [
        _copy_layout(_ref(3), _ref(6), 3, input_dimensions, 0),
        _command_header(5, 32, tile=1) + struct.pack("<4I", 0, 32, 0, 0),
        _pointwise_c32(
            _ref(1), _ref(6), _ref(0), _ref(6, offset=0x2000),
            rows, 1, 1, 0, rows * 32, rows * 32, 2,
        ),
        _command_header(5, 32, tile=3) + struct.pack("<4I", 32, 32, 1, 0),
        _depthwise_c32(
            _ref(1, offset=len(pointwise_weights)), _ref(6, offset=0x2000),
            _ref(6, offset=0x3000), height, width, height, width,
            channels, 1, 1, 1, 1, 1, 4,
        ),
        _copy_layout(_ref(6, offset=0x3000), _ref(4), 4, output_dimensions, 5),
        _command_header(0, 32, tile=6).ljust(32, b"\x00"),
    ]
    bindings = _binding(1, 0, dimensions=input_dimensions) + _binding(
        2, 0, dimensions=output_dimensions
    )
    return _package(
        b"".join(commands), constants, bindings, 6, 0x3100, 1, 1, qparams
    )


def build_gemm_model(dimensions):
    weights = bytes(1 if row == column else 0 for row in range(32) for column in range(32))
    commands = [
        _dma_1d(_ref(1), _ref(6, offset=WEIGHT_SCRATCH_OFFSET), len(weights), 0, 0)
    ]
    bindings = []
    for index, dim_m in enumerate(dimensions):
        commands.extend(
            [
                _dma_1d(_ref(3, index), _ref(6, offset=IFM_SCRATCH_OFFSET), dim_m * 32, 0, index * 3 + 1),
                _gemm(
                    _ref(6, offset=WEIGHT_SCRATCH_OFFSET),
                    _ref(6, offset=IFM_SCRATCH_OFFSET),
                    _ref(6, offset=OFM_SCRATCH_OFFSET),
                    dim_m,
                    index * 3 + 2,
                ),
                _dma_1d(
                    _ref(6, offset=OFM_SCRATCH_OFFSET),
                    _ref(4, index),
                    dim_m * 32 * 4,
                    1,
                    index * 3 + 3,
                ),
            ]
        )
        bindings.append(_binding(1, index, dimensions=(1, 1, dim_m, 32)))
    for index, dim_m in enumerate(dimensions):
        bindings.append(_binding(2, index, data_type=4, dimensions=(1, 1, dim_m, 32)))
    commands.append(_command_header(0, 32, tile=len(commands)).ljust(32, b"\x00"))
    required_tcdm_bytes = OFM_SCRATCH_OFFSET + max(dimensions) * 32 * 4
    return _package(
        b"".join(commands),
        weights,
        b"".join(bindings),
        len(commands) - 1,
        required_tcdm_bytes,
        len(dimensions),
        len(dimensions),
    )


def build_invocation(model):
    binding_addresses = struct.pack(
        "<HHIIIHHIII",
        1,
        0,
        INPUT_BASE,
        32,
        0,
        2,
        0,
        OUTPUT_BASE,
        32,
        0,
    )
    invocation = struct.pack(
        "<IHH6I8I",
        NAI_INVOCATION_MAGIC,
        1,
        0,
        64,
        MODEL_BASE,
        len(model),
        BINDING_TABLE_BASE,
        2,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    )
    assert len(invocation) == 64 and len(binding_addresses) == 32
    return invocation, binding_addresses


def build_invocation_with_bindings(
    model,
    bindings,
    model_base=MODEL_BASE,
    binding_table_base=BINDING_TABLE_BASE,
):
    binding_addresses = b"".join(
        struct.pack("<HHIII", direction, index, base, byte_size, 0)
        for direction, index, base, byte_size in bindings
    )
    invocation = struct.pack(
        "<IHH6I8I",
        NAI_INVOCATION_MAGIC,
        1,
        0,
        64,
        model_base,
        len(model),
        binding_table_base,
        len(bindings),
        0,
        *([0] * 8),
    )
    return invocation, binding_addresses


def _model_binding_descriptors(model):
    section_count = struct.unpack_from("<I", model, 20)[0]
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    bindings_offset = None
    bindings_size = 0
    binding_count = 0
    for index in range(section_count):
        descriptor = section_table_offset + index * 32
        section_type, _flags, offset, size, _alignment, count = struct.unpack_from(
            "<6I", model, descriptor
        )
        if section_type == 4:
            bindings_offset = offset
            bindings_size = size
            binding_count = count
            break
    if bindings_offset is None or bindings_size < binding_count * 64:
        raise ValueError("model has an invalid bindings section")

    bindings = []
    for binding in range(binding_count):
        offset = bindings_offset + binding * 64
        direction, index = struct.unpack_from("<2H", model, offset)
        dimensions = struct.unpack_from("<4I", model, offset + 16)
        byte_size = struct.unpack_from("<I", model, offset + 32)[0]
        bindings.append((direction, index, byte_size, dimensions))
    return bindings


def _signed_input(dim_m, seed):
    values = [((row * 3 + column + seed) % 15) - 7 for row in range(dim_m) for column in range(32)]
    return bytes(value & 0xFF for value in values), values


def _mm_clamp(value, lower=-128, upper=127):
    return max(lower, min(upper, value))


def _mm_input_value(row, column, channel):
    return ((row * 3 + column * 5 + channel * 7 + 1) % 5) - 2


def _mm_stem_weight(kh, kw, input_channel, output_channel):
    return (
        (
            kh * 2
            + kw * 3
            + input_channel * 5
            + output_channel * 7
            + 2
        )
        % 3
    ) - 1


def _mm_depthwise_weight(tag, kh, kw, channel):
    return ((tag * 3 + kh * 5 + kw * 7 + channel * 2 + 1) % 3) - 1


def _mm_pointwise_weight(tag, input_channel, output_channel):
    if tag == 5:
        return 1 if input_channel == output_channel else 0
    return (
        (tag * 5 + input_channel * 3 + output_channel * 7 + 4) % 3
    ) - 1


def _mm_conv_weight(tag, kh, kw, input_channel, output_channel):
    return (
        (
            tag * 11
            + kh * 3
            + kw * 5
            + input_channel * 7
            + output_channel * 2
            + 6
        )
        % 3
    ) - 1


def _mm_conv2d(
    source,
    height,
    width,
    input_channels,
    output_channels,
    kernel,
    stride,
    weight,
    activation=None,
):
    output_height = (height + stride - 1) // stride
    output_width = (width + stride - 1) // stride
    total_pad_h = max(
        0, (output_height - 1) * stride + kernel - height
    )
    total_pad_w = max(
        0, (output_width - 1) * stride + kernel - width
    )
    pad_top = total_pad_h // 2
    pad_left = total_pad_w // 2
    output = [0] * (output_height * output_width * output_channels)
    for output_y in range(output_height):
        for output_x in range(output_width):
            output_pixel = (
                output_y * output_width + output_x
            ) * output_channels
            for output_channel in range(output_channels):
                accumulator = 0
                for kh in range(kernel):
                    input_y = output_y * stride + kh - pad_top
                    if input_y < 0 or input_y >= height:
                        continue
                    for kw in range(kernel):
                        input_x = output_x * stride + kw - pad_left
                        if input_x < 0 or input_x >= width:
                            continue
                        input_pixel = (
                            input_y * width + input_x
                        ) * input_channels
                        for input_channel in range(input_channels):
                            accumulator += (
                                source[input_pixel + input_channel]
                                * weight(
                                    kh,
                                    kw,
                                    input_channel,
                                    output_channel,
                                )
                            )
                if activation is None:
                    output[output_pixel + output_channel] = _mm_clamp(
                        accumulator
                    )
                else:
                    output[output_pixel + output_channel] = _mm_clamp(
                        accumulator, *activation
                    )
    return output, output_height, output_width


def _mm_depthwise(
    source,
    height,
    width,
    channels,
    stride,
    tag,
    activation=None,
):
    output_height = (height + stride - 1) // stride
    output_width = (width + stride - 1) // stride
    total_pad_h = max(0, (output_height - 1) * stride + 3 - height)
    total_pad_w = max(0, (output_width - 1) * stride + 3 - width)
    pad_top = total_pad_h // 2
    pad_left = total_pad_w // 2
    output = [0] * (output_height * output_width * channels)
    for output_y in range(output_height):
        for output_x in range(output_width):
            output_pixel = (output_y * output_width + output_x) * channels
            for channel in range(channels):
                accumulator = 0
                for kh in range(3):
                    input_y = output_y * stride + kh - pad_top
                    if input_y < 0 or input_y >= height:
                        continue
                    for kw in range(3):
                        input_x = output_x * stride + kw - pad_left
                        if input_x < 0 or input_x >= width:
                            continue
                        input_pixel = (input_y * width + input_x) * channels
                        accumulator += (
                            source[input_pixel + channel]
                            * _mm_depthwise_weight(tag, kh, kw, channel)
                        )
                if activation is None:
                    output[output_pixel + channel] = _mm_clamp(accumulator)
                else:
                    output[output_pixel + channel] = _mm_clamp(
                        accumulator, *activation
                    )
    return output, output_height, output_width


def _mm_add(lhs, rhs):
    return [_mm_clamp(left + right) for left, right in zip(lhs, rhs)]


def _mm_global_avgpool(source, height, width, channels):
    pixels = height * width
    output = []
    for channel in range(channels):
        total = sum(
            source[pixel * channels + channel] for pixel in range(pixels)
        )
        sign = -1 if total < 0 else 1
        output.append(sign * (abs(total) // pixels))
    return output


def _micro_mobilenet_input_values():
    return [
        _mm_input_value(row, column, channel)
        for row in range(96)
        for column in range(96)
        for channel in range(3)
    ]


def _micro_mobilenet_stage10_values(input_values):
    stem, _, _ = _mm_conv2d(
        input_values,
        96,
        96,
        3,
        32,
        3,
        2,
        _mm_stem_weight,
        activation=(0, 6),
    )
    dw0, _, _ = _mm_depthwise(
        stem, 48, 48, 32, 1, tag=0, activation=(0, 6)
    )
    pw0, _, _ = _mm_conv2d(
        dw0,
        48,
        48,
        32,
        32,
        1,
        1,
        lambda _kh, _kw, ic, oc: _mm_pointwise_weight(0, ic, oc),
    )
    residual0 = _mm_add(pw0, stem)
    dw1, _, _ = _mm_depthwise(
        residual0, 48, 48, 32, 2, tag=1
    )
    pw1, _, _ = _mm_conv2d(
        dw1,
        24,
        24,
        32,
        64,
        1,
        1,
        lambda _kh, _kw, ic, oc: _mm_pointwise_weight(1, ic, oc),
        activation=(0, 6),
    )
    pw2, _, _ = _mm_conv2d(
        pw1,
        24,
        24,
        64,
        128,
        1,
        1,
        lambda _kh, _kw, ic, oc: _mm_pointwise_weight(2, ic, oc),
    )
    dw2, _, _ = _mm_depthwise(pw2, 24, 24, 128, 1, tag=2)
    pw3, _, _ = _mm_conv2d(
        dw2,
        24,
        24,
        128,
        64,
        1,
        1,
        lambda _kh, _kw, ic, oc: _mm_pointwise_weight(3, ic, oc),
    )
    residual1 = _mm_add(pw3, pw1)
    return residual1


def _micro_mobilenet_input_and_expected():
    input_values = _micro_mobilenet_input_values()
    residual1 = _micro_mobilenet_stage10_values(input_values)
    validate, _, _ = _mm_conv2d(
        residual1,
        24,
        24,
        64,
        64,
        3,
        1,
        lambda kh, kw, ic, oc: _mm_conv_weight(
            4, kh, kw, ic, oc
        ),
    )
    pooled = _mm_global_avgpool(validate, 24, 24, 64)
    classifier, _, _ = _mm_conv2d(
        pooled,
        1,
        1,
        64,
        32,
        1,
        1,
        lambda _kh, _kw, ic, oc: _mm_pointwise_weight(5, ic, oc),
    )
    return (
        bytes(value & 0xFF for value in input_values),
        bytes(value & 0xFF for value in classifier),
    )


def _micro_mobilenet_stage1_input_and_expected():
    input_values = _micro_mobilenet_input_values()
    output, output_height, output_width = _mm_conv2d(
        input_values,
        96,
        96,
        3,
        32,
        3,
        2,
        _mm_stem_weight,
        activation=(0, 6),
    )
    assert (output_height, output_width) == (48, 48)
    return (
        bytes(value & 0xFF for value in input_values),
        bytes(value & 0xFF for value in output),
    )


def _micro_mobilenet_stage10_input_and_expected():
    input_values = _micro_mobilenet_input_values()
    output = _micro_mobilenet_stage10_values(input_values)
    return (
        bytes(value & 0xFF for value in input_values),
        bytes(value & 0xFF for value in output),
    )


def _compile_fully_connected_model(asymmetric=False):
    default_root = Path(__file__).resolve().parents[4] / "neural-compiler"
    compiler_root = Path(os.environ.get("NEURAL_COMPILER_ROOT", default_root)).resolve()
    extension_modules = list((compiler_root / "ethosu").glob("regor*.so"))
    if not extension_modules:
        raise RuntimeError(
            f"Neural compiler Python extension is not built under {compiler_root}/ethosu"
        )

    stem = (
        "fully_connected_asym_k33_n34"
        if asymmetric
        else "fully_connected_k33_n34"
    )
    fixture = Path(__file__).with_name(f"{stem}.tflite.b64")
    model_data = base64.b64decode(fixture.read_text(encoding="ascii"))
    with tempfile.TemporaryDirectory(prefix="neural-ai-compiled-model-") as temporary_dir:
        temporary_path = Path(temporary_dir)
        input_path = temporary_path / f"{stem}.tflite"
        output_path = temporary_path / "output"
        input_path.write_bytes(model_data)
        command = [
            sys.executable,
            "-c",
            "import sys; from ethosu.vela.vela import main; raise SystemExit(main(sys.argv[1:]))",
            "--accelerator-config=neural-ai",
            "--output-format=nai",
            f"--output-dir={output_path}",
            str(input_path),
        ]
        environment = os.environ.copy()
        environment["PYTHONPATH"] = os.pathsep.join(
            [str(compiler_root), environment.get("PYTHONPATH", "")]
        ).rstrip(os.pathsep)
        result = subprocess.run(
            command,
            cwd=compiler_root,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Neural compiler failed ({result.returncode}):\n{result.stdout}\n{result.stderr}"
            )
        package = (output_path / f"{stem}.nai").read_bytes()
    assert package[:4] == b"NAIM"
    return package


def _compile_pointwise_conv_model():
    default_root = Path(__file__).resolve().parents[4] / "neural-compiler"
    compiler_root = Path(os.environ.get("NEURAL_COMPILER_ROOT", default_root)).resolve()
    extension_modules = list((compiler_root / "ethosu").glob("regor*.so"))
    if not extension_modules:
        raise RuntimeError(
            f"Neural compiler Python extension is not built under {compiler_root}/ethosu"
        )

    fixture = Path(__file__).with_name("pointwise_conv_h2w3_k33_n34.tflite.b64")
    model_data = base64.b64decode(fixture.read_text(encoding="ascii"))
    with tempfile.TemporaryDirectory(prefix="neural-ai-compiled-conv-") as temporary_dir:
        temporary_path = Path(temporary_dir)
        input_path = temporary_path / "pointwise_conv_h2w3_k33_n34.tflite"
        output_path = temporary_path / "output"
        input_path.write_bytes(model_data)
        command = [
            sys.executable,
            "-c",
            "import sys; from ethosu.vela.vela import main; raise SystemExit(main(sys.argv[1:]))",
            "--accelerator-config=neural-ai",
            "--output-format=nai",
            f"--output-dir={output_path}",
            str(input_path),
        ]
        environment = os.environ.copy()
        environment["PYTHONPATH"] = os.pathsep.join(
            [str(compiler_root), environment.get("PYTHONPATH", "")]
        ).rstrip(os.pathsep)
        result = subprocess.run(
            command,
            cwd=compiler_root,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Neural compiler failed ({result.returncode}):\n{result.stdout}\n{result.stderr}"
            )
        package = (output_path / "pointwise_conv_h2w3_k33_n34.nai").read_bytes()
    assert package[:4] == b"NAIM"
    return package


def _compile_tflite_fixture_model(
    fixture_stem, temporary_prefix, compressed=False
):
    default_root = Path(__file__).resolve().parents[4] / "neural-compiler"
    compiler_root = Path(os.environ.get("NEURAL_COMPILER_ROOT", default_root)).resolve()
    extension_modules = list((compiler_root / "ethosu").glob("regor*.so"))
    if not extension_modules:
        raise RuntimeError(
            f"Neural compiler Python extension is not built under {compiler_root}/ethosu"
        )

    suffix = ".tflite.zlib.b64" if compressed else ".tflite.b64"
    fixture = Path(__file__).with_name(f"{fixture_stem}{suffix}")
    model_data = base64.b64decode(fixture.read_text(encoding="ascii"))
    if compressed:
        model_data = zlib.decompress(model_data)
    with tempfile.TemporaryDirectory(prefix=temporary_prefix) as temporary_dir:
        temporary_path = Path(temporary_dir)
        input_path = temporary_path / f"{fixture_stem}.tflite"
        output_path = temporary_path / "output"
        input_path.write_bytes(model_data)
        command = [
            sys.executable,
            "-c",
            "import sys; from ethosu.vela.vela import main; raise SystemExit(main(sys.argv[1:]))",
            "--accelerator-config=neural-ai",
            "--output-format=nai",
            f"--output-dir={output_path}",
            str(input_path),
        ]
        environment = os.environ.copy()
        environment["PYTHONPATH"] = os.pathsep.join(
            [str(compiler_root), environment.get("PYTHONPATH", "")]
        ).rstrip(os.pathsep)
        result = subprocess.run(
            command,
            cwd=compiler_root,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Neural compiler failed ({result.returncode}):\n{result.stdout}\n{result.stderr}"
            )
        package = (output_path / f"{fixture_stem}.nai").read_bytes()
    assert package[:4] == b"NAIM"
    return package


def _compile_generic_k3_conv_model():
    return _compile_tflite_fixture_model(
        "generic_k3_conv_h4w4_k32_n32", "neural-ai-compiled-k3-"
    )


def _compile_generic_k3_c48_conv_model():
    return _compile_tflite_fixture_model(
        "generic_k3_conv_h4w4_k48_n32", "neural-ai-compiled-k3-c48-", compressed=True
    )


def _compile_selected_yolo320_model():
    default_root = Path(__file__).resolve().parents[4] / "neural-compiler"
    compiler_root = Path(os.environ.get("NEURAL_COMPILER_ROOT", default_root)).resolve()
    model_path = compiler_root / "test/model/yolov8n_320_int8.tflite"
    extension_modules = list((compiler_root / "ethosu").glob("regor*.so"))
    if not extension_modules or not model_path.is_file():
        raise RuntimeError("Selected YOLO320 compiler model or Python extension is missing")
    with tempfile.TemporaryDirectory(prefix="neural-ai-compiled-yolo320-") as temporary_dir:
        output_path = Path(temporary_dir) / "output"
        command = [
            sys.executable,
            "-c",
            "import sys; from ethosu.vela.vela import main; raise SystemExit(main(sys.argv[1:]))",
            "--accelerator-config=neural-ai",
            "--output-format=nai",
            f"--output-dir={output_path}",
            str(model_path),
        ]
        environment = os.environ.copy()
        environment["PYTHONPATH"] = os.pathsep.join(
            [str(compiler_root), environment.get("PYTHONPATH", "")]
        ).rstrip(os.pathsep)
        result = subprocess.run(
            command,
            cwd=compiler_root,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Neural compiler failed ({result.returncode}):\n{result.stdout}\n{result.stderr}"
            )
        package = (output_path / "yolov8n_320_int8.nai").read_bytes()
    assert package[:4] == b"NAIM"
    return model_path, package


def _compile_selected_mobilenet224_model():
    default_root = Path(__file__).resolve().parents[4] / "neural-compiler"
    compiler_root = Path(os.environ.get("NEURAL_COMPILER_ROOT", default_root)).resolve()
    model_path = compiler_root / "test/model/mobilenet_v2_224_int8.tflite"
    extension_modules = list((compiler_root / "ethosu").glob("regor*.so"))
    if not extension_modules or not model_path.is_file():
        raise RuntimeError("Selected MobileNet224 compiler model or Python extension is missing")
    with tempfile.TemporaryDirectory(prefix="neural-ai-compiled-mobilenet224-") as temporary_dir:
        output_path = Path(temporary_dir) / "output"
        command = [
            sys.executable,
            "-c",
            "import sys; from ethosu.vela.vela import main; raise SystemExit(main(sys.argv[1:]))",
            "--accelerator-config=neural-ai",
            "--output-format=nai",
            f"--output-dir={output_path}",
            str(model_path),
        ]
        environment = os.environ.copy()
        environment["PYTHONPATH"] = os.pathsep.join(
            [str(compiler_root), environment.get("PYTHONPATH", "")]
        ).rstrip(os.pathsep)
        result = subprocess.run(
            command,
            cwd=compiler_root,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Neural compiler failed ({result.returncode}):\n{result.stdout}\n{result.stderr}"
            )
        package = (output_path / "mobilenet_v2_224_int8.nai").read_bytes()
    assert package[:4] == b"NAIM"
    return model_path, package


def _extract_selected_yolo320_command_prefix(model, command_count):
    return _extract_selected_yolo320_command_range(model, 0, command_count)


def _command_section(model):
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    section_count = struct.unpack_from("<I", model, 20)[0]
    for index in range(section_count):
        descriptor = section_table_offset + index * 32
        if struct.unpack_from("<I", model, descriptor)[0] == 1:
            offset, size = struct.unpack_from("<2I", model, descriptor + 8)
            return descriptor, offset, size
    raise ValueError("commands section is missing")


def _logical_command_records(model):
    _descriptor, commands_offset, commands_size = _command_section(model)
    if commands_offset > len(model) or commands_size > len(model) - commands_offset:
        raise ValueError("commands section exceeds model bounds")
    encoded = memoryview(model)[commands_offset : commands_offset + commands_size]
    declared_count = struct.unpack_from("<I", model, 32)[0]
    records = []
    offset = 0

    def read_header(data, position):
        if position > len(data) or len(data) - position < 16:
            raise ValueError("truncated command header")
        kind, size, flags = struct.unpack_from("<HHI", data, position)
        if size < 32 or size % 32 or size > len(data) - position:
            raise ValueError("invalid command size")
        if (flags & ~31 or (flags & 4 and kind != 12) or
                (flags & 8 and kind != 34) or (flags & 16 and kind != 14)):
            raise ValueError("invalid command flags")
        return kind, size, flags

    while offset < len(encoded):
        command_type, command_size, flags = read_header(encoded, offset)
        if command_type != 33:
            record = bytes(encoded[offset : offset + command_size])
            if command_type == 0:
                if (command_size != 32 or offset + command_size != len(encoded) or
                        any(record[16:]) or len(records) != declared_count):
                    raise ValueError("invalid END or logical command count")
                return records, record
            if len(records) >= declared_count:
                raise ValueError("stream exceeds declared logical command count")
            records.append(record)
            offset += command_size
            continue

        iterations, body_count, body_bytes, patch_count = struct.unpack_from(
            "<4I", encoded, offset + 16
        )
        if (flags or iterations < 2 or not 1 <= body_count <= 16 or patch_count > 24 or
                command_size != ((32 + patch_count * 8 + 31) & ~31) or
                body_bytes > 2048 - command_size or
                body_bytes > len(encoded) - offset - command_size or
                iterations * body_count > declared_count - len(records)):
            raise ValueError("invalid affine loop bounds or logical count")
        if any(encoded[offset + 32 + patch_count * 8:offset + command_size]):
            raise ValueError("affine metadata padding must be zero")
        body = bytearray(encoded[offset + command_size : offset + command_size + body_bytes])
        children = []
        child_offset = 0
        for _child in range(body_count):
            child_type, child_size, _flags = read_header(body, child_offset)
            if child_type in (0, 33):
                raise ValueError("nested loop or END in affine body")
            children.append((child_offset, child_size))
            child_offset += child_size
        if child_offset != body_bytes:
            raise ValueError("affine children do not cover body")
        patches = [
            struct.unpack_from("<2I", encoded, offset + 32 + patch * 8)
            for patch in range(patch_count)
        ]
        previous_word = -1
        for word, _delta in patches:
            if (word <= previous_word or word > 0x3fffffff or
                    not any(start + 8 <= word * 4 and word * 4 + 4 <= start + size
                            for start, size in children)):
                raise ValueError("affine patch must be ordered and inside a child payload")
            previous_word = word
        for _iteration in range(iterations):
            for body_offset, child_size in children:
                records.append(bytes(body[body_offset : body_offset + child_size]))
            for word_offset, delta in patches:
                byte_offset = word_offset * 4
                value = struct.unpack_from("<I", body, byte_offset)[0]
                struct.pack_into("<I", body, byte_offset, (value + delta) & 0xFFFFFFFF)
        offset += command_size + body_bytes
    raise ValueError("commands section has no END record")


_DMA_SUBMIT_DIRECTION_OFFSETS = {
    24: 36,
    25: 48,
    26: 60,
}


def _restart_boundary_outstanding(commands, command_boundary):
    """Return asynchronous work that a memory-only snapshot cannot restore."""
    if not 0 <= command_boundary <= len(commands):
        raise ValueError(
            f"snapshot boundary {command_boundary} is outside 0-{len(commands)}"
        )

    dma_submits = {0: [], 1: []}
    systolic_submit = None
    for command_index, command in enumerate(commands[:command_boundary], start=1):
        command_type = struct.unpack_from("<H", command)[0]
        if command_type in _DMA_SUBMIT_DIRECTION_OFFSETS:
            direction = struct.unpack_from(
                "<I", command, _DMA_SUBMIT_DIRECTION_OFFSETS[command_type]
            )[0]
            # Local-to-local submit commands execute synchronously in firmware.
            if direction in dma_submits:
                dma_submits[direction].append(command_index)
        elif command_type == 27:
            direction = struct.unpack_from("<I", command, 16)[0]
            if direction in dma_submits:
                dma_submits[direction].clear()
        elif command_type in (29, 32):
            systolic_submit = command_index
        elif command_type == 30:
            systolic_submit = None
        elif command_type == 1:
            dma_submits[0].clear()
            dma_submits[1].clear()
            systolic_submit = None

    return {
        "dma_external_to_local": tuple(dma_submits[0]),
        "dma_local_to_external": tuple(dma_submits[1]),
        "systolic": systolic_submit,
    }


def _require_restart_safe_boundary(model, command_boundary):
    commands, _end = _logical_command_records(model)
    outstanding = _restart_boundary_outstanding(commands, command_boundary)
    details = []
    for name in ("dma_external_to_local", "dma_local_to_external"):
        if outstanding[name]:
            details.append(f"{name} submits {list(outstanding[name])}")
    if outstanding["systolic"] is not None:
        details.append(f"systolic submit {outstanding['systolic']}")
    if details:
        raise ValueError(
            f"snapshot boundary {command_boundary} is not restart-safe; "
            + ", ".join(details)
        )


def _replace_command_section(model, commands, end):
    package = bytearray(model)
    descriptor, commands_offset, commands_size = _command_section(package)
    replacement = b"".join(commands) + end
    assert len(replacement) % 32 == 0
    delta = len(replacement) - commands_size
    package[commands_offset : commands_offset + commands_size] = replacement
    section_table_offset = struct.unpack_from("<I", package, 24)[0]
    section_count = struct.unpack_from("<I", package, 20)[0]
    for index in range(section_count):
        section = section_table_offset + index * 32
        section_offset = struct.unpack_from("<I", package, section + 8)[0]
        if section_offset > commands_offset:
            struct.pack_into("<I", package, section + 8, section_offset + delta)
    struct.pack_into("<I", package, 16, len(package))
    struct.pack_into("<I", package, descriptor + 12, len(replacement))
    struct.pack_into("<I", package, descriptor + 20, len(commands))
    struct.pack_into("<I", package, 32, len(commands))
    return bytes(package)


def _extract_selected_yolo320_command_range(model, first_command, end_command):
    commands, end = _logical_command_records(model)
    total_commands = len(commands)
    assert 0 <= first_command < end_command <= total_commands
    return _replace_command_section(model, commands[first_command:end_command], end)


def _selected_command_trace_records(model, first_command, end_command):
    commands, _end = _logical_command_records(model)
    total_commands = len(commands)
    assert 0 <= first_command < end_command <= total_commands

    records = []
    for command_index, command in enumerate(commands):
        command_type, command_size, flags, layer_id, tile_id = struct.unpack_from(
            "<HHIII", command
        )
        if first_command <= command_index < end_command:
            records.append(
                {
                    "command": command_index + 1,
                    "type": command_type,
                    "size": command_size,
                    "flags": flags,
                    "layer_id": layer_id,
                    "tile_id": tile_id,
                    "header": command[:16],
                }
            )
    records.append(
        {
            "command": end_command + 1,
            "type": 0,
            "size": 32,
            "flags": 0,
            "layer_id": 0,
            "tile_id": 0,
            "header": _command_header(0, 32),
        }
    )
    return records


def _write_command_pmu_csv(path, records, counters, append):
    fieldnames = [
        "command",
        "type",
        "size",
        "flags",
        "layer_id",
        "tile_id",
        *counters[0].keys(),
    ]
    mode = "a" if append else "w"
    with Path(path).open(mode, newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        if not append:
            writer.writeheader()
        for record, command_counters in zip(records, counters):
            writer.writerow(
                {
                    key: value
                    for key, value in {**record, **command_counters}.items()
                    if key != "header"
                }
            )


_YOLO320_SNAPSHOT_MAGIC = b"NAISNP01"
_YOLO320_SNAPSHOT_HEADER = struct.Struct("<8s6I")


def _encode_yolo320_snapshot(model, command_boundary, tcdm, l2_temporary, output):
    payload = bytes(tcdm) + bytes(l2_temporary) + bytes(output)
    header = _YOLO320_SNAPSHOT_HEADER.pack(
        _YOLO320_SNAPSHOT_MAGIC,
        command_boundary,
        zlib.crc32(model) & 0xFFFFFFFF,
        len(tcdm),
        len(l2_temporary),
        len(output),
        zlib.crc32(payload) & 0xFFFFFFFF,
    )
    return header + zlib.compress(payload, level=1)


def _decode_yolo320_snapshot(model, snapshot):
    if len(snapshot) < _YOLO320_SNAPSHOT_HEADER.size:
        raise ValueError("YOLO320 snapshot is truncated")
    magic, boundary, model_crc, tcdm_bytes, temporary_bytes, output_bytes, payload_crc = (
        _YOLO320_SNAPSHOT_HEADER.unpack_from(snapshot)
    )
    if magic != _YOLO320_SNAPSHOT_MAGIC:
        raise ValueError("YOLO320 snapshot magic is invalid")
    if model_crc != (zlib.crc32(model) & 0xFFFFFFFF):
        raise ValueError("YOLO320 snapshot model CRC does not match")
    payload = zlib.decompress(snapshot[_YOLO320_SNAPSHOT_HEADER.size :])
    if len(payload) != tcdm_bytes + temporary_bytes + output_bytes:
        raise ValueError("YOLO320 snapshot payload size does not match")
    if payload_crc != (zlib.crc32(payload) & 0xFFFFFFFF):
        raise ValueError("YOLO320 snapshot payload CRC does not match")
    temporary_offset = tcdm_bytes
    output_offset = temporary_offset + temporary_bytes
    return (
        boundary,
        payload[:temporary_offset],
        payload[temporary_offset:output_offset],
        payload[output_offset:],
    )


def _verify_yolo320_snapshot(
    model,
    snapshot,
    *,
    expected_boundary=None,
    expected_tcdm=None,
    expected_temporary=None,
    expected_output=None,
):
    """Validate snapshot integrity and optionally compare its complete memory image."""
    boundary, tcdm, temporary, output = _decode_yolo320_snapshot(model, snapshot)
    if expected_boundary is not None and boundary != expected_boundary:
        raise ValueError(
            f"YOLO320 snapshot boundary is {boundary}, expected {expected_boundary}"
        )

    for name, actual, expected in (
        ("TCDM", tcdm, expected_tcdm),
        ("L2 temporary", temporary, expected_temporary),
        ("output", output, expected_output),
    ):
        if expected is None:
            continue
        if isinstance(expected, int):
            if len(actual) != expected:
                raise ValueError(
                    f"YOLO320 snapshot {name} has {len(actual)} bytes, expected {expected}"
                )
        elif actual != bytes(expected):
            raise ValueError(
                f"YOLO320 snapshot {name} differs from live memory: "
                f"snapshot_crc=0x{zlib.crc32(actual) & 0xFFFFFFFF:08x} "
                f"live_crc=0x{zlib.crc32(bytes(expected)) & 0xFFFFFFFF:08x}"
            )
    return boundary, tcdm, temporary, output


def _yolo320_snapshot_path_boundary(path):
    marker = "command-"
    marker_offset = path.stem.rfind(marker)
    suffix = path.stem[marker_offset + len(marker) :] if marker_offset >= 0 else ""
    return int(suffix) if suffix.isdigit() else None


def _yolo320_snapshot_output_path(path_spec, command_boundary, multiple_boundaries):
    if "{command}" in path_spec:
        return Path(path_spec.replace("{command}", str(command_boundary)))
    path = Path(path_spec)
    if not multiple_boundaries:
        return path
    marker = "command-"
    marker_offset = path.stem.rfind(marker)
    if marker_offset >= 0 and path.stem[marker_offset + len(marker) :].isdigit():
        stem = path.stem[: marker_offset + len(marker)] + str(command_boundary)
    else:
        stem = f"{path.stem}-command-{command_boundary}"
    return path.with_name(stem + path.suffix)


def _compile_high_c16_slice_model():
    return _compile_tflite_fixture_model(
        "c32_high_c16_slice_h2w3", "neural-ai-compiled-high-c16-slice-"
    )


def _compile_rgb_k3_conv_model():
    return _compile_tflite_fixture_model(
        "rgb_k3_conv_h7w7_k3_n32", "neural-ai-compiled-rgb-"
    )


def _compile_depthwise_k3_conv_model():
    return _compile_tflite_fixture_model(
        "depthwise_k3_conv_h3w3_c33_s2", "neural-ai-compiled-depthwise-"
    )


def _compile_afu_add_model():
    return _compile_tflite_fixture_model(
        "add_h2w2_c32", "neural-ai-compiled-add-"
    )


def _compile_quantized_add_model():
    return _compile_tflite_fixture_model(
        "add_quant_h2w2_c32", "neural-ai-compiled-quant-add-"
    )


def _compile_compact_scalar_mul_model():
    return _compile_tflite_fixture_model(
        "scalar_mul_p2_l37", "neural-ai-compiled-scalar-mul-"
    )


def _compile_sigmoid_model():
    return _compile_tflite_fixture_model(
        "sigmoid_h2w3_c33", "neural-ai-compiled-sigmoid-"
    )


def _compile_silu_model():
    return _compile_tflite_fixture_model(
        "silu_h2w3_c33", "neural-ai-compiled-silu-"
    )


def _compile_relu6_model():
    return _compile_tflite_fixture_model(
        "relu6_h2w3_c33", "neural-ai-compiled-relu6-"
    )


def _compile_global_avgpool_model():
    return _compile_tflite_fixture_model(
        "global_avgpool_h2w3_c33", "neural-ai-compiled-global-avgpool-"
    )


def _compile_spatial_mean_model():
    return _compile_tflite_fixture_model(
        "mean_spatial_h2w3_c33", "neural-ai-compiled-spatial-mean-"
    )


def _compile_token_mean_model():
    return _compile_tflite_fixture_model(
        "mean_token_t7_c33", "neural-ai-compiled-token-mean-"
    )


def _compile_resize_nearest_model():
    return _compile_tflite_fixture_model(
        "resize_nearest_h2w3_c32_2x", "neural-ai-compiled-resize-nearest-"
    )


def _compile_yolov8_resize_c256_model():
    return _compile_tflite_fixture_model(
        "yolov8_resize_h10w10_c256_2x", "neural-ai-compiled-yolov8-resize-"
    )


def _compile_maxpool_model():
    return _compile_tflite_fixture_model(
        "maxpool_h24w24_c32_k5s1p2", "neural-ai-compiled-maxpool-"
    )


def _compile_yolov8_maxpool_c128_model():
    return _compile_tflite_fixture_model(
        "yolov8_maxpool_h10w10_c128", "neural-ai-compiled-yolov8-maxpool-"
    )


def _compile_yolov8_head_transpose_model():
    return _compile_tflite_fixture_model(
        "yolov8_head_transpose_h10w10_c144",
        "neural-ai-compiled-yolov8-head-transpose-",
    )


def _compile_concat_model():
    return _compile_tflite_fixture_model(
        "concat_h24w24_c32_c32", "neural-ai-compiled-concat-"
    )


def _compile_public_reshape_model():
    return _compile_tflite_fixture_model(
        "reshape_1x4x32_to_1x2x2x32", "neural-ai-compiled-reshape-"
    )


def _compile_pointwise_depthwise_chain_model():
    return _compile_tflite_fixture_model(
        "pointwise_depthwise_chain", "neural-ai-compiled-chain-"
    )


def _compile_micro_mobilenet_full_model():
    return _compile_tflite_fixture_model(
        "micro_mobilenet_full",
        "neural-ai-compiled-micro-mobilenet-",
        compressed=True,
    )


def _compile_micro_mobilenet_stage1_model():
    return _compile_tflite_fixture_model(
        "micro_mobilenet_stage1",
        "neural-ai-compiled-micro-mobilenet-stage1-",
        compressed=True,
    )


def _compile_micro_mobilenet_stage10_model():
    return _compile_tflite_fixture_model(
        "micro_mobilenet_stage10",
        "neural-ai-compiled-micro-mobilenet-stage10-",
        compressed=True,
    )


def _load_compiler_striped_pointwise_package(width):
    fixture = Path(__file__).with_name(f"pointwise_m{width}.nai.b64")
    package = base64.b64decode(fixture.read_text(encoding="ascii"))
    assert package[:4] == b"NAIM"
    return package


def _pointwise_striped_expected(input_values, width):
    expected = bytearray()
    for pixel in range(width):
        channels = input_values[pixel * 32:(pixel + 1) * 32]
        value = sum(channel - 256 if channel >= 128 else channel for channel in channels)
        value = max(-128, min(127, value)) & 0xFF
        expected.extend([value] * 32)
    return bytes(expected)


async def _run_compiler_striped_pointwise(dut, axi_master, width):
    model = _load_compiler_striped_pointwise_package(width)
    input_values = [(index * 7 + 3) & 0xFF for index in range(width * 32)]
    input_data = bytes(input_values)
    expected = _pointwise_striped_expected(input_values, width)
    input_base = 0x80000000
    output_base = 0x80004000
    runtime_bindings = [
        (1, 0, input_base, len(input_data)),
        (2, 0, output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=500000)

    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, output_base, len(expected))) == expected

    # The compiler must coalesce oversized M into one full-row pointwise
    # command; the runtime performs the <=256-row decomposition internally.
    section_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_offset + 8)[0]
    offset = command_offset
    pointwise_rows = []
    while offset < len(model):
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 10:
            pointwise_rows.append(struct.unpack_from("<I", model, offset + 48)[0])
        if command_type == 0:
            break
        offset += command_size
    assert pointwise_rows and sum(pointwise_rows) == width
    assert pointwise_rows == [width]



def _runtime_firmware_path():
    manifest = os.environ.get("NAI_REPLAY_MANIFEST")
    firmware_override = os.environ.get("NAI_REPLAY_FIRMWARE_ELF")
    if firmware_override:
        if not manifest:
            raise ValueError("NAI_REPLAY_FIRMWARE_ELF requires NAI_REPLAY_MANIFEST")
        return Path(firmware_override).resolve()
    if manifest:
        return Path(manifest).resolve().with_suffix(".elf")
    return Path(__file__).resolve().parents[3] / "sw/runtime/neural_ai/neural_ai.elf"


def _load_pinned_range(manifest_path):
    """Validate both saved artifacts and the original range/address settings."""
    import hashlib
    import json

    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text())
    payloads = {}
    for suffix in (".nai", ".elf"):
        payload = manifest_path.with_suffix(suffix).read_bytes()
        if hashlib.sha256(payload).hexdigest() != manifest[suffix]:
            raise ValueError(f"Pinned replay {suffix} SHA-256 mismatch")
        payloads[suffix] = payload
    for key, expected in manifest["environment"].items():
        if key.startswith("YOLO320_RANGE_") and os.environ.get(key) != expected:
            raise ValueError(f"Pinned replay setting mismatch: {key} must be {expected}")
    return payloads[".nai"]


def _firmware_symbol_address(symbol_name, *, optional=False):
    repository_root = Path(__file__).resolve().parents[3]
    nm = repository_root / "hw/spatz/install/llvm/bin/llvm-nm"
    firmware = _runtime_firmware_path()
    result = subprocess.run(
        [str(nm), "-n", str(firmware)],
        check=True,
        capture_output=True,
        text=True,
    )
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) == 3 and fields[2] == symbol_name:
            return int(fields[0], 16)
    if optional:
        return None
    raise AssertionError(f"firmware symbol not found: {symbol_name}")


def _describe_model_command(model, descriptor_header):
    command_type, command_size, _flags, layer_id, tile_id = struct.unpack(
        "<HHIII", descriptor_header
    )
    try:
        commands, _end = _logical_command_records(model)
    except ValueError:
        return "command=unknown (commands section missing)"

    command_count = len(commands)
    matches = []
    for command_index, command_record in enumerate(commands):
        if command_record[:16] == descriptor_header:
            matches.append(command_index)
    if len(matches) == 1:
        command = f"command={matches[0] + 1}/{command_count} (index={matches[0]})"
    elif matches:
        command = f"command_candidates={matches}"
    else:
        command = "command=unknown"
    return (
        f"{command}, type={command_type}, size={command_size}, "
        f"layer={layer_id}, tile={tile_id}"
    )


def _current_model_command(dut, model, command_buffer_address, command_pointer_address=None):
    if command_pointer_address is not None:
        command_buffer_address = read_dtcm_word(dut, command_pointer_address)
        if command_buffer_address == 0:
            return "command=not_started"
    descriptor_header = b"".join(
        read_dtcm_word(dut, command_buffer_address + offset).to_bytes(4, "little")
        for offset in range(0, 16, 4)
    )
    return _describe_model_command(model, descriptor_header)


def _snitch_debug_state(dut):
    pc_signal = dut.u_npu_cluster.u_snitch_core.i_snitch.pc_q
    if not pc_signal.value.is_resolvable:
        return "pc=unresolved"
    return f"pc=0x{pc_signal.value.to_unsigned():08x}"


def _systolic_debug_state(dut):
    systolic_states = ("IDLE", "LOAD_WEIGHTS", "COMPUTE", "WAIT_DRAIN", "DONE")
    drain_states = ("IDLE", "ACCUM_READ", "ACCUM_WRITE", "ACCUM_REQUANT")
    linebuf_states = (
        "IDLE",
        "ENSURE",
        "FILL_REQ0",
        "FILL_REQ1",
        "FILL_DRAIN",
        "WINDOW_REQ",
        "WINDOW_WAIT",
        "STREAM_PRIME",
        "STREAM_EMIT",
        "BYPASS_PREP",
        "BYPASS_REQ0",
        "BYPASS_WAIT0",
        "BYPASS_REQ1",
        "BYPASS_WAIT1",
        "STREAM_DONE",
    )
    linebuf_fetch_main_states = ("REQ0", "REQ1", "DRAIN", "IDLE")
    linebuf_fetch_background_states = ("IDLE", "SCAN", "REQ0", "REQ1", "DRAIN")
    linebuf_bypass_states = ("IDLE", "PREP", "REQ0", "WAIT0", "REQ1", "WAIT1", "EMIT")

    def state_name(signal, names):
        value = int(signal.value) if signal.value.is_resolvable else -1
        return names[value] if 0 <= value < len(names) else str(value)

    details = [
        f"sys={state_name(dut.debug_sys_state_o, systolic_states)}",
        f"drain={state_name(dut.debug_sys_drain_state_o, drain_states)}",
        f"linebuf={state_name(dut.debug_linebuf_state_o, linebuf_states)}",
        f"lb_fetch={state_name(dut.debug_linebuf_fetch_main_state_o, linebuf_fetch_main_states)}",
        f"lb_bg={state_name(dut.debug_linebuf_fetch_background_state_o, linebuf_fetch_background_states)}",
        f"lb_bypass={state_name(dut.debug_linebuf_bypass_state_o, linebuf_bypass_states)}",
    ]
    controller = getattr(dut.u_npu_cluster, "u_sys_ctrl", None)
    if controller is None:
        return ", ".join(details)
    for label, signal_name in (
        ("req", "req_cnt_q"),
        ("rsp", "rsp_cnt_q"),
        ("remaining", "drain_cnt_q"),
        ("k_tile", "k_tile_idx_q"),
        ("weight_empty", "weight_fifo_empty"),
        ("ofm_empty", "ofm_fifo_empty"),
        ("lb_prefetch_busy", "linebuf_prefetch_busy"),
    ):
        signal = getattr(controller, signal_name, None)
        if signal is not None and signal.value.is_resolvable:
            details.append(f"{label}={int(signal.value)}")
    input_engine = getattr(controller, "i_input_engine", None)
    linebuffer = getattr(input_engine, "i_linebuf", None) if input_engine is not None else None
    if linebuffer is not None:
        fetch_engine = getattr(linebuffer, "i_fetch_engine", None)
        scheduler = getattr(linebuffer, "i_spatial_scheduler", None)
        for label, owner, signal_name in (
            ("beat_fifo", fetch_engine, "count_q"),
            ("emitted", scheduler, "emitted_vectors_q"),
        ):
            if owner is None:
                continue
            signal = getattr(owner, signal_name, None)
            if signal is not None and signal.value.is_resolvable:
                details.append(f"{label}={int(signal.value)}")
    return ", ".join(details)


def _dma_debug_state(dut):
    cluster = dut.u_npu_cluster
    controller = cluster.u_idma_ctrl_mm
    details = []

    def add(label, owner, signal_name):
        signal = getattr(owner, signal_name, None)
        if signal is not None and signal.value.is_resolvable:
            details.append(f"{label}={int(signal.value)}")

    for label, signal_name in (
        ("dma_busy", "idma_irq_a2o_busy"),
        ("dma_start", "idma_irq_a2o_start"),
        ("dma_done", "idma_irq_a2o_done"),
        ("dma_queue", "idma_a2o_queue_usage"),
        ("pmu_context", "pmu_context_id"),
        ("pmu_active", "pmu_context_active"),
        ("pmu_phase", "pmu_phase"),
    ):
        add(label, cluster, signal_name)
    for label, signal_name in (
        ("dma_next_id", "a2o_next_id"),
        ("dma_done_id", "a2o_done_id"),
        ("backend_busy_bits", "a2o_busy"),
        ("front_valid", "a2o_front_valid"),
        ("front_ready", "a2o_front_ready"),
        ("fifo_valid", "a2o_fe_valid"),
        ("fifo_ready", "a2o_fe_ready"),
        ("backend_valid", "a2o_be_req_valid"),
        ("backend_ready", "a2o_be_req_ready"),
        ("backend_rsp", "a2o_be_rsp_valid"),
        ("midend_busy", "a2o_me_busy"),
    ):
        add(label, controller, signal_name)
    for label, signal_name in (
        ("axi_ar_v", "axi_ar_valid_o"),
        ("axi_ar_r", "axi_ar_ready_i"),
        ("axi_r_v", "axi_r_valid_i"),
        ("axi_r_r", "axi_r_ready_o"),
        ("obi_w_req", "idma_obi_write_req"),
        ("obi_w_gnt", "idma_obi_write_gnt"),
        ("obi_w_rsp", "idma_obi_write_rvalid"),
    ):
        add(label, cluster, signal_name)
    return ", ".join(details)


async def _load_and_run(
    dut,
    axi_master,
    invocation,
    timeout_cycles=600000,
    measure_pmu=False,
    invocation_base=INVOCATION_BASE,
    model=None,
    command_trace_records=None,
    command_trace_callback=None,
):
    await load_firmware_elf_axi(
        dut,
        axi_master,
        _runtime_firmware_path(),
    )
    await program_command_queue(axi_master, invocation_base, len(invocation))
    command_buffer_address = (
        _firmware_symbol_address("g_command_buffer") if model is not None else None
    )
    command_pointer_address = (
        _firmware_symbol_address("g_nai_current_command", optional=True)
        if model is not None else None
    )
    dma_trace = None
    dma_trace_task = None
    dma_trace_path = os.environ.get("NAI_DMA_TRACE_CSV")
    if dma_trace_path:
        import hashlib
        import json

        from dma_debug_trace import DMAHandshakeTrace

        trace_max_rows = int(os.environ.get("NAI_DMA_TRACE_MAX_ROWS", "20000"))
        if trace_max_rows <= 0:
            raise ValueError("NAI_DMA_TRACE_MAX_ROWS must be positive")
        dma_trace = DMAHandshakeTrace(dut, dma_trace_path, max_rows=trace_max_rows)
        artifact_base = Path(dma_trace_path)
        artifact_base.parent.mkdir(parents=True, exist_ok=True)
        artifacts = {}
        firmware_path = _runtime_firmware_path()
        for suffix, payload in ((".elf", firmware_path.read_bytes()), (".nai", model)):
            if payload is not None:
                with artifact_base.with_suffix(suffix).open("xb") as artifact:
                    artifact.write(payload)
                artifacts[suffix] = hashlib.sha256(payload).hexdigest()
        artifacts["environment"] = {
            key: value for key, value in os.environ.items()
            if key.startswith(("YOLO320_RANGE_", "NAI_DMA_TRACE_", "NAI_REPLAY_"))
        }
        with artifact_base.with_suffix(".json").open("x") as manifest:
            json.dump(artifacts, manifest, indent=2)
        dma_trace_task = cocotb.start_soon(dma_trace.run(
            start_cycle=int(os.environ.get("NAI_DMA_TRACE_START_CYCLE", "0")),
            cycles=timeout_cycles,
        ))
    command_trace_task = None
    if command_trace_records is not None:
        command_trace_task = cocotb.start_soon(
            monitor_command_buffer_pmu(
                dut,
                command_buffer_address,
                [record["header"] for record in command_trace_records],
                sample_callback=command_trace_callback,
                command_pointer_address=command_pointer_address,
            )
        )
    pmu_filter = os.environ.get("NAI_PMU_COMMAND_FILTER")
    await release_fetch(
        dut,
        axi_master=axi_master,
        pmu_command_id=int(pmu_filter, 0) if pmu_filter is not None else None,
    )
    progress_callback = lambda: "; ".join(
        detail
        for detail in (
            _snitch_debug_state(dut),
            _current_model_command(dut, model, command_buffer_address, command_pointer_address)
            if model is not None
            else "",
            _systolic_debug_state(dut),
            _dma_debug_state(dut),
        )
        if detail
    )
    try:
        counters = await wait_for_host_irq(
            dut,
            timeout_cycles=timeout_cycles,
            axi_master=axi_master,
            report_name="test_compiler_runtime",
            progress_callback=progress_callback,
        )
    except AssertionError as error:
        if command_trace_task is not None:
            command_trace_task.cancel()
        status = await _axi_read32(axi_master, NPU_CMD_STATUS)
        fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
        fail_pointer = await _axi_read32(axi_master, NPU_CMD_FAIL_PTR)
        done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
        pc_signal = dut.u_npu_cluster.u_snitch_core.i_snitch.pc_q
        program_counter = (
            pc_signal.value.to_unsigned() if pc_signal.value.is_resolvable else 0
        )
        command_progress = (
            _current_model_command(dut, model, command_buffer_address, command_pointer_address)
            if model is not None
            else "command=unavailable"
        )
        systolic_progress = _systolic_debug_state(dut)
        dma_progress = _dma_debug_state(dut)
        dut._log.error("timeout PMU snapshot:\n%s", format_pmu_report(pmu_direct_snapshot(dut)))
        raise AssertionError(
            f"{error}; status={status} fail=0x{fail_code:08x} "
            f"pointer=0x{fail_pointer:08x} done={done_count} "
            f"pc=0x{program_counter:08x}; {command_progress}; {systolic_progress}; "
            f"{dma_progress}"
        ) from error
    finally:
        if dma_trace_task is not None:
            dma_trace_task.cancel()
            dma_trace.close()
    if command_trace_task is not None:
        return counters, await command_trace_task
    if measure_pmu:
        return counters
    return None


@cocotb.test()
async def test_compiler_runtime_dma_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_data = bytes((index * 7 + 3) & 0xFF for index in range(32))
    model = build_model()
    invocation, binding_addresses = build_invocation(model)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(32))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == struct.unpack_from(
        "<I", model, 32
    )[0]
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, 32)) == input_data


@cocotb.test()
async def test_compiler_runtime_unaligned_raw_dma_1d_2d_3d(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )

    for dimension in (1, 2, 3):
        model, copies, binding_bytes = build_unaligned_dma_model(dimension)
        input_data = bytes(
            (index * 17 + dimension * 11) & 0xFF
            for index in range(binding_bytes)
        )
        expected = bytearray(binding_bytes)
        for source, destination, length in copies:
            expected[destination:destination + length] = (
                input_data[source:source + length]
            )
        runtime_bindings = [
            (1, 0, INPUT_BASE, binding_bytes),
            (2, 0, OUTPUT_BASE, binding_bytes),
        ]
        invocation, binding_addresses = build_invocation_with_bindings(
            model, runtime_bindings
        )

        await reset_dut(dut)
        await write_l2_bytes(dut, INPUT_BASE, input_data)
        await write_l2_bytes(dut, OUTPUT_BASE, bytes(binding_bytes))
        await write_l2_bytes(dut, MODEL_BASE, model)
        await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
        await write_l2_bytes(dut, INVOCATION_BASE, invocation)
        await _load_and_run(dut, axi_master, invocation)

        status = await _axi_read32(axi_master, NPU_CMD_STATUS)
        if status != NPU_CMD_STATUS_PASS:
            fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
            fail_pointer = await _axi_read32(axi_master, NPU_CMD_FAIL_PTR)
            done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
            raise AssertionError(
                f"unaligned DMA{dimension}D failed: status={status} "
                f"fail=0x{fail_code:08x} pointer=0x{fail_pointer:08x} "
                f"done={done_count}"
            )
        assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
        assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 2
        assert bytes(await read_l2_bytes(
            dut, OUTPUT_BASE, binding_bytes
        )) == bytes(expected)


@cocotb.test()
async def test_compiler_runtime_async_dma_2d_local_wait(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model, binding_bytes = build_async_dma_2d_wait_model()
    output_base = 0x80008000
    input_data = bytes((index * 29 + 7) & 0xFF for index in range(binding_bytes))
    runtime_bindings = [
        (1, 0, INPUT_BASE, binding_bytes),
        (2, 0, output_base, binding_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, output_base, bytes(binding_bytes))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=500000, model=model
    )

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 4
    assert bytes(await read_l2_bytes(
        dut, output_base, binding_bytes
    )) == input_data


@cocotb.test()
async def test_compiler_runtime_async_dma_before_afu_lut(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model, input_bytes, afu_bytes = build_async_dma_before_afu_lut_model()
    output_base = 0x80008000
    input_data = bytes((index * 37 + 11) & 0xFF for index in range(input_bytes))
    runtime_bindings = [
        (1, 0, INPUT_BASE, input_bytes),
        (2, 0, output_base, afu_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, output_base, bytes(afu_bytes))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=500000, model=model
    )

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 10
    assert bytes(await read_l2_bytes(
        dut, output_base, afu_bytes
    )) == input_data[:afu_bytes]


@cocotb.test()
async def test_compiler_runtime_dma_transfer_id_stress(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    iterations = int(os.environ.get("DMA_TRANSFER_ID_STRESS_ITERATIONS", "1000"))
    timeout_cycles = int(
        os.environ.get("DMA_TRANSFER_ID_STRESS_TIMEOUT_CYCLES", "5000000")
    )
    model = build_dma_transfer_id_stress_model(iterations)
    input_data = bytes((0x3D, 0xA7, 0x19, 0xE2))
    model_base = 0x81000000
    invocation_base = 0x81800000
    binding_table_base = 0x81801000
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(input_data)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(input_data)))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=timeout_cycles,
        invocation_base=invocation_base,
        model=model,
    )

    expected_commands = iterations * 2 + 1
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == expected_commands
    assert bytes(await read_l2_bytes(
        dut, OUTPUT_BASE, len(input_data)
    )) == input_data


@cocotb.test()
async def test_compiler_runtime_layout_round_trip(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_data = bytes((index * 11 + 5) & 0xFF for index in range(132))
    model = build_layout_model()
    invocation, binding_addresses = build_invocation(model)
    binding_addresses = bytearray(binding_addresses)
    struct.pack_into("<I", binding_addresses, 8, len(input_data))
    struct.pack_into("<I", binding_addresses, 24, len(input_data))
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(input_data)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 1
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(input_data))) == input_data


@cocotb.test()
async def test_compiler_runtime_c32_layout_round_trip(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_data = bytes((index * 13 + 7) & 0xFF for index in range(132))
    model = build_c32_layout_model()
    invocation, binding_addresses = build_invocation(model)
    binding_addresses = bytearray(binding_addresses)
    struct.pack_into("<I", binding_addresses, 8, len(input_data))
    struct.pack_into("<I", binding_addresses, 24, len(input_data))
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(input_data)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 2
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(input_data))) == input_data


@cocotb.test()
async def test_compiler_runtime_afu_add_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 2 * 32
    lhs_values = [120 if index % 7 == 0 else ((index * 3) % 41) - 20
                  for index in range(count)]
    rhs_values = [20 if index % 7 == 0 else ((index * 5) % 31) - 15
                  for index in range(count)]
    expected = bytes(
        max(-128, min(127, lhs + rhs)) & 0xFF
        for lhs, rhs in zip(lhs_values, rhs_values)
    )
    model = build_afu_add_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (1, 1, INPUT2_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, bytes(value & 0xFF for value in lhs_values))
    await write_l2_bytes(dut, INPUT2_BASE, bytes(value & 0xFF for value in rhs_values))
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 4
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == expected


@cocotb.test()
async def test_compiler_runtime_afu_add_bias_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 2 * 32
    bias = 110
    lhs_values = [((index * 37 + 11) & 0xFF) - 128 for index in range(count)]
    rhs_values = [((index * 19 + 7) & 0xFF) - 128 for index in range(count)]
    expected = bytes(
        max(-128, min(127, lhs + rhs + bias)) & 0xFF
        for lhs, rhs in zip(lhs_values, rhs_values)
    )
    model = build_afu_add_bias_model(bias)
    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (1, 1, INPUT2_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(
        dut, INPUT_BASE, bytes(value & 0xFF for value in lhs_values)
    )
    await write_l2_bytes(
        dut, INPUT2_BASE, bytes(value & 0xFF for value in rhs_values)
    )
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 4
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == expected


@cocotb.test()
async def test_compiler_runtime_afu_lut_binary_chain_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 73
    lhs = bytes((index * 11 + 5) & 0xFF for index in range(count))
    rhs = bytes((index * 7 + 131) & 0xFF for index in range(count))
    model, lut = build_afu_lut_binary_chain_model(count)

    def signed(byte):
        return byte if byte < 128 else byte - 256

    expected = bytes(
        max(-128, min(127, signed(lut[left]) + signed(right))) & 0xFF
        for left, right in zip(lhs, rhs)
    )
    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (1, 1, INPUT2_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, lhs)
    await write_l2_bytes(dut, INPUT2_BASE, rhs)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, model=model)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 5
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == expected


@cocotb.test()
async def test_compiler_runtime_afu_dfl16_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    locations = 2100
    input_base = 0x80100000
    output_base = 0x80150000
    input_values = bytearray(144 * locations)
    expected = bytearray(4 * locations)
    for channel in range(144):
        for location in range(locations):
            value = ((location * 13 + channel * 11 + 7) % 61) - 30
            input_values[channel * locations + location] = value & 0xFF
    for side in range(4):
        for location in range(locations):
            values = [
                ((location * 13 + (side * 16 + bin_index) * 11 + 7) % 61) - 30
                for bin_index in range(16)
            ]
            q8 = _dfl16_q8(values)
            value = ((q8 * 51003 + (1 << 7)) >> 8) - 128
            expected[side * locations + location] = max(-128, min(127, value)) & 0xFF

    model = build_afu_dfl16_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    dfl_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 28:
            assert command_size == 96
            assert struct.unpack_from("<I", model, offset + 56)[0] == locations
            dfl_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert dfl_commands == 1

    runtime_bindings = [
        (1, 0, input_base, len(input_values)),
        (2, 0, output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, input_base, input_values)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=1000000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns
    status = await _axi_read32(axi_master, NPU_CMD_STATUS)
    fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
    done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
    assert status == NPU_CMD_STATUS_PASS, (
        f"DFL16 runtime failed: status=0x{status:08x} "
        f"code=0x{fail_code:08x} done={done_count}"
    )
    assert fail_code == 0
    assert done_count == 3
    assert bytes(await read_l2_bytes(dut, output_base, len(expected))) == expected
    cocotb.log.info(
        "DFL16 runtime=%s ns PMU cycles=%d", elapsed_ns, counters["cycle"]
    )


async def _run_row32_case(dut, axi_master, channels, height, width,
                          input_base, output_base):
    model, compact_bytes = build_row32_layout_model(channels, height, width)
    input_data = bytes((index * 17 + channels) & 0xFF for index in range(compact_bytes))
    runtime_bindings = [
        (1, 0, input_base, compact_bytes),
        (2, 0, output_base, compact_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await reset_dut(dut)
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(compact_bytes))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    start_ns = get_sim_time("ns")
    await _load_and_run(dut, axi_master, invocation)
    elapsed_ns = get_sim_time("ns") - start_ns
    status = await _axi_read32(axi_master, NPU_CMD_STATUS)
    if status != NPU_CMD_STATUS_PASS:
        fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
        done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
        raise AssertionError(
            f"ROW32 C={channels} H={height} W={width} dispatch failed: "
            f"status={status} "
            f"fail=0x{fail_code:08x} done={done_count}"
        )
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 2
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert bytes(await read_l2_bytes(dut, output_base, compact_bytes)) == input_data
    return elapsed_ns


@cocotb.test()
async def test_compiler_runtime_unaligned_row32_c3_c31(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await _run_row32_case(dut, axi_master, 3, 1, 11,
                          0x80002003, 0x80003007)
    await _run_row32_case(dut, axi_master, 31, 1, 5,
                          0x80002005, 0x8000300b)


@cocotb.test()
async def test_compiler_runtime_row32_channel_boundary_matrix(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    logging.getLogger("cocotb.tb_npu_cluster.s_axi").setLevel(logging.WARNING)
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )

    for channels in (3, 31, 32, 33, 63, 64, 65):
        elapsed_ns = await _run_row32_case(
            dut,
            axi_master,
            channels,
            2,
            3,
            0x80002000,
            0x80003000,
        )
        dut._log.info(
            "ROW32 C=%d H=2 W=3 runtime completion: %.3f ns",
            channels,
            elapsed_ns,
        )


@cocotb.test()
async def test_compiler_runtime_pointwise_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, output_channels = 1, 1, 64, 32
    input_values = [((pixel + channel) % 5) - 2
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for pixel in range(height * width):
        value = sum(input_values[pixel * channels:(pixel + 1) * channels]) & 0xFF
        expected.extend([value] * output_channels)
    model = build_pointwise_c32_model(height, width, channels, output_channels)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=200000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 4
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_runtime_pointwise_c32_relu6_clamp(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_values = [-1] * 4 + [2] * 28
    input_data = bytes(value & 0xFF for value in input_values)
    expected_value = min(max(sum(input_values), 0), 6)
    expected = bytes([expected_value] * 32)
    model = build_pointwise_c32_model(1, 1, 32, 32, clamp_min=0, clamp_max=6)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=200000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected


@cocotb.test()
async def test_compiler_runtime_pointwise_per_channel_requant(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    qparam_specs = []
    expected_values = []
    for channel in range(32):
        bias = channel * 5 - 75
        multiplier = 1 << (30 if channel % 2 == 0 else 29)
        shift = 30
        zero_point = -(channel // 2)
        qparam_specs.append((bias, multiplier, shift, zero_point, -128, 127))
        accumulator = 32 + bias
        product = accumulator * multiplier
        magnitude = abs(product)
        rounded = (magnitude + (1 << (shift - 1))) >> shift
        scaled = rounded if product >= 0 else -rounded
        expected_values.append(max(-128, min(127, scaled + zero_point)) & 0xFF)

    model = build_pointwise_c32_model(1, 1, 32, 32, qparam_specs=qparam_specs)
    input_data = bytes([1] * 32)
    expected = bytes(expected_values)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected


@cocotb.test()
async def test_compiler_runtime_rejects_mismatched_qparam_block(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model = build_pointwise_c32_model(
        1, 1, 32, 32, qparam_block_delta=1
    )
    input_data = bytes([1] * 32)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, 32),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(32))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_FAIL
    assert await _axi_read32(
        axi_master, NPU_CMD_FAIL_CODE
    ) == NPU_CMD_FAIL_V2_OPERATION
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 2
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, 32)) == bytes(32)


@cocotb.test()
async def test_compiler_runtime_depthwise_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 3, 3, 32
    input_values = [((pixel + channel * 3) % 9) - 4
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    model = build_depthwise_c32_model(height, width, channels)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(input_data)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(input_data)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 4
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(input_data))) == input_data


@cocotb.test()
async def test_compiler_runtime_repeated_depthwise_c32_package(dut):
    """A retained qparam block must re-enable requant for every depthwise job."""
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 3, 3, 32
    input_values = [
        ((pixel + channel * 3) % 9) - 4
        for pixel in range(height * width)
        for channel in range(channels)
    ]
    input_data = bytes(value & 0xFF for value in input_values)
    model = build_depthwise_c32_model(
        height, width, channels, repetitions=2
    )
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(input_data)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(input_data)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 5
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(input_data))) == input_data


@cocotb.test()
async def test_compiler_runtime_depthwise_c65_stride2_tail(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, stride = 3, 3, 65, 2
    output_height = ((height - 1) // stride) + 1
    output_width = ((width - 1) // stride) + 1
    input_values = [((pixel * 7 + channel * 3) % 19) - 9
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for output_y in range(output_height):
        for output_x in range(output_width):
            input_pixel = (output_y * stride) * width + output_x * stride
            expected.extend(
                value & 0xFF
                for value in input_values[input_pixel * channels:(input_pixel + 1) * channels]
            )

    model = build_depthwise_c32_model(height, width, channels, stride)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=400000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 8
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_runtime_depthwise_c96_stride2_groups(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, stride = 3, 3, 96, 2
    output_height = ((height - 1) // stride) + 1
    output_width = ((width - 1) // stride) + 1
    input_values = [((pixel * 11 + channel * 5) % 23) - 11
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for output_y in range(output_height):
        for output_x in range(output_width):
            input_pixel = (output_y * stride) * width + output_x * stride
            expected.extend(
                value & 0xFF
                for value in input_values[input_pixel * channels:(input_pixel + 1) * channels]
            )

    model = build_depthwise_c32_model(height, width, channels, stride)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=400000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 8
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_runtime_pointwise_depthwise_chain(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 2, 2, 32
    input_values = [((pixel * 3 + channel) % 5) - 2
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for pixel in range(height * width):
        value = sum(input_values[pixel * channels:(pixel + 1) * channels])
        expected.extend([max(-128, min(127, value)) & 0xFF] * channels)

    model = build_pointwise_depthwise_chain_model(height, width)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=300000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 6
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_pointwise_depthwise_chain(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 2, 2, 32
    input_values = [((pixel * 5 + channel * 2) % 7) - 3
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for pixel in range(height * width):
        value = sum(input_values[pixel * channels:(pixel + 1) * channels])
        expected.extend([max(-128, min(127, value)) & 0xFF] * channels)

    model = _compile_pointwise_depthwise_chain_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=300000)

    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_micro_mobilenet_full_graph(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_base = 0x80000000
    output_base = 0x80008000
    invocation_base = 0x80010000
    binding_table_base = 0x80011000
    model_base = 0x80100000
    native_mobilenet_cycles = 347_992
    native_yolo_cycles = 388_146

    input_data, expected = _micro_mobilenet_input_and_expected()
    model = _compile_micro_mobilenet_full_model()
    assert len(input_data) == 96 * 96 * 3
    assert len(expected) == 32
    assert struct.unpack_from("<I", model, 16)[0] == len(model)
    command_count = struct.unpack_from("<I", model, 32)[0]
    required_tcdm = struct.unpack_from("<I", model, 36)[0]
    assert required_tcdm <= 0x7F000
    assert struct.unpack_from("<2I", model, 44) == (1, 1)

    section_table = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table + 12)[0]
    command_types = {}
    offset = command_offset
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        assert command_size >= 32
        command_types[command_type] = command_types.get(command_type, 0) + 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert command_types.get(12, 0) == 0
    assert command_types.get(13, 0) == 2
    assert command_types.get(14, 0) == 1
    assert command_types.get(9, 0) > 0
    assert command_types.get(10, 0) > 0
    assert command_types.get(11, 0) > 0

    runtime_bindings = [
        (1, 0, input_base, len(input_data)),
        (2, 0, output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=3_000_000,
        measure_pmu=True,
        invocation_base=invocation_base,
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    actual = bytes(await read_l2_bytes(dut, output_base, len(expected)))
    assert actual == expected, (
        f"Micro-MobileNet mismatch: actual={list(actual)} "
        f"expected={list(expected)}"
    )
    assert counters["cycle"] > 0
    cocotb.log.warning(
        "compiler Micro-MobileNet full graph package=%d bytes commands=%d "
        "TCDM=%d runtime=%s ns PMU cycles=%d "
        "vs native MobileNet=%d (%.3fx) and native YOLO=%d (%.3fx)",
        len(model),
        command_count,
        required_tcdm,
        elapsed_ns,
        counters["cycle"],
        native_mobilenet_cycles,
        counters["cycle"] / native_mobilenet_cycles,
        native_yolo_cycles,
        counters["cycle"] / native_yolo_cycles,
    )
    cocotb.log.warning("%s", format_pmu_report(counters))


@cocotb.test()
async def test_compiler_generated_micro_mobilenet_stage1(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_base = 0x80000000
    output_base = 0x80010000
    invocation_base = 0x80030000
    binding_table_base = 0x80031000
    model_base = 0x80040000
    input_data, expected = _micro_mobilenet_stage1_input_and_expected()
    model = _compile_micro_mobilenet_stage1_model()
    command_count = struct.unpack_from("<I", model, 32)[0]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        [
            (1, 0, input_base, len(input_data)),
            (2, 0, output_base, len(expected)),
        ],
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    counters = await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=1_500_000,
        measure_pmu=True,
        invocation_base=invocation_base,
    )

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    actual = bytes(await read_l2_bytes(dut, output_base, len(expected)))
    if actual != expected:
        mismatch = next(
            index
            for index, (actual_value, expected_value) in enumerate(
                zip(actual, expected)
            )
            if actual_value != expected_value
        )
        raise AssertionError(
            "Micro-MobileNet stage 1 mismatch at byte "
            f"{mismatch}: actual={actual[mismatch]} "
            f"expected={expected[mismatch]}"
        )
    cocotb.log.warning(
        "compiler Micro-MobileNet stage 1\n%s", format_pmu_report(counters)
    )


@cocotb.test()
async def test_compiler_generated_micro_mobilenet_stage10(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_base = 0x80000000
    output_base = 0x80010000
    invocation_base = 0x80030000
    binding_table_base = 0x80031000
    model_base = 0x80040000
    input_data, expected = _micro_mobilenet_stage10_input_and_expected()
    model = _compile_micro_mobilenet_stage10_model()
    command_count = struct.unpack_from("<I", model, 32)[0]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        [
            (1, 0, input_base, len(input_data)),
            (2, 0, output_base, len(expected)),
        ],
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    counters = await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=3_000_000,
        measure_pmu=True,
        invocation_base=invocation_base,
    )

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    actual = bytes(await read_l2_bytes(dut, output_base, len(expected)))
    if actual != expected:
        mismatch = next(
            index
            for index, (actual_value, expected_value) in enumerate(
                zip(actual, expected)
            )
            if actual_value != expected_value
        )
        raise AssertionError(
            "Micro-MobileNet stage 10 mismatch at byte "
            f"{mismatch}: actual={actual[mismatch]} "
            f"expected={expected[mismatch]}"
        )
    assert counters["cycle"] > 0
    cocotb.log.warning(
        "compiler Micro-MobileNet stage 10\n%s", format_pmu_report(counters)
    )


@cocotb.test()
async def test_compiler_runtime_gemm_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    dimensions = (1, 31, 32, 33, 256)
    input_bases = (0x80000000, 0x80001000, 0x80002000, 0x80004000, 0x80006000)
    output_bases = (0x80010000, 0x80011000, 0x80015000, 0x80019000, 0x80020000)
    model = build_gemm_model(dimensions)
    runtime_bindings = []
    expected_outputs = []
    for index, (dim_m, base) in enumerate(zip(dimensions, input_bases)):
        input_data, values = _signed_input(dim_m, index)
        await write_l2_bytes(dut, base, input_data)
        runtime_bindings.append((1, index, base, len(input_data)))
        expected_outputs.append(b"".join(struct.pack("<i", value) for value in values))
    for index, (base, output) in enumerate(zip(output_bases, expected_outputs)):
        runtime_bindings.append((2, index, base, len(output)))

    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 16
    for base, expected in zip(output_bases, expected_outputs):
        assert bytes(await read_l2_bytes(dut, base, len(expected))) == expected


@cocotb.test()
async def test_compiler_generated_fully_connected_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model = _compile_fully_connected_model()
    input_values = [(index % 5) - 2 for index in range(33)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytes([sum(input_values) & 0xFF] * 34)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    await _load_and_run(dut, axi_master, invocation)

    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected


@cocotb.test()
async def test_compiler_generated_asymmetric_fully_connected_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model = _compile_fully_connected_model(asymmetric=True)
    input_values = [-7 + ((index % 5) - 2) for index in range(33)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected_value = sum(value + 7 for value in input_values)
    expected = bytes([expected_value & 0xFF] * 34)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    await _load_and_run(dut, axi_master, invocation)

    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected


@cocotb.test()
async def test_compiler_generated_pointwise_m257_stripes(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)
    await _run_compiler_striped_pointwise(dut, axi_master, 257)


@cocotb.test()
async def test_compiler_generated_pointwise_m511_stripes(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)
    await _run_compiler_striped_pointwise(dut, axi_master, 511)


@cocotb.test()
async def test_compiler_generated_pointwise_conv_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, output_channels = 2, 3, 33, 34
    input_values = [((pixel * 3 + channel) % 9) - 4
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for pixel in range(height * width):
        value = sum(input_values[pixel * channels:(pixel + 1) * channels]) & 0xFF
        expected.extend([value] * output_channels)
    model = _compile_pointwise_conv_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_afu_add_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 2 * 32
    lhs_values = [
        120 if index % 7 == 0 else ((index * 3) % 41) - 20
        for index in range(count)
    ]
    rhs_values = [
        20 if index % 7 == 0 else ((index * 5) % 31) - 15
        for index in range(count)
    ]
    expected = bytes(
        max(-128, min(127, lhs + rhs)) & 0xFF
        for lhs, rhs in zip(lhs_values, rhs_values)
    )
    model = _compile_afu_add_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (1, 1, INPUT2_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(
        dut, INPUT_BASE, bytes(value & 0xFF for value in lhs_values)
    )
    await write_l2_bytes(
        dut, INPUT2_BASE, bytes(value & 0xFF for value in rhs_values)
    )
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == expected


@cocotb.test()
async def test_compiler_generated_quantized_add_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 2 * 32
    lhs_values = [((index * 17 + 3) & 0xFF) - 128 for index in range(count)]
    rhs_values = [((index * 29 + 11) & 0xFF) - 128 for index in range(count)]
    model = _compile_quantized_add_model()
    commands_offset = struct.unpack_from("<I", model, 64 + 8)[0]
    commands_size = struct.unpack_from("<I", model, 64 + 12)[0]
    command_types = []
    offset = commands_offset
    while offset < commands_offset + commands_size:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        command_types.append(command_type)
        offset += command_size
    assert 34 in command_types

    # Read the exact compiler-emitted parameters so this independent reference
    # also freezes command field interpretation across the two repositories.
    afu_binary_offset = next(
        pos for pos in range(commands_offset, commands_offset + commands_size, 32)
        if struct.unpack_from("<H", model, pos)[0] == 34
    )
    # The command layout contains alternating signed scale / unsigned shift;
    # unpack explicitly to avoid relying on Python integer wraparound.
    lhs_scale = struct.unpack_from("<i", model, afu_binary_offset + 44)[0]
    lhs_shift = struct.unpack_from("<I", model, afu_binary_offset + 48)[0]
    rhs_scale = struct.unpack_from("<i", model, afu_binary_offset + 52)[0]
    rhs_shift = struct.unpack_from("<I", model, afu_binary_offset + 56)[0]
    output_scale = struct.unpack_from("<i", model, afu_binary_offset + 60)[0]
    output_shift = struct.unpack_from("<I", model, afu_binary_offset + 64)[0]
    lhs_zp, rhs_zp, output_zp, clamp_min, clamp_max = struct.unpack_from(
        "<5i", model, afu_binary_offset + 68
    )
    double_round_shift = struct.unpack_from("<I", model, afu_binary_offset + 88)[0]
    def scale_value(value, scale, shift, double_shift):
        if shift == 0:
            return value * scale
        correction = 1 << (30 - double_shift) if shift > 31 - double_shift else 0
        rounded = value * scale + (1 << (shift - 1))
        rounded += correction if value >= 0 else -correction
        return rounded >> shift

    expected = bytearray()
    for lhs, rhs in zip(lhs_values, rhs_values):
        value = scale_value(lhs - lhs_zp, lhs_scale, lhs_shift, double_round_shift)
        value += scale_value(rhs - rhs_zp, rhs_scale, rhs_shift, double_round_shift)
        value = scale_value(value, output_scale, output_shift, 0) + output_zp
        expected.append(min(max(value, clamp_min), clamp_max) & 0xFF)

    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (1, 1, INPUT2_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, bytes(value & 0xFF for value in lhs_values))
    await write_l2_bytes(dut, INPUT2_BASE, bytes(value & 0xFF for value in rhs_values))
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    await _load_and_run(dut, axi_master, invocation)

    status = await _axi_read32(axi_master, NPU_CMD_STATUS)
    fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
    fail_ptr = await _axi_read32(axi_master, NPU_CMD_FAIL_PTR)
    done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
    assert status == NPU_CMD_STATUS_PASS, (
        f"runtime failed: status=0x{status:08x} code=0x{fail_code:08x} "
        f"ptr=0x{fail_ptr:08x} done={done_count} types={command_types}"
    )
    assert fail_code == 0
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_compact_scalar_mul_lut_package(dut):
    import numpy as np
    import tensorflow as tf

    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 37
    input_values = [((index * 37 + 13) & 0xFF) - 128 for index in range(count)]
    fixture = Path(__file__).with_name("scalar_mul_p2_l37.tflite.b64")
    tflite_model = base64.b64decode(fixture.read_text(encoding="ascii"))
    interpreter = tf.lite.Interpreter(
        model_content=tflite_model,
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    interpreter.set_tensor(
        input_detail["index"], np.asarray(input_values, dtype=np.int8).reshape(1, 2, 37)
    )
    interpreter.invoke()
    expected = interpreter.get_tensor(output_detail["index"]).tobytes()

    model = _compile_compact_scalar_mul_model()
    commands_offset = struct.unpack_from("<I", model, 64 + 8)[0]
    commands_size = struct.unpack_from("<I", model, 64 + 12)[0]
    offset = commands_offset
    lut_commands = 0
    while offset < commands_offset + commands_size:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 12:
            assert struct.unpack_from("<I", model, offset + 40)[0] == count
            lut_commands += 1
        assert command_type != 17
        offset += command_size
    assert offset == commands_offset + commands_size
    assert lut_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, bytes(value & 0xFF for value in input_values))
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == expected


@cocotb.test()
async def test_compiler_generated_sigmoid_afu_lut_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 3 * 33
    input_data = bytes(range(count))
    expected = bytearray()
    for raw in input_data:
        signed = raw if raw < 128 else raw - 256
        real = max(-8.0, min(8.0, 0.125 * signed))
        logistic = 1.0 / (1.0 + math.exp(-real))
        quantized = max(-128, min(127, math.floor(-128.0 + 256.0 * logistic + 0.5)))
        expected.append(quantized & 0xFF)

    model = _compile_sigmoid_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    lut_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 12:
            assert command_size == 64
            assert struct.unpack_from("<H", model, offset + 16)[0] == 6
            assert struct.unpack_from("<H", model, offset + 24)[0] == 6
            assert struct.unpack_from("<H", model, offset + 32)[0] == 1
            assert struct.unpack_from("<I", model, offset + 40)[0] == 384
            lut_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert lut_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=300000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_silu_afu_lut_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 3 * 33
    input_data = bytes((index * 131 + 17) & 0xFF for index in range(count))
    expected = bytearray()
    for raw in input_data:
        signed = raw if raw < 128 else raw - 256
        real = max(-8.0, min(8.0, 0.125 * signed))
        logistic = 1.0 / (1.0 + math.exp(-real))
        quantized_logistic = max(
            -128, min(127, math.floor(-128.0 + 256.0 * logistic + 0.5))
        )
        product = signed * (quantized_logistic + 128)
        rounded = (
            (product + 64) // 128
            if product >= 0
            else -((-product + 64) // 128)
        )
        expected.append(max(-128, min(127, rounded)) & 0xFF)

    model = _compile_silu_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    command_types = []
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        assert command_size >= 32
        command_types.append(command_type)
        if command_type == 12:
            assert command_size == 64
            assert struct.unpack_from("<H", model, offset + 16)[0] == 6
            assert struct.unpack_from("<H", model, offset + 24)[0] == 6
            assert struct.unpack_from("<H", model, offset + 32)[0] == 1
            assert struct.unpack_from("<I", model, offset + 40)[0] == 384
        offset += command_size
    assert offset == command_offset + command_bytes
    assert command_types.count(12) == 1
    assert 13 not in command_types
    assert 17 not in command_types

    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == bytes(expected)
    assert counters["cycle"] > 0
    cocotb.log.warning(
        "compiler SiLU LUT package=%d bytes commands=%d runtime=%s ns "
        "PMU cycles=%d; diagnostic ratios vs Micro-MobileNet=%0.3fx "
        "and Micro-YOLO=%0.3fx",
        len(model),
        command_count,
        elapsed_ns,
        counters["cycle"],
        counters["cycle"] / 347_992,
        counters["cycle"] / 388_146,
    )
    cocotb.log.warning("%s", format_pmu_report(counters))


@cocotb.test()
async def test_compiler_generated_relu6_afu_lut_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    count = 2 * 3 * 33
    input_data = bytes(range(count))
    expected = bytearray()
    for raw in input_data:
        signed = raw if raw < 128 else raw - 256
        real = 0.25 * (signed + 3)
        clamped = max(0.0, min(6.0, real))
        quantized = max(-128, min(127, math.floor(-3.0 + clamped / 0.25 + 0.5)))
        expected.append(quantized & 0xFF)

    model = _compile_relu6_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    lut_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 12:
            assert command_size == 64
            assert struct.unpack_from("<H", model, offset + 16)[0] == 6
            assert struct.unpack_from("<H", model, offset + 24)[0] == 6
            assert struct.unpack_from("<H", model, offset + 32)[0] == 1
            assert struct.unpack_from("<I", model, offset + 40)[0] == 384
            lut_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert lut_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, count),
        (2, 0, OUTPUT_BASE, count),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(count))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation, timeout_cycles=300000)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, count)) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_global_avgpool_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 2, 3, 33
    deltas = (-5, -3, -1, 1, 3, 5)
    input_values = []
    expected_values = []
    for pixel in range(height * width):
        for channel in range(channels):
            base = (channel % 41) - 20
            input_values.append(base + deltas[pixel])
    for channel in range(channels):
        expected_values.append((channel % 41) - 20)
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytes(value & 0xFF for value in expected_values)
    model = _compile_global_avgpool_model()

    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    avgpool_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 14:
            assert command_size == 64
            assert struct.unpack_from("<3I", model, offset + 32) == (
                height,
                width,
                channels,
            )
            avgpool_commands += 1
        offset += command_size
    assert avgpool_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected
    assert counters["afu_done"] > 0
    cocotb.log.info(
        "compiler global AvgPool C33 runtime=%s ns PMU cycles=%d "
        "AFU done=%d AFU TCDM req=%d",
        elapsed_ns,
        counters["cycle"],
        counters["afu_done"],
        counters["afu_tcdm_req"],
    )


@cocotb.test()
async def test_compiler_generated_mean_fused_requant_packages(dut):
    """Check spatial and token Mean byte-for-byte against TensorFlow Lite."""
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )

    cases = (
        (
            "spatial",
            _compile_spatial_mean_model,
            (2, 3, 33),
            198,
            bytes.fromhex(
                "06fcf3ea292016c403faf0e7261dcbc101f7ee2d24d2c808fef5342bd8cf0e05fc"
            ),
        ),
        (
            "token",
            _compile_token_mean_model,
            (1, 7, 33),
            231,
            bytes.fromhex(
                "1a1bd3d41e2021d923dbdcde2829e1e2e3e4e63031e9eaebecee3839f1f2f3f4f6"
            ),
        ),
    )

    for name, compile_model, dimensions, input_count, expected in cases:
        await reset_dut(dut)
        input_data = bytes(((index * 37 + 11) % 255) - 128 & 0xFF
                           for index in range(input_count))
        model = compile_model()

        section_table_offset = struct.unpack_from("<I", model, 24)[0]
        command_offset = struct.unpack_from(
            "<I", model, section_table_offset + 8
        )[0]
        command_bytes = struct.unpack_from(
            "<I", model, section_table_offset + 12
        )[0]
        offset = command_offset
        avgpool_commands = 0
        while offset < command_offset + command_bytes:
            command_type, command_size = struct.unpack_from("<HH", model, offset)
            if command_type == 14:
                flags = struct.unpack_from("<I", model, offset + 4)[0]
                assert flags & (1 << 4)
                assert struct.unpack_from("<3I", model, offset + 32) == dimensions
                output_multiplier, output_shift, input_offset, output_zero_point = (
                    struct.unpack_from("<iIii", model, offset + 44)
                )
                assert output_multiplier > 0
                assert output_shift <= 63
                assert input_offset == dimensions[0] * dimensions[1]
                assert output_zero_point == -1
                avgpool_commands += 1
            offset += command_size
        assert offset == command_offset + command_bytes
        assert avgpool_commands == 1

        runtime_bindings = [
            (1, 0, INPUT_BASE, len(input_data)),
            (2, 0, OUTPUT_BASE, len(expected)),
        ]
        invocation, binding_addresses = build_invocation_with_bindings(
            model, runtime_bindings
        )
        await write_l2_bytes(dut, INPUT_BASE, input_data)
        await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
        await write_l2_bytes(dut, MODEL_BASE, model)
        await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
        await write_l2_bytes(dut, INVOCATION_BASE, invocation)

        await _load_and_run(dut, axi_master, invocation, timeout_cycles=300000)

        assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
        assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
        command_count = struct.unpack_from("<I", model, 32)[0]
        assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
        actual = bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected)))
        assert actual == expected, f"{name} Mean output differs from TFLite"


@cocotb.test()
async def test_compiler_generated_resize_nearest_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 2, 3, 32
    input_data = bytes((index * 29 + 7) & 0xFF for index in range(height * width * channels))
    expected = bytearray()
    for output_y in range(height * 2):
        input_y = output_y // 2
        for output_x in range(width * 2):
            input_x = output_x // 2
            pixel = (input_y * width + input_x) * channels
            expected.extend(input_data[pixel : pixel + channels])
    model = _compile_resize_nearest_model()

    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    upsample_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 20:
            assert command_size == 64
            assert struct.unpack_from("<H", model, offset + 16)[0] == 6
            assert struct.unpack_from("<H", model, offset + 24)[0] == 6
            assert struct.unpack_from("<5I", model, offset + 32) == (
                height,
                width,
                channels,
                2,
                2,
            )
            upsample_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert upsample_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)
    cocotb.log.info(
        "compiler nearest 2x C32 runtime=%s ns PMU cycles=%d",
        elapsed_ns,
        counters["cycle"],
    )


@cocotb.test()
async def test_compiler_generated_yolov8_resize_c256_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    input_h, input_w, channels = 10, 10, 256
    output_h, output_w = input_h * 2, input_w * 2
    output_base = 0x80010000
    input_data = bytes(
        (index * 37 + 11) & 0xFF
        for index in range(input_h * input_w * channels)
    )
    expected = bytearray()
    for output_y in range(output_h):
        for output_x in range(output_w):
            source = ((output_y // 2) * input_w + output_x // 2) * channels
            expected.extend(input_data[source : source + channels])

    model = _compile_yolov8_resize_c256_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    upsample_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 20:
            assert command_size == 64
            assert struct.unpack_from("<5I", model, offset + 32) == (
                input_h,
                input_w,
                channels,
                2,
                2,
            )
            upsample_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert upsample_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=600000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, output_base, len(expected))) == bytes(expected)
    cocotb.log.info(
        "compiler YOLO nearest 2x C256 runtime=%s ns PMU cycles=%d",
        elapsed_ns,
        counters["cycle"],
    )


@cocotb.test()
async def test_compiler_generated_maxpool_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 24, 24, 32
    maxpool_output_base = 0x80010000
    input_values = [
        ((index * 37 + 11) & 0xFF) - 256
        if ((index * 37 + 11) & 0xFF) >= 128
        else ((index * 37 + 11) & 0xFF)
        for index in range(height * width * channels)
    ]
    expected_values = []
    for output_y in range(height):
        for output_x in range(width):
            for channel in range(channels):
                value = -128
                for kernel_y in range(-2, 3):
                    input_y = output_y + kernel_y
                    if input_y < 0 or input_y >= height:
                        continue
                    for kernel_x in range(-2, 3):
                        input_x = output_x + kernel_x
                        if input_x < 0 or input_x >= width:
                            continue
                        index = (input_y * width + input_x) * channels + channel
                        value = max(value, input_values[index])
                expected_values.append(value)
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytes(value & 0xFF for value in expected_values)
    model = _compile_maxpool_model()

    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    maxpool_commands = 0
    layout_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 19:
            assert command_size == 96
            assert struct.unpack_from("<H", model, offset + 16)[0] == 6
            assert struct.unpack_from("<H", model, offset + 24)[0] == 6
            assert struct.unpack_from("<9I", model, offset + 32) == (
                height,
                width,
                channels,
                5,
                5,
                1,
                1,
                2,
                2,
            )
            maxpool_commands += 1
        if command_type == 18:
            layout_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert maxpool_commands == 1
    assert layout_commands == 2

    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, maxpool_output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, maxpool_output_base, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, maxpool_output_base, len(expected))) == expected
    cocotb.log.info(
        "compiler MaxPool K5/S1/P2 C32 runtime=%s ns PMU cycles=%d",
        elapsed_ns,
        counters["cycle"],
    )


@cocotb.test()
async def test_compiler_generated_yolov8_maxpool_c128_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 10, 10, 128
    output_base = 0x80010000
    input_values = [
        (index * 37 + 11) & 0xFF for index in range(height * width * channels)
    ]
    expected = bytearray()
    for output_y in range(height):
        for output_x in range(width):
            for channel in range(channels):
                value = -128
                for kernel_y in range(-2, 3):
                    input_y = output_y + kernel_y
                    if input_y < 0 or input_y >= height:
                        continue
                    for kernel_x in range(-2, 3):
                        input_x = output_x + kernel_x
                        if input_x < 0 or input_x >= width:
                            continue
                        raw = input_values[
                            (input_y * width + input_x) * channels + channel
                        ]
                        signed = raw if raw < 128 else raw - 256
                        value = max(value, signed)
                expected.append(value & 0xFF)

    model = _compile_yolov8_maxpool_c128_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    maxpool_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 19:
            assert command_size == 96
            assert struct.unpack_from("<9I", model, offset + 32) == (
                height,
                width,
                channels,
                5,
                5,
                1,
                1,
                2,
                2,
            )
            maxpool_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert maxpool_commands == 1

    input_data = bytes(input_values)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, output_base, len(expected))) == bytes(expected)
    cocotb.log.info(
        "compiler YOLO MaxPool K5/S1/P2 C128 runtime=%s ns PMU cycles=%d",
        elapsed_ns,
        counters["cycle"],
    )


@cocotb.test()
async def test_compiler_generated_yolov8_head_transpose_c144_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 10, 10, 144
    pixels = height * width
    output_base = 0x80010000
    input_data = bytes(
        (index * 37 + 11) & 0xFF for index in range(pixels * channels)
    )
    expected = bytes(
        input_data[pixel * channels + channel]
        for channel in range(channels)
        for pixel in range(pixels)
    )

    model = _compile_yolov8_head_transpose_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    head_pack_commands = 0
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 18 and struct.unpack_from("<H", model, offset + 32)[0] == 5:
            assert command_size == 96
            assert struct.unpack_from("<4I", model, offset + 40) == (
                1,
                height,
                width,
                channels,
            )
            assert struct.unpack_from("<3I", model, offset + 56) == (
                channels,
                pixels * 32,
                pixels,
            )
            head_pack_commands += 1
        offset += command_size
    assert offset == command_offset + command_bytes
    assert head_pack_commands == 1

    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, output_base, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, output_base, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)
    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    status = await _axi_read32(axi_master, NPU_CMD_STATUS)
    fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
    fail_pointer = await _axi_read32(axi_master, NPU_CMD_FAIL_PTR)
    done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
    assert status == NPU_CMD_STATUS_PASS, (
        f"runtime failed: status=0x{status:08x} code=0x{fail_code:08x} "
        f"pointer=0x{fail_pointer:08x} done={done_count}"
    )
    assert fail_code == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert done_count == command_count
    assert bytes(await read_l2_bytes(dut, output_base, len(expected))) == expected
    cocotb.log.info(
        "compiler YOLO C144 head transpose runtime=%s ns PMU cycles=%d",
        elapsed_ns,
        counters["cycle"],
    )


@cocotb.test()
async def test_compiler_generated_concat_c32_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, input_channels = 24, 24, 32
    input_bytes = height * width * input_channels
    output_bytes = input_bytes * 2
    rhs_base = 0x80010000
    concat_output_base = 0x80020000
    lhs = bytes((index * 29 + 7) & 0xFF for index in range(input_bytes))
    rhs = bytes((index * 43 + 19) & 0xFF for index in range(input_bytes))
    expected = bytearray()
    for pixel in range(height * width):
        offset = pixel * input_channels
        expected.extend(lhs[offset : offset + input_channels])
        expected.extend(rhs[offset : offset + input_channels])

    model = _compile_concat_model()
    section_table_offset = struct.unpack_from("<I", model, 24)[0]
    command_offset = struct.unpack_from("<I", model, section_table_offset + 8)[0]
    command_bytes = struct.unpack_from("<I", model, section_table_offset + 12)[0]
    offset = command_offset
    layout_commands = 0
    local_dma_commands = []
    while offset < command_offset + command_bytes:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 18:
            layout_commands += 1
        if command_type == 2:
            source_region = struct.unpack_from("<H", model, offset + 16)[0]
            destination_region = struct.unpack_from("<H", model, offset + 24)[0]
            destination_offset = struct.unpack_from("<I", model, offset + 28)[0]
            length, direction = struct.unpack_from("<II", model, offset + 32)
            if direction == 2:
                assert source_region == 6
                assert destination_region == 6
                assert length == input_bytes
                local_dma_commands.append(destination_offset)
        offset += command_size
    assert offset == command_offset + command_bytes
    assert layout_commands == 3
    assert len(local_dma_commands) == 2
    assert abs(local_dma_commands[1] - local_dma_commands[0]) == input_bytes

    runtime_bindings = [
        (1, 0, INPUT_BASE, input_bytes),
        (1, 1, rhs_base, input_bytes),
        (2, 0, concat_output_base, output_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, lhs)
    await write_l2_bytes(dut, rhs_base, rhs)
    await write_l2_bytes(dut, concat_output_base, bytes(output_bytes))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    start_ns = get_sim_time("ns")
    counters = await _load_and_run(
        dut, axi_master, invocation, timeout_cycles=300000, measure_pmu=True
    )
    elapsed_ns = get_sim_time("ns") - start_ns

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, concat_output_base, output_bytes)) == bytes(expected)
    cocotb.log.warning(
        "compiler Concat C32+C32 runtime=%s ns PMU cycles=%d",
        elapsed_ns,
        counters["cycle"],
    )


@cocotb.test()
async def test_compiler_generated_public_reshape_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    tensor_bytes = 4 * 32
    input_data = bytes((index * 29 + 7) & 0xFF for index in range(tensor_bytes))
    model = _compile_public_reshape_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, tensor_bytes),
        (2, 0, OUTPUT_BASE, tensor_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model, runtime_bindings
    )
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(tensor_bytes))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert command_count == 2
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, tensor_bytes)) == input_data


@cocotb.test()
async def test_compiler_generated_high_c16_slice_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 2, 3, 32
    input_data = bytearray(height * width * channels)
    for pixel in range(height * width):
        input_data[pixel * channels] = 1
    expected = bytes([32] * (height * width * channels))

    model = _compile_high_c16_slice_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, bytes(input_data))
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected


@cocotb.test()
async def test_compiler_generated_generic_k3_conv_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, output_channels = 4, 4, 32, 32
    input_values = [((pixel * 3 + channel) % 9) - 4
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for output_y in range(height):
        for output_x in range(width):
            value = 0
            for kernel_y in range(3):
                input_y = output_y + kernel_y - 1
                for kernel_x in range(3):
                    input_x = output_x + kernel_x - 1
                    if 0 <= input_y < height and 0 <= input_x < width:
                        pixel = input_y * width + input_x
                        value += sum(input_values[pixel * channels:(pixel + 1) * channels])
            value = max(-128, min(127, value)) & 0xFF
            expected.extend([value] * output_channels)

    model = _compile_generic_k3_conv_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_generic_k3_c48_tail_package(dut):
    import numpy as np
    import tensorflow as tf

    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels = 4, 4, 48
    input_values = [((pixel * 5 + channel * 3) % 17) - 8
                    for pixel in range(height * width)
                    for channel in range(channels)]
    fixture = Path(__file__).with_name(
        "generic_k3_conv_h4w4_k48_n32.tflite.zlib.b64"
    )
    tflite_model = zlib.decompress(base64.b64decode(fixture.read_text(encoding="ascii")))
    interpreter = tf.lite.Interpreter(
        model_content=tflite_model,
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    interpreter.set_tensor(
        input_detail["index"], np.asarray(input_values, dtype=np.int8).reshape(1, 4, 4, 48)
    )
    interpreter.invoke()
    expected = interpreter.get_tensor(output_detail["index"]).tobytes()

    model = _compile_generic_k3_c48_conv_model()
    commands_offset = struct.unpack_from("<I", model, 64 + 8)[0]
    commands_size = struct.unpack_from("<I", model, 64 + 12)[0]
    offset = commands_offset
    linebuffer_jobs = 0
    while offset < commands_offset + commands_size:
        command_type, command_size = struct.unpack_from("<HH", model, offset)
        if command_type == 9:
            linebuffer_jobs += 1
        offset += command_size
    assert offset == commands_offset + commands_size
    assert linebuffer_jobs == 2

    input_data = bytes(value & 0xFF for value in input_values)
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == expected


@cocotb.test()
async def test_compiler_generated_selected_yolo320_first_stem_tile(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    _, full_model = _compile_selected_yolo320_model()
    prefix_commands = int(os.environ.get("YOLO320_PREFIX_COMMANDS", "6"))
    timeout_cycles = int(os.environ.get("YOLO320_PREFIX_TIMEOUT_CYCLES", "1000000"))
    model = _extract_selected_yolo320_command_prefix(full_model, prefix_commands)
    input_base = 0x80000000
    output_base = 0x80100000
    l2_temporary_base = 0x80200000
    invocation_base = 0x81400000
    model_base = 0x81000000
    binding_table_base = 0x81401000
    input_bytes = 320 * 320 * 3
    output_bytes = 84 * 2100
    l2_temporary_bytes = 307200
    input_data = bytes(((index * 37 + 11) & 0xFF) for index in range(input_bytes))
    runtime_bindings = [
        (1, 0, input_base, input_bytes),
        (2, 0, output_base, output_bytes),
        (3, 0, l2_temporary_base, l2_temporary_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(output_bytes))
    await write_l2_bytes(dut, l2_temporary_base, bytes(l2_temporary_bytes))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=timeout_cycles,
        invocation_base=invocation_base,
        model=model,
    )

    status = await _axi_read32(axi_master, NPU_CMD_STATUS)
    fail_code = await _axi_read32(axi_master, NPU_CMD_FAIL_CODE)
    fail_pointer = await _axi_read32(axi_master, NPU_CMD_FAIL_PTR)
    done_count = await _axi_read32(axi_master, NPU_CMD_DONE_COUNT)
    assert (status, fail_code, fail_pointer, done_count) == (
        NPU_CMD_STATUS_PASS,
        0,
        0,
        prefix_commands,
    )


@cocotb.test()
async def test_compiler_generated_selected_yolo320_isolated_range(dut):
    """Replay a restart-safe YOLO command range with deterministic memory."""
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    first_command = int(os.environ.get("YOLO320_RANGE_START", "1367"))
    end_command = int(os.environ.get("YOLO320_RANGE_END", "1455"))
    timeout_cycles = int(os.environ.get("YOLO320_RANGE_TIMEOUT_CYCLES", "500000"))
    padding_bytes = int(os.environ.get("YOLO320_RANGE_PADDING_BYTES", "0"))
    leading_padding_bytes = int(
        os.environ.get("YOLO320_RANGE_LEADING_PADDING_BYTES", "0")
    )
    assert leading_padding_bytes >= 0 and leading_padding_bytes % 32 == 0
    assert padding_bytes >= 0 and padding_bytes % 32 == 0
    leading_padding_command_count = leading_padding_bytes // 32
    padding_command_count = padding_bytes // 32
    replay_manifest = os.environ.get("NAI_REPLAY_MANIFEST")
    if replay_manifest:
        # This package already contains the sliced commands and padding. Do
        # not recompile, relocate sections, or insert padding a second time.
        model = _load_pinned_range(replay_manifest)
    else:
        _model_path, full_model = _compile_selected_yolo320_model()
        _require_restart_safe_boundary(full_model, first_command)
        _require_restart_safe_boundary(full_model, end_command)
        model = _extract_selected_yolo320_command_range(
            full_model, first_command, end_command
        )
        if leading_padding_bytes or padding_bytes:
            commands, end = _logical_command_records(model)
            leading_padding_commands = [
                _command_header(1, 32, tile=index).ljust(32, b"\x00")
                for index in range(leading_padding_command_count)
            ]
            padding_commands = [
                _command_header(1, 32, tile=end_command + index).ljust(32, b"\x00")
                for index in range(padding_command_count)
            ]
            model = _replace_command_section(
                model, leading_padding_commands + commands + padding_commands, end
            )
    commands, _end = _logical_command_records(model)
    assert len(commands) == (
        end_command - first_command + leading_padding_command_count + padding_command_count
    )

    input_base = 0x80000000
    output_base = 0x80100000
    l2_temporary_base = 0x80200000
    invocation_base = 0x81400000
    model_base = int(
        os.environ.get("YOLO320_RANGE_MODEL_BASE", "0x81000000"), 0
    )
    binding_table_base = 0x81401000
    input_bytes = 320 * 320 * 3
    output_bytes = 84 * 2100
    l2_temporary_bytes = 307200
    runtime_bindings = [
        (1, 0, input_base, input_bytes),
        (2, 0, output_base, output_bytes),
        (3, 0, l2_temporary_base, l2_temporary_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    write_tcdm_bytes(dut, bytes(TCDM_TOTAL_BYTES))
    await write_l2_bytes(dut, input_base, bytes(input_bytes))
    await write_l2_bytes(dut, output_base, bytes(output_bytes))
    await write_l2_bytes(dut, l2_temporary_base, bytes(l2_temporary_bytes))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=timeout_cycles,
        invocation_base=invocation_base,
        model=model,
    )

    expected_commands = (
        end_command
        - first_command
        + leading_padding_command_count
        + padding_command_count
    )
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == expected_commands


@cocotb.test()
async def test_compiler_generated_selected_yolo320_segmented_prefix(dut):
    """Continue a YOLO command prefix across resets without clearing SRAM."""
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model_path, full_model = _compile_selected_yolo320_model()
    total_commands = struct.unpack_from("<I", full_model, 32)[0]
    snapshot_input_path = os.environ.get("YOLO320_SNAPSHOT_IN", "")
    snapshot_output_path = os.environ.get("YOLO320_SNAPSHOT_OUT", "")
    first_command = 0
    segment_ends = [
        int(value)
        for value in os.environ.get("YOLO320_SEGMENT_ENDS", "131,141").split(",")
        if value.strip()
    ]
    assert segment_ends
    timeout_cycles = int(os.environ.get("YOLO320_SEGMENT_TIMEOUT_CYCLES", "1000000"))
    command_pmu_csv = os.environ.get("YOLO320_COMMAND_PMU_CSV", "")
    command_pmu_csv_written = False

    input_base = 0x80000000
    output_base = 0x80100000
    l2_temporary_base = 0x80200000
    invocation_base = 0x81400000
    model_base = 0x81000000
    binding_table_base = 0x81401000
    input_bytes = 320 * 320 * 3
    output_bytes = 84 * 2100
    l2_temporary_bytes = 307200
    input_data = bytes(((index * 37 + 11) & 0xFF) for index in range(input_bytes))
    expected_output = None
    if segment_ends[-1] == total_commands:
        import numpy as np
        import tensorflow as tf

        interpreter = tf.lite.Interpreter(
            model_path=str(model_path),
            experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
        )
        interpreter.allocate_tensors()
        input_detail = interpreter.get_input_details()[0]
        output_detail = interpreter.get_output_details()[0]
        input_tensor = np.frombuffer(input_data, dtype=np.uint8).view(np.int8).reshape(
            1, 320, 320, 3
        )
        interpreter.set_tensor(input_detail["index"], input_tensor)
        interpreter.invoke()
        expected_output = interpreter.get_tensor(output_detail["index"]).tobytes()
        assert len(expected_output) == output_bytes
    runtime_bindings = [
        (1, 0, input_base, input_bytes),
        (2, 0, output_base, output_bytes),
        (3, 0, l2_temporary_base, l2_temporary_bytes),
    ]
    await write_l2_bytes(dut, input_base, input_data)
    if snapshot_input_path:
        snapshot_input = Path(snapshot_input_path)
        boundary, tcdm, l2_temporary, output = _verify_yolo320_snapshot(
            full_model,
            snapshot_input.read_bytes(),
            expected_boundary=_yolo320_snapshot_path_boundary(snapshot_input),
            expected_tcdm=TCDM_TOTAL_BYTES,
            expected_temporary=l2_temporary_bytes,
            expected_output=output_bytes,
        )
        _require_restart_safe_boundary(full_model, boundary)
        assert len(l2_temporary) == l2_temporary_bytes
        assert len(output) == output_bytes
        first_command = boundary
        await hold_reset(dut)
        write_tcdm_bytes(dut, tcdm)
        await write_l2_bytes(dut, l2_temporary_base, l2_temporary)
        await write_l2_bytes(dut, output_base, output)
        if read_tcdm_bytes(dut) != tcdm:
            raise AssertionError("YOLO320 snapshot TCDM restore verification failed")
        if bytes(await read_l2_bytes(dut, l2_temporary_base, l2_temporary_bytes)) != l2_temporary:
            raise AssertionError("YOLO320 snapshot L2 temporary restore verification failed")
        if bytes(await read_l2_bytes(dut, output_base, output_bytes)) != output:
            raise AssertionError("YOLO320 snapshot output restore verification failed")
        await release_reset(dut)
        dut._log.info(
            "YOLO320 SNAPSHOT INTEGRITY OK: restored command %d from %s; "
            "model/payload CRC, sizes and memory readback match",
            first_command,
            snapshot_input_path,
        )
    else:
        await write_l2_bytes(dut, output_base, bytes(output_bytes))
        await write_l2_bytes(dut, l2_temporary_base, bytes(l2_temporary_bytes))

    assert all(
        previous < current
        for previous, current in zip([first_command] + segment_ends[:-1], segment_ends)
    )
    assert segment_ends[-1] <= total_commands
    for command_boundary in segment_ends:
        _require_restart_safe_boundary(full_model, command_boundary)

    multiple_snapshot_boundaries = len(segment_ends) > 1
    for segment_index, end_command in enumerate(segment_ends):
        if segment_index != 0:
            await reset_dut(dut)
        model = _extract_selected_yolo320_command_range(
            full_model, first_command, end_command
        )
        invocation, binding_addresses = build_invocation_with_bindings(
            model,
            runtime_bindings,
            model_base=model_base,
            binding_table_base=binding_table_base,
        )
        await write_l2_bytes(dut, model_base, model)
        await write_l2_bytes(dut, binding_table_base, binding_addresses)
        await write_l2_bytes(dut, invocation_base, invocation)

        command_trace_records = (
            _selected_command_trace_records(full_model, first_command, end_command)
            if command_pmu_csv
            else None
        )
        command_trace_callback = None
        if command_trace_records is not None:

            def command_trace_callback(command_index, command_counters):
                nonlocal command_pmu_csv_written
                _write_command_pmu_csv(
                    command_pmu_csv,
                    [command_trace_records[command_index]],
                    [command_counters],
                    append=command_pmu_csv_written,
                )
                command_pmu_csv_written = True

        run_result = await _load_and_run(
            dut,
            axi_master,
            invocation,
            timeout_cycles=timeout_cycles,
            invocation_base=invocation_base,
            model=model,
            command_trace_records=command_trace_records,
            command_trace_callback=command_trace_callback,
        )
        if command_trace_records is not None:
            _segment_pmu, command_pmu = run_result
            assert len(command_pmu) == len(command_trace_records) - 1
            dut._log.info(
                "YOLO320 wrote per-command PMU for commands %d-%d to %s",
                first_command + 1,
                end_command,
                command_pmu_csv,
            )
        segment_commands = end_command - first_command
        assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
        assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
        assert await _axi_read32(axi_master, NPU_CMD_FAIL_PTR) == 0
        assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == segment_commands
        dut._log.info(
            "YOLO320 segmented prefix completed commands %d-%d",
            first_command + 1,
            end_command,
        )
        first_command = end_command
        if expected_output is not None and first_command == total_commands:
            actual_output = bytes(await read_l2_bytes(dut, output_base, output_bytes))
            assert actual_output == expected_output, (
                "YOLO320 final output differs from TensorFlow Lite reference: "
                f"actual_crc=0x{zlib.crc32(actual_output) & 0xFFFFFFFF:08x} "
                f"expected_crc=0x{zlib.crc32(expected_output) & 0xFFFFFFFF:08x}"
            )
            dut._log.info(
                "YOLO320 OUTPUT DATA PASS: %d bytes match TensorFlow Lite reference "
                "(crc32=0x%08x)",
                output_bytes,
                zlib.crc32(actual_output) & 0xFFFFFFFF,
            )
        if snapshot_output_path:
            output_path = _yolo320_snapshot_output_path(
                snapshot_output_path, first_command, multiple_snapshot_boundaries
            )
            snapshot_tcdm = read_tcdm_bytes(dut)
            snapshot_temporary = bytes(
                await read_l2_bytes(dut, l2_temporary_base, l2_temporary_bytes)
            )
            snapshot_output = bytes(await read_l2_bytes(dut, output_base, output_bytes))
            snapshot = _encode_yolo320_snapshot(
                full_model,
                first_command,
                snapshot_tcdm,
                snapshot_temporary,
                snapshot_output,
            )
            output_path.write_bytes(snapshot)
            stored_snapshot = output_path.read_bytes()
            _verify_yolo320_snapshot(
                full_model,
                stored_snapshot,
                expected_boundary=first_command,
                expected_tcdm=snapshot_tcdm,
                expected_temporary=snapshot_temporary,
                expected_output=snapshot_output,
            )
            dut._log.info(
                "YOLO320 SNAPSHOT INTEGRITY OK: command %d written to %s (%d bytes); "
                "model/payload CRC, sizes and live memory match",
                first_command,
                output_path,
                len(stored_snapshot),
            )


@cocotb.test()
async def test_compiler_generated_selected_yolo320_full_graph(dut):
    import numpy as np
    import tensorflow as tf

    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model_path, model = _compile_selected_yolo320_model()
    input_base = 0x80000000
    output_base = 0x80100000
    l2_temporary_base = 0x80200000
    invocation_base = 0x81400000
    model_base = 0x81000000
    binding_table_base = 0x81401000
    input_bytes = 320 * 320 * 3
    output_bytes = 84 * 2100
    l2_temporary_bytes = 307200

    interpreter = tf.lite.Interpreter(
        model_path=str(model_path),
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    input_values = ((np.arange(input_bytes, dtype=np.uint32) * 37 + 11) & 0xFF).astype(np.uint8)
    input_tensor = input_values.view(np.int8).reshape(1, 320, 320, 3)
    interpreter.set_tensor(input_detail["index"], input_tensor)
    interpreter.invoke()
    expected = interpreter.get_tensor(output_detail["index"]).tobytes()
    assert len(expected) == output_bytes

    command_count = struct.unpack_from("<I", model, 32)[0]
    logical_commands, _end = _logical_command_records(model)
    assert command_count == len(logical_commands)
    assert struct.unpack_from("<I", model, 36)[0] <= 520192
    runtime_bindings = [
        (1, 0, input_base, input_bytes),
        (2, 0, output_base, output_bytes),
        (3, 0, l2_temporary_base, l2_temporary_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, input_base, input_values.tobytes())
    await write_l2_bytes(dut, output_base, bytes(output_bytes))
    await write_l2_bytes(dut, l2_temporary_base, bytes(l2_temporary_bytes))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    command_pmu_csv = os.environ.get("YOLO320_COMMAND_PMU_CSV", "")
    command_trace_records = (
        _selected_command_trace_records(model, 0, command_count)
        if command_pmu_csv
        else None
    )
    command_trace_callback = None
    if command_trace_records is not None:

        def command_trace_callback(command_index, command_counters):
            _write_command_pmu_csv(
                command_pmu_csv,
                [command_trace_records[command_index]],
                [command_counters],
                append=command_index != 0,
            )

    run_result = await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=int(os.environ.get("YOLO320_TIMEOUT_CYCLES", "10000000")),
        invocation_base=invocation_base,
        model=model,
        command_trace_records=command_trace_records,
        command_trace_callback=command_trace_callback,
    )
    if command_trace_records is not None:
        _model_pmu, command_pmu = run_result
        assert len(command_pmu) == command_count
        dut._log.info(
            "YOLO320 wrote per-command PMU for %d commands to %s",
            command_count,
            command_pmu_csv,
        )

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, output_base, output_bytes)) == expected


@cocotb.test()
async def test_compiler_generated_selected_mobilenet224_prefix(dut):
    """Run a short MobileNet prefix for fast command-stream regressions."""
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    _model_path, full_model = _compile_selected_mobilenet224_model()
    commands, end = _logical_command_records(full_model)
    prefix_commands = int(os.environ.get("MOBILENET224_PREFIX_COMMANDS", "140"))
    assert 0 < prefix_commands <= len(commands)
    model = _replace_command_section(full_model, commands[:prefix_commands], end)
    bindings = _model_binding_descriptors(model)
    input_binding = next(binding for binding in bindings if binding[0] == 1)
    output_binding = next(binding for binding in bindings if binding[0] == 2)
    temporary_binding = next(binding for binding in bindings if binding[0] == 3)
    input_base = 0x80000000
    output_base = 0x80100000
    temporary_base = 0x80200000
    model_base = 0x81000000
    invocation_base = 0x81800000
    binding_table_base = 0x81801000
    runtime_bindings = [
        (1, input_binding[1], input_base, input_binding[2]),
        (2, output_binding[1], output_base, output_binding[2]),
        (3, temporary_binding[1], temporary_base, temporary_binding[2]),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    input_data = bytes(
        ((index * 37 + 11) & 0xFF) for index in range(input_binding[2])
    )
    await write_l2_bytes(dut, input_base, input_data)
    await write_l2_bytes(dut, output_base, bytes(output_binding[2]))
    await write_l2_bytes(dut, temporary_base, bytes(temporary_binding[2]))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=int(os.environ.get("MOBILENET224_PREFIX_TIMEOUT_CYCLES", "1000000")),
        invocation_base=invocation_base,
        model=model,
    )
    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == prefix_commands


@cocotb.test()
async def test_compiler_generated_selected_mobilenet224_full_graph(dut):
    import numpy as np
    import tensorflow as tf

    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    model_path, model = _compile_selected_mobilenet224_model()
    bindings = _model_binding_descriptors(model)
    input_bindings = [binding for binding in bindings if binding[0] == 1]
    output_bindings = [binding for binding in bindings if binding[0] == 2]
    temporary_bindings = [binding for binding in bindings if binding[0] == 3]
    assert len(input_bindings) == len(output_bindings) == len(temporary_bindings) == 1
    input_bytes = input_bindings[0][2]
    output_bytes = output_bindings[0][2]
    l2_temporary_bytes = temporary_bindings[0][2]

    interpreter = tf.lite.Interpreter(
        model_path=str(model_path),
        experimental_op_resolver_type=tf.lite.experimental.OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    input_values = ((np.arange(input_bytes, dtype=np.uint32) * 37 + 11) & 0xFF).astype(np.uint8)
    input_tensor = input_values.view(np.int8).reshape(input_detail["shape"])
    interpreter.set_tensor(input_detail["index"], input_tensor)
    interpreter.invoke()
    expected = interpreter.get_tensor(output_detail["index"]).tobytes()
    assert input_tensor.nbytes == input_bytes
    assert len(expected) == output_bytes

    input_base = 0x80000000
    output_base = 0x80100000
    l2_temporary_base = 0x80200000
    model_base = 0x81000000
    invocation_base = 0x81800000
    binding_table_base = 0x81801000
    command_count = struct.unpack_from("<I", model, 32)[0]
    logical_commands, _end = _logical_command_records(model)
    assert command_count == len(logical_commands)
    assert struct.unpack_from("<I", model, 36)[0] <= TCDM_TOTAL_BYTES
    assert model_base + len(model) <= invocation_base

    runtime_bindings = [
        (1, input_bindings[0][1], input_base, input_bytes),
        (2, output_bindings[0][1], output_base, output_bytes),
        (3, temporary_bindings[0][1], l2_temporary_base, l2_temporary_bytes),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(
        model,
        runtime_bindings,
        model_base=model_base,
        binding_table_base=binding_table_base,
    )
    await write_l2_bytes(dut, input_base, input_values.tobytes())
    await write_l2_bytes(dut, output_base, bytes(output_bytes))
    await write_l2_bytes(dut, l2_temporary_base, bytes(l2_temporary_bytes))
    await write_l2_bytes(dut, model_base, model)
    await write_l2_bytes(dut, binding_table_base, binding_addresses)
    await write_l2_bytes(dut, invocation_base, invocation)

    command_pmu_csv = os.environ.get("MOBILENET224_COMMAND_PMU_CSV", "")
    command_trace_records = (
        _selected_command_trace_records(model, 0, command_count)
        if command_pmu_csv
        else None
    )
    command_trace_callback = None
    if command_trace_records is not None:

        def command_trace_callback(command_index, command_counters):
            _write_command_pmu_csv(
                command_pmu_csv,
                [command_trace_records[command_index]],
                [command_counters],
                append=command_index != 0,
            )

    run_result = await _load_and_run(
        dut,
        axi_master,
        invocation,
        timeout_cycles=int(os.environ.get("MOBILENET224_TIMEOUT_CYCLES", "50000000")),
        invocation_base=invocation_base,
        model=model,
        command_trace_records=command_trace_records,
        command_trace_callback=command_trace_callback,
    )
    if command_trace_records is not None:
        _model_pmu, command_pmu = run_result
        assert len(command_pmu) == command_count
        dut._log.info(
            "MobileNet224 wrote per-command PMU for %d commands to %s",
            command_count,
            command_pmu_csv,
        )

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_PTR) == 0
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    actual = bytes(await read_l2_bytes(dut, output_base, output_bytes))
    assert actual == expected, (
        "MobileNet224 final output differs from TensorFlow Lite reference: "
        f"actual_crc=0x{zlib.crc32(actual) & 0xFFFFFFFF:08x} "
        f"expected_crc=0x{zlib.crc32(expected) & 0xFFFFFFFF:08x}"
    )
    dut._log.info(
        "MobileNet224 OUTPUT DATA PASS: %d bytes match TensorFlow Lite reference "
        "(crc32=0x%08x)",
        output_bytes,
        zlib.crc32(actual) & 0xFFFFFFFF,
    )


@cocotb.test()
async def test_compiler_generated_rgb_k3_conv_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, output_height, output_width = 7, 7, 3, 4, 4
    input_values = [((pixel * 5 + channel) % 11) - 5
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for output_y in range(output_height):
        for output_x in range(output_width):
            value = 0
            for kernel_y in range(3):
                input_y = output_y * 2 + kernel_y - 1
                for kernel_x in range(3):
                    input_x = output_x * 2 + kernel_x - 1
                    if 0 <= input_y < height and 0 <= input_x < width:
                        pixel = input_y * width + input_x
                        value += sum(input_values[pixel * channels:(pixel + 1) * channels])
            value = max(-128, min(127, value)) & 0xFF
            expected.extend([value] * 32)

    model = _compile_rgb_k3_conv_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_generated_depthwise_k3_conv_package(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    height, width, channels, output_height, output_width = 3, 3, 33, 2, 2
    input_values = [((pixel * 5 + channel * 3) % 13) - 6
                    for pixel in range(height * width)
                    for channel in range(channels)]
    input_data = bytes(value & 0xFF for value in input_values)
    expected = bytearray()
    for output_y in range(output_height):
        for output_x in range(output_width):
            channel_values = [0] * channels
            for kernel_y in range(3):
                input_y = output_y * 2 + kernel_y - 1
                for kernel_x in range(3):
                    input_x = output_x * 2 + kernel_x - 1
                    if 0 <= input_y < height and 0 <= input_x < width:
                        pixel = input_y * width + input_x
                        for channel in range(channels):
                            channel_values[channel] += input_values[pixel * channels + channel]
            expected.extend(max(-128, min(127, value)) & 0xFF for value in channel_values)

    model = _compile_depthwise_k3_conv_model()
    runtime_bindings = [
        (1, 0, INPUT_BASE, len(input_data)),
        (2, 0, OUTPUT_BASE, len(expected)),
    ]
    invocation, binding_addresses = build_invocation_with_bindings(model, runtime_bindings)
    await write_l2_bytes(dut, INPUT_BASE, input_data)
    await write_l2_bytes(dut, OUTPUT_BASE, bytes(len(expected)))
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_PASS
    assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == 0
    command_count = struct.unpack_from("<I", model, 32)[0]
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == command_count
    assert bytes(await read_l2_bytes(dut, OUTPUT_BASE, len(expected))) == bytes(expected)


@cocotb.test()
async def test_compiler_runtime_rejects_invalid_bindings(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    model = build_model()
    invocation, original_addresses = build_invocation(model)
    invalid_records = []
    misaligned = bytearray(original_addresses)
    struct.pack_into("<I", misaligned, 20, OUTPUT_BASE + 4)
    invalid_records.append(misaligned)
    undersized = bytearray(original_addresses)
    struct.pack_into("<I", undersized, 24, 16)
    invalid_records.append(undersized)

    for binding_addresses in invalid_records:
        await reset_dut(dut)
        await write_l2_bytes(dut, MODEL_BASE, model)
        await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
        await write_l2_bytes(dut, INVOCATION_BASE, invocation)
        await _load_and_run(dut, axi_master, invocation)
        assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_FAIL
        assert await _axi_read32(axi_master, NPU_CMD_FAIL_CODE) == NPU_CMD_FAIL_BAD_BINDING
        assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 0


@cocotb.test()
async def test_compiler_runtime_rejects_malformed_linebuf_job(dut):
    cocotb.start_soon(Clock(dut.clk_i, 1, unit="ns").start())
    axi_master = AxiLiteMaster(
        AxiLiteBus.from_prefix(dut, "s_axi"),
        dut.clk_i,
        dut.rst_ni,
        reset_active_level=False,
    )
    await reset_dut(dut)

    qparams = b"".join(
        struct.pack("<iiIiiiII", 0, 1 << 30, 30, 0, -128, 127, 0, 0)
        for _ in range(32)
    )
    commands = b"".join(
        [
            _command_header(5, 32, tile=0) + struct.pack("<4I", 0, 32, 0, 0),
            _linebuf_job(8, 1),  # K3*C32 requires nine K tiles.
            _command_header(0, 32, tile=2).ljust(32, b"\x00"),
        ]
    )
    model = _package(commands, b"", b"", 2, 0x1000, 0, 0, qparams)
    invocation, binding_addresses = build_invocation_with_bindings(model, [])
    await write_l2_bytes(dut, MODEL_BASE, model)
    await write_l2_bytes(dut, BINDING_TABLE_BASE, binding_addresses)
    await write_l2_bytes(dut, INVOCATION_BASE, invocation)

    await _load_and_run(dut, axi_master, invocation)

    assert await _axi_read32(axi_master, NPU_CMD_STATUS) == NPU_CMD_STATUS_FAIL
    assert await _axi_read32(axi_master, NPU_CMD_DONE_COUNT) == 1
