#include "npu_model_runtime.h"

#include "idma_mm_utils.h"
#include "npu_cmd_desc.h"
#include "npu_cmd_desc_v2.h"
#include "npu_memory_map.h"
#include "npu_model_loader.h"
#include "npu_quant_buffer.h"
#include "npu_runtime_ops.h"
#include "npu_stream_prefetch.h"

#ifndef NAI_COMMAND_PREFETCH
#define NAI_COMMAND_PREFETCH 1
#endif

#if defined(NAI_TRUSTED_FIRMWARE)
#define NAI_TRUSTED_INVALID(condition) 0u
#else
#define NAI_TRUSTED_INVALID(condition) (condition)
#endif

typedef struct {
    uint32_t base;
    uint32_t bytes;
    uint32_t staging_base;
    uint32_t staging_bytes;
    nai_stream_prefetch_t *prefetch;
} l2_reader_context_t;

static nai_model_stream_storage_v1_t g_model_storage;
static nai_binding_address_v1_t g_binding_addresses[NAI_MAX_BINDINGS_V1];
/* Affine loop bodies are fetched once and expanded in DTCM. */
static uint8_t g_command_buffer[NAI_AFFINE_LOOP_MAX_RECORD_BYTES] __attribute__((aligned(32)));

#if defined(NAI_PMU_PROFILE) && NAI_PMU_PROFILE
void nai_pmu_command_begin(uint32_t command_id)
{
    REG_WRITE(NPU_CMD_PMU_BEGIN, command_id);
}

void nai_pmu_command_end(uint32_t command_id)
{
    REG_WRITE(NPU_CMD_PMU_END, command_id);
}

static inline void pmu_phase(uint32_t phase)
{
    REG_WRITE(NPU_CMD_PMU_PHASE, phase);
}
#else
static inline void pmu_phase(uint32_t phase)
{
    (void)phase;
}
#endif

static uint32_t l2_read(void *context_pointer, uint32_t offset, void *destination, uint32_t bytes)
{
    l2_reader_context_t *context = (l2_reader_context_t *)context_pointer;
    volatile const uint8_t *staging = (volatile const uint8_t *)(unsigned long)context->staging_base;

    if (context->prefetch != 0)
        return nai_stream_prefetch_read(context->prefetch, offset, destination, bytes);
    if (bytes == 0u) return 0u;
    if (offset > context->bytes || bytes > context->bytes - offset || bytes > context->staging_bytes ||
        context->base > 0xffffffffu - offset) return 1u;
    if (!idma_memcpy_blocking(context->base + offset, context->staging_base, bytes)) return 1u;
    nai_stream_copy(destination, staging, bytes);
    return 0u;
}

#if NAI_COMMAND_PREFETCH
static uint32_t prefetch_submit(void *context, uint32_t source, void *destination, uint32_t bytes)
{
    (void)context;
    return (uint32_t)idma_L2ToL1(source, (uint32_t)(unsigned long)destination, bytes);
}

static uint32_t prefetch_wait(void *context, uint32_t transfer_id)
{
    (void)context;
    return idma_mm_wait_for_completion(IDMA_DIR_L2_TO_L1, transfer_id);
}
#endif

static uint32_t all_zero(const uint32_t *words, uint32_t count)
{
    for (uint32_t index = 0; index < count; index++) {
        if (words[index] != 0u) return 0u;
    }
    return 1u;
}

static uint32_t fail(uint32_t code, uint32_t pointer, uint32_t completed)
{
    pmu_phase(NPU_PMU_PHASE_FAIL);
    REG_WRITE(NPU_CMD_FAIL_CODE, code);
    REG_WRITE(NPU_CMD_FAIL_PTR, pointer);
    REG_WRITE(NPU_CMD_DONE_COUNT, completed);
    REG_WRITE(NPU_CMD_STATUS, NPU_CMD_STATUS_FAIL);
    return code;
}

static uint32_t validate_invocation(const nai_invocation_v1_t *invocation,
                                    uint32_t invocation_bytes)
{
    if (invocation->magic != NAI_INVOCATION_MAGIC || invocation->abi_major != NAI_ABI_MAJOR ||
        invocation->abi_minor > NAI_ABI_MINOR || invocation->total_bytes != sizeof(*invocation) ||
        invocation->total_bytes > invocation_bytes ||
        NAI_TRUSTED_INVALID(invocation->flags != 0u ||
                            !all_zero(invocation->reserved, 8u))) return 0u;
    if ((invocation->model_base & 31u) != 0u || (invocation->model_bytes & 31u) != 0u ||
        invocation->model_bytes < sizeof(nai_model_header_v1_t) ||
        (invocation->binding_table_base & 31u) != 0u ||
        invocation->binding_count > NAI_MAX_BINDINGS_V1) return 0u;
    if ((invocation->model_bytes != 0u && invocation->model_base > 0xffffffffu - invocation->model_bytes) ||
        (invocation->binding_count != 0u && invocation->binding_table_base >
            0xffffffffu - invocation->binding_count * sizeof(nai_binding_address_v1_t))) return 0u;
    return 1u;
}

static uint32_t validate_runtime_bindings(const nai_model_view_v1_t *view,
                                          const nai_invocation_v1_t *invocation)
{
    uint32_t model_count = view->bindings->element_count;
    if (invocation->binding_count != model_count) return 0u;

    for (uint32_t index = 0; index < invocation->binding_count; index++) {
        const nai_binding_address_v1_t *address = &g_binding_addresses[index];
        uint32_t required_alignment = NAI_ALIGNMENT_BYTES;
        /* Public NHWC is a compact byte-addressed contract.  Native command
           references still request 32-byte alignment when they need it; the
           binding table itself must not reject a valid compact base. */
        if (address->direction == NAI_BINDING_INPUT || address->direction == NAI_BINDING_OUTPUT) {
            for (uint32_t public_index = 0u; public_index < model_count; public_index++) {
                const nai_binding_v1_t *binding = &view->public_bindings[public_index];
                if (binding->direction == address->direction && binding->index == address->index &&
                    binding->layout == NAI_LAYOUT_NHWC) {
                    required_alignment = 1u;
                    break;
                }
            }
        }
        if (address->flags != 0u || (address->base % required_alignment) != 0u || address->byte_size == 0u ||
            address->base > 0xffffffffu - address->byte_size) return 0u;
        if (address->direction != NAI_BINDING_INPUT && address->direction != NAI_BINDING_OUTPUT &&
            address->direction != NAI_BINDING_L2_TEMPORARY) return 0u;
        for (uint32_t previous = 0; previous < index; previous++) {
            if (g_binding_addresses[previous].direction == address->direction &&
                g_binding_addresses[previous].index == address->index) return 0u;
        }
    }

    /* Canonicalise the runtime table once so trusted command dispatch can
       resolve compiler-owned references by model binding slot in O(1). */
    for (uint32_t model_index = 0; model_index < model_count; model_index++) {
        const nai_binding_v1_t *binding = &view->public_bindings[model_index];
        uint32_t found = model_count;
        for (uint32_t runtime_index = model_index; runtime_index < invocation->binding_count; runtime_index++) {
            const nai_binding_address_v1_t *address = &g_binding_addresses[runtime_index];
            if (address->direction == binding->direction && address->index == binding->index) {
                if (address->byte_size < binding->byte_size) return 0u;
                found = runtime_index;
                break;
            }
        }
        if (found == model_count) return 0u;
        if (found != model_index) {
            nai_binding_address_v1_t temporary = g_binding_addresses[model_index];
            g_binding_addresses[model_index] = g_binding_addresses[found];
            g_binding_addresses[found] = temporary;
        }
    }
    return 1u;
}

uint32_t nai_runtime_dispatch_from_ctrl(uint32_t invocation_base,
                                        uint32_t invocation_bytes,
                                        uint32_t staging_base,
                                        uint32_t staging_bytes)
{
    nai_invocation_v1_t invocation;
    nai_model_view_v1_t view;
    nai_resolver_v1_t resolver;
    l2_reader_context_t invocation_context = {invocation_base, invocation_bytes, staging_base, staging_bytes, 0};
    nai_model_reader_v1_t invocation_reader = {&invocation_context, l2_read};
    l2_reader_context_t model_context;
    nai_model_reader_v1_t model_reader;
    uint32_t completed = 0u;
    uint32_t failure_offset = 0u;
    nai_stream_prefetch_t prefetch = {0};

    pmu_phase(NPU_PMU_PHASE_INVOCATION);
    if (staging_base != NPU_CMD_TCDM_BASE || staging_bytes < NPU_CMD_TCDM_SIZE ||
        invocation_reader.read(invocation_reader.context, 0u, &invocation, sizeof(invocation)) != 0u ||
        !validate_invocation(&invocation, invocation_bytes))
        return fail(NPU_CMD_FAIL_BAD_INVOCATION, invocation_base, 0u);

    pmu_phase(NPU_PMU_PHASE_MODEL);
    model_context = (l2_reader_context_t){invocation.model_base, invocation.model_bytes,
        staging_base, NPU_CMD_TCDM_SIZE, 0};
    model_reader = (nai_model_reader_v1_t){&model_context, l2_read};
    if (nai_model_open_stream_v1(&model_reader, invocation.model_bytes, NAI_TARGET_ID,
        &g_model_storage, &view) != NAI_LOADER_OK)
        return fail(NPU_CMD_FAIL_BAD_MODEL, invocation.model_base, 0u);

    if (invocation.binding_count != 0u) {
        pmu_phase(NPU_PMU_PHASE_BINDINGS);
        l2_reader_context_t binding_context = {invocation.binding_table_base,
            invocation.binding_count * sizeof(nai_binding_address_v1_t), staging_base, NPU_CMD_TCDM_SIZE, 0};
        nai_model_reader_v1_t binding_reader = {&binding_context, l2_read};
        if (binding_reader.read(binding_reader.context, 0u, g_binding_addresses,
            binding_context.bytes) != 0u) return fail(NPU_CMD_FAIL_BAD_BINDING,
                invocation.binding_table_base, 0u);
    }
    pmu_phase(NPU_PMU_PHASE_VALIDATE);
    if (!validate_runtime_bindings(&view, &invocation))
        return fail(NPU_CMD_FAIL_BAD_BINDING, invocation.binding_table_base, 0u);

    resolver = (nai_resolver_v1_t){invocation.model_base, invocation.model_bytes,
        g_binding_addresses, invocation.binding_count, NPU_TCDM_BASE,
        view.header->required_tcdm_bytes, 0u, 0u};
    nai_quant_buffer_reset_v1();
    REG_WRITE(NPU_CMD_STATUS, NPU_CMD_STATUS_RUNNING);
    pmu_phase(NPU_PMU_PHASE_FETCH);
    const nai_runtime_ops_v2_t *runtime_ops = nai_default_runtime_ops_v2();
#if NAI_COMMAND_PREFETCH
    const uint32_t available = view.header->required_tcdm_bytes <= NPU_CMD_TCDM_BASE - NPU_TCDM_BASE ?
        NPU_CMD_TCDM_BASE - NPU_TCDM_BASE - view.header->required_tcdm_bytes : 0u;
    const uint32_t slot_bytes = nai_stream_prefetch_capacity(available);
    const uint32_t stream_end = view.commands->offset + view.commands->size;
    /* A stream fitting one dispatch window has no later fetch to hide. */
    if (slot_bytes != 0u && stream_end - view.header->entry_command_off > sizeof(g_command_buffer)) {
        const nai_stream_prefetch_ops_t prefetch_ops = {0, prefetch_submit, prefetch_wait};
        if (nai_stream_prefetch_init(&prefetch, &prefetch_ops, invocation.model_base,
                view.header->entry_command_off, stream_end,
                (void *)(unsigned long)(NPU_CMD_TCDM_BASE - 2u * slot_bytes), slot_bytes) != 0u) {
            (void)nai_stream_prefetch_finish(&prefetch);
            return fail(NPU_CMD_FAIL_BAD_MODEL, invocation.model_base, 0u);
        }
        model_context.prefetch = &prefetch;
    }
#endif
    nai_dispatch_status_v2_t status = nai_cmd_dispatch_stream_v2(&view, &resolver,
        runtime_ops, &model_reader, g_command_buffer, sizeof(g_command_buffer),
        &completed, &failure_offset);
    pmu_phase(NPU_PMU_PHASE_BARRIER);
    if (nai_stream_prefetch_finish(&prefetch) != 0u && status == NAI_DISPATCH_OK)
        status = NAI_DISPATCH_OPERATION_FAILED;
    if (runtime_ops->barrier == 0 || runtime_ops->barrier(runtime_ops->context) != 0u) {
        if (status == NAI_DISPATCH_OK) status = NAI_DISPATCH_OPERATION_FAILED;
    }
    if (status != NAI_DISPATCH_OK) return fail(NPU_CMD_FAIL_V2_DISPATCH + (uint32_t)status,
        invocation.model_base + failure_offset, completed);

    pmu_phase(NPU_PMU_PHASE_COMPLETE);
    REG_WRITE(NPU_CMD_DONE_COUNT, completed);
    REG_WRITE(NPU_CMD_FAIL_CODE, NPU_CMD_FAIL_NONE);
    REG_WRITE(NPU_CMD_FAIL_PTR, 0u);
    REG_WRITE(NPU_CMD_STATUS, NPU_CMD_STATUS_PASS);
    return NPU_CMD_FAIL_NONE;
}
