#ifndef NPU_CMD_DESC_V2_H
#define NPU_CMD_DESC_V2_H

#include "npu_model_loader.h"
#include "hal_systolic.h"

#define NAI_CMD_FLAG_OPTIONAL  (1u << 0)
#define NAI_CMD_FLAG_SKIPPABLE (1u << 1)
#define NAI_CMD_FLAG_AFU_LUT_REUSE (1u << 2)
#define NAI_CMD_FLAG_AFU_LUT_CHAIN (1u << 3)
#define NAI_CMD_FLAG_AFU_GLOBAL_AVGPOOL_REQUANT (1u << 4)

typedef enum {
    NAI_CMD_END = 0,
    NAI_CMD_BARRIER = 1,
    NAI_CMD_DMA_1D = 2,
    NAI_CMD_DMA_2D = 3,
    NAI_CMD_DMA_3D = 4,
    NAI_CMD_RQ_LOAD = 5,
    NAI_CMD_GEMM32 = 6,
    NAI_CMD_GEMM32_ACCUM = 7,
    NAI_CMD_GEMM32_REQUANT = 8,
    NAI_CMD_LINEBUF_JOB = 9,
    NAI_CMD_POINTWISE_C32 = 10,
    NAI_CMD_DEPTHWISE_C32 = 11,
    NAI_CMD_AFU_LUT = 12,
    NAI_CMD_AFU_BINARY = 13,
    NAI_CMD_AFU_GLOBAL_AVGPOOL = 14,
    NAI_CMD_SPATZ_REQUANT = 15,
    NAI_CMD_SPATZ_ADD = 16,
    NAI_CMD_SPATZ_MUL = 17,
    NAI_CMD_COPY_LAYOUT = 18,
    NAI_CMD_MAXPOOL = 19,
    NAI_CMD_UPSAMPLE_NEAREST = 20,
    NAI_CMD_ROLLING_RESET = 21,
    NAI_CMD_ROLLING_PRODUCE = 22,
    NAI_CMD_ROLLING_CONSUME_RELEASE = 23,
    NAI_CMD_DMA_SUBMIT_1D = 24,
    NAI_CMD_DMA_SUBMIT_2D = 25,
    NAI_CMD_DMA_SUBMIT_3D = 26,
    NAI_CMD_DMA_WAIT = 27,
    NAI_CMD_AFU_DFL16 = 28,
    NAI_CMD_LINEBUF_SUBMIT = 29,
    NAI_CMD_SYSTOLIC_WAIT = 30,
    NAI_CMD_LINEBUF_BINARY = 31,
    NAI_CMD_LINEBUF_BINARY_SUBMIT = 32,
    NAI_CMD_AFFINE_LOOP = 33,
    NAI_CMD_AFU_BINARY_QUANT = 34
} nai_cmd_type_v2_t;

typedef struct {
    uint16_t type;
    uint16_t size_bytes;
    uint32_t flags;
    uint32_t layer_id;
    uint32_t tile_id;
} nai_cmd_header_v2_t;

#define NAI_AFFINE_LOOP_MAX_PATCHES      24u
#define NAI_AFFINE_LOOP_MAX_BODY_COMMANDS 16u
#define NAI_AFFINE_LOOP_MAX_RECORD_BYTES 2048u

typedef struct {
    nai_cmd_header_v2_t header;
    uint32_t iteration_count;
    uint32_t body_command_count;
    uint32_t body_bytes;
    uint32_t patch_count;
} nai_cmd_affine_loop_v2_t;

typedef struct {
    uint32_t body_word_offset;
    uint32_t delta;
} nai_cmd_affine_patch_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    uint32_t reserved[4];
} nai_cmd_control_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    uint32_t qparam_index;
    uint32_t qparam_count;
    uint32_t qparam_block;
    uint32_t reserved;
} nai_cmd_rq_load_v2_t;

typedef enum {
    NAI_DMA_EXTERNAL_TO_LOCAL = 0,
    NAI_DMA_LOCAL_TO_EXTERNAL = 1,
    NAI_DMA_LOCAL_TO_LOCAL = 2
} nai_dma_direction_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t source;
    nai_ref_v1_t destination;
    uint32_t length;
    uint32_t direction;
    uint32_t reserved[6];
} nai_cmd_dma_1d_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t source;
    nai_ref_v1_t destination;
    uint32_t length;
    uint32_t source_stride_2;
    uint32_t destination_stride_2;
    uint32_t repetitions_2;
    uint32_t direction;
    uint32_t reserved[3];
} nai_cmd_dma_2d_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t source;
    nai_ref_v1_t destination;
    uint32_t length;
    uint32_t source_stride_2;
    uint32_t destination_stride_2;
    uint32_t repetitions_2;
    uint32_t source_stride_3;
    uint32_t destination_stride_3;
    uint32_t repetitions_3;
    uint32_t direction;
} nai_cmd_dma_3d_v2_t;

/* Async DMA uses the same transfer descriptors as blocking DMA.  One transfer
   may be outstanding in each external direction.  DMA_WAIT selects the
   direction to join; local-to-local transfers remain synchronous. */
typedef struct {
    nai_cmd_header_v2_t header;
    uint32_t direction;
    uint32_t reserved[3];
} nai_cmd_dma_wait_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t weights;
    nai_ref_v1_t ifm;
    nai_ref_v1_t partial_sums;
    nai_ref_v1_t ofm;
    uint32_t dim_m;
    uint32_t ofm_row_stride;
    uint32_t partial_sum_row_stride;
    uint32_t qparam_block;
    uint32_t reserved[8];
} nai_cmd_gemm32_v2_t;

typedef struct {
    systolic_linebuf_cfg_t linebuf;
    systolic_gemm32_req_t gemm;
    uint32_t rows;
    uint32_t k_tiles;
} nai_linebuf_job_wire_v1_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_linebuf_job_wire_v1_t job;
    uint8_t reserved[20];
} nai_cmd_linebuf_job_v2_t;

/* Fused Conv/linebuffer -> requant -> binary post-op.  The RHS address is a
   compact TCDM offset on the wire and is relocated by the runtime. */
typedef struct {
    nai_cmd_header_v2_t header;
    nai_linebuf_job_wire_v1_t job;
    systolic_binary_cfg_t binary;
    uint8_t reserved[20];
} nai_cmd_linebuf_binary_v2_t;

/* Pointwise 1x1 C32 command. Activations are group-major C32 blocked;
   weights are OCG-major, then ICG-major, with one 32x32 tile per pair.
   `rows` is the complete output row count.  The runtime executes it as
   <=256-row systolic stripes while reusing staged weight tiles. */
typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t weights;
    nai_ref_v1_t ifm;
    nai_ref_v1_t partial_sums;
    nai_ref_v1_t ofm;
    uint32_t rows;
    uint32_t input_c32_groups;
    uint32_t output_c32_groups;
    uint32_t qparam_block;
    uint32_t input_group_stride_bytes;
    uint32_t output_group_stride_bytes;
    uint32_t reserved[6];
} nai_cmd_pointwise_c32_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t weights;
    nai_ref_v1_t ifm;
    nai_ref_v1_t ofm;
    uint32_t input_h;
    uint32_t input_w;
    uint32_t output_h;
    uint32_t output_w;
    uint32_t channels;
    uint32_t stride_h;
    uint32_t stride_w;
    uint32_t pad_h;
    uint32_t pad_w;
    uint32_t qparam_block;
    uint32_t reserved[4];
} nai_cmd_depthwise_c32_v2_t;

/* Generic INT8 lookup.  The AFU consumes one byte per element and the LUT
   contains exactly one output byte for every possible input byte. */
typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t ifm;
    nai_ref_v1_t ofm;
    nai_ref_v1_t lut;
    uint32_t length;
    uint32_t reserved[5];
} nai_cmd_afu_lut_v2_t;

typedef enum {
    NAI_AFU_BINARY_ADD_I8 = 1,
    NAI_AFU_BINARY_ADD_I8_BIAS = 2
} nai_afu_binary_mode_v2_t;

typedef enum {
    NAI_SPATZ_BINARY_ADD = 0,
    NAI_SPATZ_BINARY_SUBTRACT = 1,
    NAI_SPATZ_BINARY_MULTIPLY = 2
} nai_spatz_binary_mode_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t lhs;
    nai_ref_v1_t rhs;
    nai_ref_v1_t ofm;
    uint32_t length;
    uint32_t mode;
    int32_t bias;
    uint32_t reserved[3];
} nai_cmd_afu_binary_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t lhs;
    nai_ref_v1_t rhs;
    nai_ref_v1_t ofm;
    uint32_t length;
    int32_t lhs_scale;
    uint32_t lhs_shift;
    int32_t rhs_scale;
    uint32_t rhs_shift;
    int32_t output_scale;
    uint32_t output_shift;
    int32_t lhs_zero_point;
    int32_t rhs_zero_point;
    int32_t output_zero_point;
    int32_t clamp_min;
    int32_t clamp_max;
    uint32_t double_round_shift;
    uint32_t mode;
} nai_cmd_spatz_add_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t lhs;
    nai_ref_v1_t rhs;
    nai_ref_v1_t ofm;
    uint32_t length;
    int32_t lhs_scale;
    uint32_t lhs_shift;
    int32_t rhs_scale;
    uint32_t rhs_shift;
    int32_t output_scale;
    uint32_t output_shift;
    int32_t lhs_zero_point;
    int32_t rhs_zero_point;
    int32_t output_zero_point;
    int32_t clamp_min;
    int32_t clamp_max;
    uint32_t double_round_shift;
    uint32_t mode;
} nai_cmd_afu_binary_quant_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t ifm;
    nai_ref_v1_t ofm;
    uint32_t input_h;
    uint32_t input_w;
    uint32_t channels;
    int32_t output_multiplier;
    uint32_t output_shift;
    int32_t input_offset;
    int32_t output_zero_point;
    uint32_t double_round_shift;
} nai_cmd_afu_global_avgpool_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t ifm;
    nai_ref_v1_t ofm;
    uint32_t input_h;
    uint32_t input_w;
    uint32_t channels;
    uint32_t scale_h;
    uint32_t scale_w;
    uint32_t reserved[3];
} nai_cmd_upsample_nearest_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t ifm;
    nai_ref_v1_t ofm;
    uint32_t input_h;
    uint32_t input_w;
    uint32_t channels;
    uint32_t kernel_h;
    uint32_t kernel_w;
    uint32_t stride_h;
    uint32_t stride_w;
    uint32_t pad_h;
    uint32_t pad_w;
    uint32_t reserved[7];
} nai_cmd_maxpool_v2_t;

typedef enum {
    NAI_COPY_NHWC_TO_ROW32 = 1,
    NAI_COPY_ROW32_TO_NHWC = 2,
    NAI_COPY_NHWC_TO_C32 = 3,
    NAI_COPY_C32_TO_NHWC = 4,
    NAI_COPY_C32_TO_CHW = 5
} nai_copy_layout_mode_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t source;
    nai_ref_v1_t destination;
    uint16_t mode;
    uint16_t source_layout;
    uint16_t destination_layout;
    uint16_t data_type;
    uint32_t dimensions[4];
    uint32_t valid_channels;
    uint32_t source_row_stride;
    uint32_t destination_row_stride;
    uint32_t reserved[7];
} nai_cmd_copy_layout_v2_t;

typedef struct {
    nai_cmd_header_v2_t header;
    nai_ref_v1_t source;
    nai_ref_v1_t destination;
    nai_ref_v1_t scratch;
    nai_ref_v1_t exp_lut;
    nai_ref_v1_t recip_lut;
    uint32_t locations;
    uint32_t source_layout;
    int32_t output_multiplier;
    uint32_t output_shift;
    int32_t output_zero_point;
    int32_t clamp_min;
    int32_t clamp_max;
    uint32_t reserved[3];
} nai_cmd_afu_dfl16_v2_t;

_Static_assert(sizeof(nai_cmd_header_v2_t) == 16, "nai_cmd_header_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_affine_loop_v2_t) == 32,
               "nai_cmd_affine_loop_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_affine_patch_v2_t) == 8,
               "nai_cmd_affine_patch_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_control_v2_t) == 32, "nai_cmd_control_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_rq_load_v2_t) == 32, "nai_cmd_rq_load_v2_t ABI size");
_Static_assert(offsetof(nai_cmd_rq_load_v2_t, qparam_index) == 16, "RQ load index offset");
_Static_assert(offsetof(nai_cmd_rq_load_v2_t, qparam_block) == 24, "RQ load block offset");
_Static_assert(sizeof(nai_cmd_dma_1d_v2_t) == 64, "nai_cmd_dma_1d_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_dma_2d_v2_t) == 64, "nai_cmd_dma_2d_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_dma_3d_v2_t) == 64, "nai_cmd_dma_3d_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_dma_wait_v2_t) == 32, "nai_cmd_dma_wait_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_gemm32_v2_t) == 96, "nai_cmd_gemm32_v2_t ABI size");
_Static_assert(sizeof(nai_linebuf_job_wire_v1_t) == 124, "nai_linebuf_job_wire_v1_t ABI size");
_Static_assert(sizeof(nai_cmd_linebuf_job_v2_t) == 160, "nai_cmd_linebuf_job_v2_t ABI size");
_Static_assert(sizeof(systolic_binary_cfg_t) == 64, "systolic_binary_cfg_t ABI size");
_Static_assert(sizeof(nai_cmd_linebuf_binary_v2_t) == 224,
               "nai_cmd_linebuf_binary_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_pointwise_c32_v2_t) == 96, "nai_cmd_pointwise_c32_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_depthwise_c32_v2_t) == 96, "nai_cmd_depthwise_c32_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_afu_lut_v2_t) == 64, "nai_cmd_afu_lut_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_afu_binary_v2_t) == 64, "nai_cmd_afu_binary_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_spatz_add_v2_t) == 96, "nai_cmd_spatz_add_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_afu_binary_quant_v2_t) == 96,
               "nai_cmd_afu_binary_quant_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_afu_global_avgpool_v2_t) == 64,
               "nai_cmd_afu_global_avgpool_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_upsample_nearest_v2_t) == 64,
               "nai_cmd_upsample_nearest_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_maxpool_v2_t) == 96,
               "nai_cmd_maxpool_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_copy_layout_v2_t) == 96, "nai_cmd_copy_layout_v2_t ABI size");
_Static_assert(sizeof(nai_cmd_afu_dfl16_v2_t) == 96, "nai_cmd_afu_dfl16_v2_t ABI size");
_Static_assert(offsetof(nai_cmd_gemm32_v2_t, weights) == 16, "GEMM reference offset");
_Static_assert(offsetof(nai_cmd_gemm32_v2_t, dim_m) == 48, "GEMM dimension offset");

typedef enum {
    NAI_DISPATCH_OK = 0,
    NAI_DISPATCH_BAD_STREAM = 1,
    NAI_DISPATCH_BAD_COMMAND = 2,
    NAI_DISPATCH_UNSUPPORTED = 3,
    NAI_DISPATCH_BAD_REFERENCE = 4,
    NAI_DISPATCH_OPERATION_FAILED = 5
} nai_dispatch_status_v2_t;

typedef struct {
    void *context;
    uint32_t (*dma_1d)(void *context, uint32_t source, uint32_t destination,
                       uint32_t length, uint32_t direction);
    uint32_t (*dma_2d)(void *context, uint32_t source, uint32_t destination,
                       uint32_t length, uint32_t source_stride, uint32_t destination_stride,
                       uint32_t repetitions, uint32_t direction);
    uint32_t (*dma_3d)(void *context, uint32_t source, uint32_t destination,
                       uint32_t length, uint32_t source_stride_2, uint32_t destination_stride_2,
                       uint32_t repetitions_2, uint32_t source_stride_3,
                       uint32_t destination_stride_3, uint32_t repetitions_3,
                       uint32_t direction);
    uint32_t (*gemm32)(void *context, const nai_cmd_gemm32_v2_t *command,
                       uint32_t weights, uint32_t ifm, uint32_t partial_sums, uint32_t ofm);
    uint32_t (*pointwise_c32)(void *context, const nai_cmd_pointwise_c32_v2_t *command,
                              uint32_t weights, uint32_t ifm, uint32_t partial_sums, uint32_t ofm);
    uint32_t (*depthwise_c32)(void *context, const nai_cmd_depthwise_c32_v2_t *command,
                              uint32_t weights, uint32_t ifm, uint32_t ofm);
    uint32_t (*afu_lut)(void *context, const nai_cmd_afu_lut_v2_t *command,
                        uint32_t ifm, uint32_t ofm, uint32_t lut);
    uint32_t (*afu_binary)(void *context, const nai_cmd_afu_binary_v2_t *command,
                           uint32_t lhs, uint32_t rhs, uint32_t ofm);
    uint32_t (*spatz_add)(void *context, const nai_cmd_spatz_add_v2_t *command,
                          uint32_t lhs, uint32_t rhs, uint32_t ofm);
    uint32_t (*afu_global_avgpool)(
        void *context, const nai_cmd_afu_global_avgpool_v2_t *command,
        uint32_t ifm, uint32_t ofm);
    uint32_t (*upsample_nearest)(
        void *context, const nai_cmd_upsample_nearest_v2_t *command,
        uint32_t ifm, uint32_t ofm);
    uint32_t (*maxpool)(
        void *context, const nai_cmd_maxpool_v2_t *command,
        uint32_t ifm, uint32_t ofm);
    uint32_t (*linebuf_job)(void *context, const nai_cmd_linebuf_job_v2_t *command);
    uint32_t (*copy_layout)(void *context, const nai_cmd_copy_layout_v2_t *command,
                           uint32_t source, uint32_t destination);
    uint32_t (*afu_dfl16)(void *context, const nai_cmd_afu_dfl16_v2_t *command,
                          uint32_t source, uint32_t destination, uint32_t scratch,
                          uint32_t exp_lut, uint32_t recip_lut);
    uint32_t (*barrier)(void *context);
    uint32_t (*rq_load)(void *context, uint32_t qparam_address,
                        uint32_t qparam_count, uint32_t qparam_block);
    uint32_t (*dma_submit_1d)(void *context, uint32_t source, uint32_t destination,
                              uint32_t length, uint32_t direction);
    uint32_t (*dma_submit_2d)(void *context, uint32_t source, uint32_t destination,
                              uint32_t length, uint32_t source_stride,
                              uint32_t destination_stride, uint32_t repetitions,
                              uint32_t direction);
    uint32_t (*dma_submit_3d)(void *context, uint32_t source, uint32_t destination,
                              uint32_t length, uint32_t source_stride_2,
                              uint32_t destination_stride_2, uint32_t repetitions_2,
                              uint32_t source_stride_3, uint32_t destination_stride_3,
                              uint32_t repetitions_3, uint32_t direction);
    uint32_t (*dma_wait)(void *context, uint32_t direction);
    uint32_t (*linebuf_submit)(void *context, const nai_cmd_linebuf_job_v2_t *command);
    uint32_t (*systolic_wait)(void *context);
    uint32_t (*linebuf_binary_job)(
        void *context, const nai_cmd_linebuf_binary_v2_t *command);
    uint32_t (*linebuf_binary_submit)(
        void *context, const nai_cmd_linebuf_binary_v2_t *command);
    uint32_t (*afu_binary_quant)(void *context,
                                 const nai_cmd_afu_binary_quant_v2_t *command,
                                 uint32_t lhs, uint32_t rhs, uint32_t ofm);
} nai_runtime_ops_v2_t;

nai_dispatch_status_v2_t nai_cmd_dispatch_v2(const nai_model_view_v1_t *view,
                                             const nai_resolver_v1_t *resolver,
                                             const nai_runtime_ops_v2_t *ops,
                                             uint32_t *completed_commands,
                                             uint32_t *failure_command_offset);
/* The mutable dispatch window must be word-aligned. ABI records remain
 * 32-byte sized/aligned within it; refill owns it until a loop completes. */
nai_dispatch_status_v2_t nai_cmd_dispatch_stream_v2(const nai_model_view_v1_t *view,
                                                    const nai_resolver_v1_t *resolver,
                                                    const nai_runtime_ops_v2_t *ops,
                                                    const nai_model_reader_v1_t *reader,
                                                    void *command_buffer,
                                                    uint32_t command_buffer_bytes,
                                                    uint32_t *completed_commands,
                                                    uint32_t *failure_command_offset);

#endif
